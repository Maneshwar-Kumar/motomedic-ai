"""One owner-requested service-due live API diagnostic; import has no cloud action."""
from copy import deepcopy
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile
from datetime import datetime,timezone
from urllib.parse import urlencode

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'));sys.path.insert(0,str(ROOT))
import submit_hosted_v10 as cloud
import public_cloud_run_v10_13 as run
OUT=cloud.OUT/'haiku_v10_14_helpers/service_due_api_operator_v1'
MEMBER='serviceAccount:'+run.BACKEND_SA
GET_ROLE='projects/'+cloud.PROJECT+'/roles/motomedicSnapshotObjectGet'
TITLE='motomedic-backend-exact-service-due-api-v10-14-v1'
ARTIFACT_NAMES=frozenset(('service_due_case.json','receipt.json','exit_status.json'))
INVENTORY='tmp/service-due-api-v14-v1/source_inventory.json'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def write(name,value):
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/name).open('x',encoding='utf-8') as target:target.write(json.dumps(value,indent=2,sort_keys=True)+'\n')

def prepare_source(guard_name):
    import uuid
    import public_ui_preview_v13_v2 as preview
    if (OUT/'source_preparation.json').exists():raise ValueError('NEVER_OVERWRITE_SINGLE_CASE_PREPARATION')
    guard=preview.guard_receipt(guard_name)
    owner_path='reports/public_evaluator/20261012/haiku_v10_14_helpers/owner_service_due_retest_scope_v1.json'
    mvp_path='reports/public_evaluator/20261012/public_review/owner_mvp_scope_v1.json'
    owner=json.loads((ROOT/owner_path).read_bytes())
    if owner.get('question')!='When is the service due for my bike?' or owner.get('owner_authorized')is not True or owner.get('section_hint_enters_model_or_retrieval')is not False:
        raise ValueError('EXACT_OWNER_SINGLE_UNHINTED_SERVICE_QUERY_REQUIRED')
    names=['tmp/single_service_due_client_v14_v1.py','tmp/public_evaluator/hosted_client_v10_13_v2.py',owner_path,mvp_path,
        guard['path'],'reports/public_evaluator/20261012/serving_manifest_v10_14.json',
        'reports/public_evaluator/20261012/expected_runtime_lock_v10_14.json',
        'reports/public_evaluator/20261012/evaluator_client_source_v11.json',
        'reports/public_evaluator/20261012/owner_model_scope_v3.json',
        'reports/public_evaluator/20261012/haiku_v10_12/owner_anthropic_payload_scope_v2.json']
    hashes={name:sha(ROOT/name) for name in names};manifest_path=names[5]
    source11=json.loads((ROOT/names[7]).read_bytes())
    if hashes[names[1]]!=source11['files'][names[1]]:raise ValueError('EXACT_EXISTING_SOURCE11_API_CLIENT_CHANGED')
    lock=json.loads((ROOT/names[6]).read_bytes())['runtime_lock']
    if source11['serving_manifest_sha256']!='3d1d01d09c1929a8c1e52e698a3b4ca9b48c14a14954b82f7d6c795ab6bf031c' or source11['runtime_lock']!='923ef8c96bf1dbae68a03a25816c638379c988bcb8d710e1db47e77f1682c2df':
        raise ValueError('HISTORICAL_SOURCE11_FROZEN_BINDING_CHANGED')
    if hashes[manifest_path]!='b8d39544a9cc216b7bd6d37dd741c12e95f6e1d2694a59eaf573cb51195962f5' or lock!='dc6393fac73eef8f68655b49fb3189d958ca49321d0af02cc58b4e21898cef02':
        raise ValueError('EXACT_NEW_V14_FROZEN_BINDING_REQUIRED')
    frozen=json.loads((ROOT/manifest_path).read_bytes())
    for relative in ('rider_ui/client.py','rider_ui/identity.py','rider_ui/verified_sse.py','cloud/grounded_generation/token_ceiling.py'):
        if frozen['file_sha256'][relative]!=source11['files'][relative]:raise ValueError('SOURCE11_CLIENT_BYTES_INCOMPATIBLE_WITH_V14')
    inventory={'schema':'motomedic-single-service-due-api-source-inputs-v1','file_sha256':hashes,
        'manifest_path':manifest_path,'serving_manifest_sha256':hashes[manifest_path],'runtime_lock':lock,
        'guard_path':guard['path'],'owner_scope_sha256':hashes[owner_path],
        'question':owner['question'],'operation_id':uuid.uuid4().hex,'source11_reference_sha256':hashes[names[7]],
        'native_count_and_admission_authority':'UNCHANGED_ACTUAL_PRODUCTION_RUNTIME',
        'old_six_case_or_count2_forecast_used':False,'section_hint_enters_query':False}
    local=ROOT/INVENTORY;local.parent.mkdir(parents=True,exist_ok=True)
    with local.open('x',encoding='utf-8') as target:json.dump(inventory,target,indent=2,sort_keys=True);target.write('\n')
    names.append(INVENTORY);hashes[INVENTORY]=sha(local);compressed=io.BytesIO()
    with gzip.GzipFile(fileobj=compressed,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as archive:
            for name in sorted(names):
                raw=(ROOT/name).read_bytes();row=tarfile.TarInfo(name);row.size=len(raw);row.mode=0o644;row.mtime=0;archive.addfile(row,io.BytesIO(raw))
    raw=compressed.getvalue();archive_sha=hashlib.sha256(raw).hexdigest();archive=ROOT/'tmp/service-due-api-v14-v1/source.tar.gz'
    with archive.open('xb') as target:target.write(raw)
    value={'schema':'motomedic-single-service-due-api-source-preparation-v1','archive':archive.relative_to(ROOT).as_posix(),
        'sha256':archive_sha,'bytes':len(raw),'files':hashes,'inventory_sha256':hashes[INVENTORY],
        'serving_manifest_sha256':hashes[manifest_path],'runtime_lock':lock,'operation_id':inventory['operation_id'],
        'guard':guard,'object':'serving/engineering-diagnostics/v10_14/'+archive_sha+'.tar.gz','provider_calls':0}
    write('source_preparation.json',value);return {'source_prepared':True,'operation_id':inventory['operation_id'],'sha256':archive_sha,'provider_calls':0}

def prepared():
    value=read('source_preparation.json')
    if sha(ROOT/value['archive'])!=value['sha256'] or any(sha(ROOT/name)!=expected for name,expected in value['files'].items()):
        raise ValueError('EXACT_MAINTENANCE_PREPARATION_CHANGED')
    return value

def upload_source():
    value=prepared();raw=(ROOT/value['archive']).read_bytes()
    url='https://storage.googleapis.com/upload/storage/v1/b/'+cloud.BUCKET+'/o?'+urlencode({'uploadType':'media','name':value['object'],'ifGenerationMatch':'0'})
    request=cloud.Request(url,data=raw,method='POST',headers={'Authorization':'Bearer '+cloud.token(),'Content-Type':'application/gzip'})
    with cloud.build_opener(cloud.NoRedirect()).open(request,timeout=60) as response:metadata=json.load(response)
    reference={**value,'generation':str(metadata['generation']),'uri':'gs://'+cloud.BUCKET+'/'+value['object']}
    from cloud.serving_artifacts import GCSReader,ObjectReference
    GCSReader(token=cloud.token).fetch(ObjectReference(uri=reference['uri'],generation=reference['generation'],
        sha256=reference['sha256'],maximum_bytes=reference['bytes']),ROOT/'tmp/service-due-api-v14-v1/upload_readback.tar.gz')
    write('source_reference.json',reference);return {'source_uploaded':True,'generation':reference['generation'],'provider_calls':0}

def source_reference():
    preparation=prepared();source=read('source_reference.json')
    if any(source.get(key)!=value for key,value in preparation.items()):raise ValueError('MAINTENANCE_SOURCE_REFERENCE_CHANGED')
    return source

def source_policy(policy,source):
    if not policy.get('etag') or not re.fullmatch(r'serving/engineering-diagnostics/v10_14/[0-9a-f]{64}\.tar\.gz',source['object']):
        raise ValueError('EXACT_MAINTENANCE_SOURCE_OR_ETAG_REQUIRED')
    if source['object'].split('/')[-1]!=source['sha256']+'.tar.gz' or any(row.get('condition',{}).get('title')==TITLE for row in policy.get('bindings',[])):
        raise ValueError('EXACT_NEW_MAINTENANCE_SOURCE_GRANT_REQUIRED')
    if any(set(row.get('members',[])).intersection({'allUsers','allAuthenticatedUsers'}) for row in policy.get('bindings',[])):
        raise ValueError('PRIVATE_MAINTENANCE_SOURCE_BUCKET_REQUIRED')
    updated=deepcopy(policy);updated['version']=3
    added={'role':GET_ROLE,'members':[MEMBER],'condition':{'title':TITLE,
        'expression':"resource.name == 'projects/_/buckets/"+cloud.BUCKET+'/objects/'+source['object']+"'",
        'description':'Read only the exact owner-requested single service-due API diagnostic archive'}}
    updated.setdefault('bindings',[]).append(added);return updated,added

def grant_source():
    source=source_reference();endpoint='https://storage.googleapis.com/storage/v1/b/'+cloud.BUCKET+'/iam'
    policy=run.api('GET',endpoint+'?optionsRequestedPolicyVersion=3');updated,added=source_policy(policy,source)
    client_grant=json.loads((cloud.OUT/'operations/client_source_grant_v11.json').read_bytes())
    if client_grant['added_binding'] not in policy.get('bindings',[]):raise ValueError('EXACT_CLIENT11_GET_GRANT_MISSING')
    run.api('PUT',endpoint,updated);after=run.api('GET',endpoint+'?optionsRequestedPolicyVersion=3')
    if added not in after.get('bindings',[]) or sorted(digest(row) for row in after['bindings'] if row!=added)!=sorted(digest(row) for row in policy['bindings']):
        raise ValueError('MAINTENANCE_EXACT_GET_GRANT_READBACK_FAILED')
    write('source_grant.json',{'source':source,'added_binding':added,'all_previous_bindings_including_client11_and_artifact_creator_unchanged':True,
        'prior_policy_sha256':digest(policy),'readback_policy_sha256':digest(after),'provider_calls':0,'public_iam_changed':False})
    return {'exact_diagnostic_source_get_granted':True,'client11_unchanged':True,'provider_calls':0}

def build_recipe(source,binding):
    if (binding.get('schema')!='motomedic-backend-only-v14-build-binding-v1' or
        binding.get('runtime_revision')!='v10_14' or binding.get('serving_manifest_sha256')!=source['serving_manifest_sha256'] or
        binding.get('serving_manifest_sha256')!='b8d39544a9cc216b7bd6d37dd741c12e95f6e1d2694a59eaf573cb51195962f5' or
        binding.get('source_commit')!='67fc3171bcdae8cdf5725bcb4739806ec6353f66' or
        binding.get('runtime_lock')!=source['runtime_lock'] or binding.get('runtime_lock')!='dc6393fac73eef8f68655b49fb3189d958ca49321d0af02cc58b4e21898cef02' or
        not re.fullmatch(r'us-central1-docker\.pkg\.dev/motomedic-ai-20261009/motomedic/arm-a@sha256:[0-9a-f]{64}',binding.get('backend_image','')) or
        not re.fullmatch(r'[0-9]+',source.get('generation','')) or source['object']!='serving/engineering-diagnostics/v10_14/'+source['sha256']+'.tar.gz'):
        raise ValueError('EXACT_FROZEN_SINGLE_CASE_SOURCE_REQUIRED')
    output='tmp/service-due-api-v14-run/$BUILD_ID'
    return {'serviceAccount':'projects/'+cloud.PROJECT+'/serviceAccounts/'+run.BACKEND_SA,
        'source':{'storageSource':{'bucket':cloud.BUCKET,'object':source['object'],'generation':source['generation']}},
        'steps':[{'name':'docker.io/library/python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1',
            'entrypoint':'python','args':['-c','from pathlib import Path; p=Path("/workspace/'+output+'"); p.mkdir(parents=True,exist_ok=True); p.chmod(0o777)']},
            {'name':binding['backend_image'],'entrypoint':'python','args':['-B','tmp/single_service_due_client_v14_v1.py',
                '--inventory',INVENTORY,'--output','/workspace/'+output,'--allocated-job-id','$BUILD_ID',
                '--artifact-uri','gs://'+cloud.BUCKET+'/engineering-acceptance/public-v10_3/$BUILD_ID'],
                'env':['PYTHONPATH=/app','MOTOMEDIC_HOSTED_PROVIDER_VALIDATION=true','MOTOMEDIC_CLOUD_BUILD_ID=$BUILD_ID'],
                'secretEnv':['MOTOMEDIC_VISITOR_SECRET']}],
        'availableSecrets':{'secretManager':[{'versionName':'projects/'+cloud.PROJECT+'/secrets/motomedic-rider-visitor-v1/versions/1','env':'MOTOMEDIC_VISITOR_SECRET'}]},
        'options':{'logging':'CLOUD_LOGGING_ONLY'},'timeout':'1800s'}

def submit():
    source=source_reference();grant=read('source_grant.json')
    if (OUT/'submission.json').exists():raise ValueError('MAINTENANCE_SUBMISSION_EXISTS_USE_POLL')
    if grant['source']!=source:raise ValueError('MAINTENANCE_SOURCE_GET_BINDING_CHANGED')
    import public_ui_preview_v13_v2 as preview
    preview.guard_receipt(source['guard']['path'])
    if (OUT/'submit_intent.json').exists():raise ValueError('SUBMISSION_OUTCOME_MAY_BE_UNCERTAIN_NO_RETRY')
    binding_path=cloud.OUT/'haiku_v10_14_helpers/backend_release_v1/backend_build_binding.json'
    binding=json.loads(binding_path.read_bytes());config=build_recipe(source,binding)
    write('submit_intent.json',{'config':config,'operation_id':source['operation_id'],'backend_build_binding_path':binding_path.relative_to(ROOT).as_posix(),'backend_build_binding_sha256':sha(binding_path),'provider_calls':0})
    operation=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds',config)
    write('submission.json',{'config':config,'operation':operation,'backend_build_binding_path':binding_path.relative_to(ROOT).as_posix(),'backend_build_binding_sha256':sha(binding_path),'provider_calls':0})
    return {'id':operation['metadata']['build']['id'],'provider_calls':0}

def poll():
    job=read('submission.json')['operation']['metadata']['build']['id'];result=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds/'+job)
    name='build_readback_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json'
    write(name,result);return {'id':job,'status':result['status'],'readback':name,'provider_calls':0}

def logs():
    job=read('submission.json')['operation']['metadata']['build']['id']
    if not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',job):raise ValueError('EXACT_MAINTENANCE_BUILD_ID_REQUIRED')
    result=cloud.api('https://logging.googleapis.com/v2/entries:list',{'resourceNames':['projects/'+cloud.PROJECT],
        'filter':'resource.type="build" AND resource.labels.build_id="'+job+'"','orderBy':'timestamp desc','pageSize':500})
    records=[]
    for row in result.get('entries',[]):
        value=row.get('jsonPayload')
        if not isinstance(value,dict):
            text=row.get('textPayload','')
            try:value=json.loads(text[text.find('{'):])
            except (ValueError,TypeError):continue
        if not isinstance(value,dict) or value.get('artifact_file') not in ARTIFACT_NAMES:continue
        if not re.fullmatch(r'[0-9]+',str(value.get('generation',''))) or not re.fullmatch(r'[0-9a-f]{64}',value.get('sha256','')):
            raise ValueError('MAINTENANCE_ARTIFACT_LOG_BINDING_INVALID')
        records.append({'timestamp':row.get('timestamp'),'artifact_file':value['artifact_file'],
            'generation':str(value['generation']),'sha256':value['sha256']})
    name='artifact_logs_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json'
    write(name,{'schema':'motomedic-maintenance-artifact-log-inventory-v1','cloud_build_id':job,'records':records,
        'raw_logs_saved':False,'provider_calls':0})
    return {'id':job,'artifact_records':len(records),'log_inventory':name,'provider_calls':0}

def download():
    job=read('submission.json')['operation']['metadata']['build']['id']
    if not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',job):raise ValueError('EXACT_MAINTENANCE_BUILD_ID_REQUIRED')
    inventories=sorted(OUT.glob('artifact_logs_*.json'))
    if not inventories:raise ValueError('READ_MAINTENANCE_ARTIFACT_LOGS_FIRST')
    inventory_path=inventories[-1];inventory=json.loads(inventory_path.read_bytes())
    if inventory.get('schema')!='motomedic-maintenance-artifact-log-inventory-v1' or inventory.get('cloud_build_id')!=job:raise ValueError('EXACT_MAINTENANCE_ARTIFACT_JOB_REQUIRED')
    records={}
    for row in inventory['records']:
        name=row['artifact_file']
        if name not in ARTIFACT_NAMES or not re.fullmatch(r'[0-9]+',row.get('generation','')) or not re.fullmatch(r'[0-9a-f]{64}',row.get('sha256','')):
            raise ValueError('EXACT_MAINTENANCE_ARTIFACT_REFERENCE_REQUIRED')
        if name in records and any(records[name][key]!=row[key] for key in ('generation','sha256')):
            raise ValueError('CONFLICTING_MAINTENANCE_ARTIFACT_GENERATION')
        records[name]=row
    if not {'receipt.json','exit_status.json'}.issubset(records):raise ValueError('MAINTENANCE_EXIT_AND_RECEIPT_ARTIFACTS_REQUIRED')
    output=OUT/'hosted_runs'/job
    if output.exists():raise ValueError('NEVER_OVERWRITE_MAINTENANCE_DOWNLOADED_ARTIFACTS')
    output.mkdir(parents=True)
    from cloud.serving_artifacts import GCSReader,ObjectReference
    files={}
    for name,row in sorted(records.items()):
        reference=ObjectReference(uri='gs://'+cloud.BUCKET+'/engineering-acceptance/public-v10_3/'+job+'/'+name,
            generation=row['generation'],sha256=row['sha256'],maximum_bytes=2*1024*1024)
        GCSReader(token=cloud.token).fetch(reference,output/name)
        files[name]={'generation':row['generation'],'sha256':row['sha256'],'bytes':(output/name).stat().st_size}
    with (output/'download_inventory.json').open('x',encoding='utf-8') as target:
        json.dump({'schema':'motomedic-maintenance-download-inventory-v1','cloud_build_id':job,'files':files,
            'log_inventory_sha256':sha(inventory_path),'artifact_prefix':'engineering-acceptance/public-v10_3/'+job+'/',
            'provider_calls':0},target,indent=2,sort_keys=True);target.write('\n')
    return {'id':job,'files':files,'provider_calls':0}

if __name__=='__main__':
    import private_acceptance_console_v10_13_v2 as console
    cloud.token=console.token
    if sys.argv[1:]==['--check-only']:print(json.dumps({'actions':['prepare_source','upload_source','grant_source','submit','poll','logs','download'],
        'direct_provider_credentials_supplied_to_client':False,'no_automatic_execution':True,'exact_owner_query_scope_required':True,'provider_calls_by_operator':0}))
    elif len(sys.argv)==3 and sys.argv[1]=='prepare_source':print(json.dumps(prepare_source(sys.argv[2])))
    elif len(sys.argv)==2 and sys.argv[1] in ('upload_source','grant_source','submit','poll','logs','download'):print(json.dumps(globals()[sys.argv[1]]()))
    else:raise SystemExit('ONE_FIXED_OWNER_APPROVED_MAINTENANCE_ACTION_REQUIRED')
