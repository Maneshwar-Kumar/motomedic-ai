'use strict';
// A shell observer only. It has no answer submission or provider path.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium}=require('playwright');
const ROOT=path.resolve(__dirname,'../..');
const VERSION='motomedic-paused-preview-browser-v1';
const MESSAGE='Answering is paused while we finish checking the demo.';
const ORIGIN='https://motomedic-rider-ui-279945185781.us-central1.run.app';
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
function arg(name,fallback){const i=process.argv.indexOf(name);return i<0?fallback:process.argv[i+1];}
function requireValue(value,code){if(!value)throw Object.assign(new Error(code),{safeCode:code});}
async function scopeAndPause(page){
  const label='My motorcycle is a Himalayan BS6';
  const checkbox=page.getByRole('checkbox',{name:label,exact:true});
  await checkbox.waitFor({state:'visible',timeout:30000});
  requireValue(await checkbox.isEnabled(),'PREVIEW_SCOPE_CHECKBOX_DISABLED');
  if(!await checkbox.isChecked())await page.getByText(label,{exact:true}).click();
  await page.waitForFunction(()=>document.querySelector('input[type="checkbox"]')?.checked,{timeout:15000});
  requireValue(await checkbox.isChecked(),'PREVIEW_SCOPE_NOT_CONFIRMED');
  await page.getByText(MESSAGE,{exact:true}).waitFor({state:'visible',timeout:30000});
  const input=page.getByPlaceholder('Ask a question…',{exact:true})
    .or(page.getByRole('textbox',{name:'Ask a question…',exact:true})).first();
  await input.waitFor({state:'visible',timeout:30000});
  requireValue(await input.isDisabled(),'PREVIEW_QUESTION_INPUT_MUST_BE_DISABLED');
  return {scope_checkbox_checked:true,paused_message_visible:true,paused_message_sha256:sha(MESSAGE),question_input_disabled:true};
}
async function main(){
  const selfCheck=process.argv.includes('--self-check');
  requireValue(selfCheck||process.argv.includes('--execute-authorized'),'PREVIEW_EXECUTION_AUTHORIZATION_REQUIRED');
  requireValue(!process.argv.includes('--follow-up')&&!process.argv.includes('--answer'),'PREVIEW_CANNOT_SUBMIT_ANSWERS');
  const out=path.resolve(arg('--output',path.join(__dirname,'preview-output-v13-v1')));
  requireValue(out.startsWith(path.join(ROOT,'tmp')+path.sep),'PREVIEW_OUTPUT_MUST_STAY_IN_TMP');
  requireValue(!fs.existsSync(out),'VERSIONED_PREVIEW_OUTPUT_ALREADY_EXISTS');
  const release=arg('--release-sha','');
  requireValue(selfCheck||/^[a-f0-9]{64}$/.test(release),'FROZEN_PREVIEW_MANIFEST_SHA_REQUIRED');
  requireValue(selfCheck||arg('--url','')===ORIGIN,'EXACT_PREVIEW_ORIGIN_REQUIRED');
  const privateToken=(process.env.MOTOMEDIC_PRIVATE_TEST_ID_TOKEN||'').trim();
  delete process.env.MOTOMEDIC_PRIVATE_TEST_ID_TOKEN;
  requireValue(!privateToken||/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(privateToken),'PREVIEW_PRIVATE_TOKEN_INVALID');
  fs.mkdirSync(out,{recursive:true});
  const receipt={schema:VERSION,recorded_at_utc:new Date().toISOString(),script_sha256:sha(fs.readFileSync(__filename)),
    expected_runtime_policy:'open-manual-haiku-draft-verify-v10_13',runtime_policy_directly_observed:false,
    runtime_policy_evidence:'REQUIRES_CORRELATED_CURRENT_PRIVATE_READINESS_V2',
    execution:selfCheck?'SYNTHETIC_BROWSER_ABOUT_BLANK_ONLY':privateToken?'AUTHORIZED_PRIVATE_PAUSED_PREVIEW':'AUTHORIZED_PUBLIC_PAUSED_PREVIEW',
    expected_release_manifest_sha256:selfCheck?null:release,ui_turn_submissions:0,provider_calls_by_this_observer:0,
    raw_page_text_logged:false,cookie_values_logged:false,raw_network_or_token_values_saved:false,
    independent_factual_quality_acceptance:false,full_release_acceptance:false};
  let browser,page,stage='LAUNCH',errors=0,sockets=0,visitorStatus=null,requests=0,blockedAnswerPosts=0;
  try{
    browser=await chromium.launch({executablePath:arg('--browser','C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'),headless:true});
    receipt.browser_version=browser.version();
    const context=await browser.newContext({viewport:{width:1440,height:1100},deviceScaleFactor:1,serviceWorkers:'block',
      ...(privateToken&&!selfCheck?{extraHTTPHeaders:{Authorization:'Bearer '+privateToken}}:{})});
    await context.route('**/*',route=>{
      const request=route.request(),url=new URL(request.url());
      if(url.origin!==ORIGIN){return route.abort('blockedbyclient');}
      if(request.method()==='POST'&&url.pathname!=='/_visitor'){blockedAnswerPosts++;return route.abort('blockedbyclient');}
      return route.continue();
    });
    await context.routeWebSocket('**/*',socket=>{
      const url=new URL(socket.url());
      if(url.protocol!=='wss:'||'https://'+url.host!==ORIGIN||url.pathname!=='/_stcore/stream')
        return socket.close({code:1008,reason:'EXACT_PREVIEW_SHELL_SOCKET_REQUIRED'});
      socket.connectToServer();
    });
    page=await context.newPage();
    page.on('pageerror',()=>errors++);page.on('request',()=>requests++);
    page.on('websocket',socket=>{if(new URL(socket.url()).pathname==='/_stcore/stream')sockets++;});
    page.on('response',response=>{if(new URL(response.url()).pathname==='/_visitor')visitorStatus=response.status();});
    if(selfCheck){
      stage='OFFLINE_SYNTHETIC_PAUSE';await page.goto('about:blank');
      await page.setContent('<label><input type="checkbox" aria-label="My motorcycle is a Himalayan BS6"'+
        ' style="position:absolute;width:1px;height:1px;opacity:0"><span>My motorcycle is a Himalayan BS6</span></label>'+
        '<p>'+MESSAGE+'</p><textarea disabled placeholder="Ask a question…"></textarea>');
      Object.assign(receipt,await scopeAndPause(page));
      requireValue(requests===0,'SYNTHETIC_PREVIEW_EXTERNAL_REQUEST_FORBIDDEN');receipt.external_requests=0;
      // Prove that the same observer rejects an accidentally enabled entry.
      await page.evaluate(()=>document.querySelector('textarea').disabled=false);
      let rejected=false;try{await scopeAndPause(page);}catch(error){rejected=error.safeCode==='PREVIEW_QUESTION_INPUT_MUST_BE_DISABLED';}
      requireValue(rejected,'ENABLED_INPUT_NEGATIVE_CONTROL_FAILED');receipt.enabled_input_negative_control_rejected=true;
      receipt.status='PASS_ABOUT_BLANK_PAUSED_PREVIEW';
    }else{
      stage='HEALTH';const health=await page.goto(ORIGIN+'/health',{waitUntil:'domcontentloaded',timeout:30000});
      requireValue(health&&health.status()===200&&health.url()===ORIGIN+'/health'&&!health.request().redirectedFrom(),'PREVIEW_GATEWAY_HEALTH_OR_REDIRECT_INVALID');
      const value=JSON.parse(await health.text());requireValue(value.ready===true&&Object.keys(value).length===1,'PREVIEW_GATEWAY_HEALTH_SHAPE_INVALID');
      receipt.gateway_health={http_status:200,ready:true};stage='UI_NAVIGATION';
      await page.goto(ORIGIN,{waitUntil:'domcontentloaded',timeout:60000});
      await page.getByText('MotoMedic handles your routine queries for your Himalayan',{exact:true}).waitFor({timeout:120000});
      stage='PROOF_COOKIE_SOCKET';
      const visitor=(await context.cookies(ORIGIN)).find(value=>value.name==='__Host-motomedic-visitor');
      requireValue(visitor&&visitor.secure&&visitor.httpOnly&&visitor.sameSite==='Lax'&&visitor.path==='/'&&visitorStatus===200&&sockets>0,'PREVIEW_PROOF_COOKIE_OR_SOCKET_MISSING');
      receipt.admission={visitor_proof_status:visitorStatus,cookie_secure:true,cookie_http_only:true,cookie_same_site:'Lax',streamlit_socket_opened:true};
      stage='UI_SCOPE_AND_PAUSE';Object.assign(receipt,await scopeAndPause(page));
      requireValue(blockedAnswerPosts===0,'PREVIEW_UI_ATTEMPTED_NONPROOF_POST');
      receipt.no_horizontal_overflow=await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth);
      await page.screenshot({path:path.join(out,'paused_preview.png'),fullPage:true});
      receipt.screenshot='paused_preview.png';receipt.public_origin=ORIGIN;
      receipt.status=privateToken?'PASS_PRIVATE_PAUSED_SHELL':'PASS_PUBLIC_PAUSED_SHELL';
    }
    requireValue(errors===0,'PREVIEW_BROWSER_PAGE_ERROR');
  }catch(error){receipt.status='FAIL';receipt.failure_stage=stage;receipt.failure_code=error.safeCode||(error.name==='TimeoutError'?'PREVIEW_WAIT_TIMEOUT':'PREVIEW_BROWSER_EXECUTION_FAILED');}
  finally{receipt.page_error_count=errors;receipt.streamlit_socket_count=sockets;receipt.blocked_nonproof_posts=blockedAnswerPosts;
    if(browser)await browser.close();fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');}
  console.log(JSON.stringify(receipt));return receipt.status.startsWith('PASS')?0:1;
}
main().then(code=>process.exitCode=code).catch(()=>{console.log(JSON.stringify({schema:VERSION,status:'FAIL',failure_code:'PREVIEW_ARGUMENT_OR_RUNTIME_INVALID'}));process.exitCode=1;});
