"""Separate owner-waived functional promotion; legacy factual gates stay intact."""
from copy import deepcopy
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'));sys.path.insert(0,str(ROOT/'tmp/public_evaluator'))
import public_cloud_run_v10_13_v2 as run
import private_acceptance_console_v10_13_v2 as console
import rollback_public_v10_13 as rollback
import public_core_inspection_v13_v3 as core
import public_ui_preview_v13_v2 as preview
from hosted_client_v10_13_v2 import firestore_value
from cloud.grounded_generation.token_ceiling import GRANT_DOCUMENT,resolve_token_ceiling
cloud=run.cloud
OUT=cloud.OUT/'haiku_v10_13_helpers/functional_ui_promotion_v1'
UI='motomedic-rider-ui'
ENABLED=UI+'-v10-13-functional-enabled'
FLAG='MOTOMEDIC_RIDER_ANSWERS_ENABLED'
WAIVER=cloud.OUT/'public_review/owner_functional_acceptance_scope_v1.json'
WAIVER_SHA='19371f8c30839754cfd5233e5db68efc88589f25313b96e67aee3e72c112248d'
ACCEPTANCE=cloud.OUT/'haiku_v10_13_runtime/functional_operational_acceptance_v1.json'
CASE_IDS=('EVAL_DIRECT_01','EVAL_USB_02','EVAL_FOLLOWUP_03','EVAL_TOPIC_TABLE_04','EVAL_PARTIAL_05','EVAL_UNSUPPORTED_06')
PRIMARY='grounded-primary-nonrecurring-v1'
MONEY='owner-haiku-fallback-20261011-validation-v1'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def write(name,value):
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/name).open('x',encoding='utf-8') as target:json.dump(value,target,indent=2,sort_keys=True);target.write('\n')
def absent(*names):
    if any((OUT/name).exists() for name in names):raise ValueError('NEVER_OVERWRITE_FUNCTIONAL_PROMOTION_RECEIPT')

def file_reference(path):return {'path':path.relative_to(ROOT).as_posix(),'sha256':sha(path)}
def bound_file(reference):
    if type(reference)is not dict or type(reference.get('path'))is not str or not re.fullmatch(r'[0-9a-f]{64}',reference.get('sha256','')):
        raise ValueError('EXACT_BOUND_FUNCTIONAL_RECEIPT_REFERENCE_REQUIRED')
    path=(ROOT/reference['path']).resolve()
    if not path.is_relative_to(cloud.OUT) or sha(path)!=reference['sha256']:
        raise ValueError('FUNCTIONAL_RECEIPT_PATH_OR_HASH_CHANGED')
    return path,json.loads(path.read_bytes())

def owner_waiver(binding):
    if sha(WAIVER)!=WAIVER_SHA:raise ValueError('EXACT_DIRECT_OWNER_FUNCTIONAL_WAIVER_CHANGED')
    value=json.loads(WAIVER.read_bytes())
    true=('owner_authorized','independent_manual_review_waived_for_present_functional_demo','immutable_source_bindings_required',
        'runtime_semantic_verifier_required','answering_enablement_requires_functional_probe')
    false=('independent_manual_review_required','independent_factual_quality_acceptance','human_factual_signoff',
        'existing_scoped_source_approval_waived','source_content_approval_changed','runtime_semantic_verifier_bypass_authorized')
    candidate=value.get('frozen_candidate',{})
    if (value.get('schema')!='motomedic-owner-functional-demo-acceptance-scope-v1' or value.get('authority')!='DIRECT_OWNER_INSTRUCTION' or
        any(value.get(key)is not True for key in true) or any(value.get(key)is not False for key in false) or
        candidate.get('serving_manifest_sha256')!=binding['serving_manifest_sha256'] or candidate.get('runtime_lock')!=binding['runtime_lock']):
        raise ValueError('EXACT_CURRENT_OWNER_WAIVER_WITH_RUNTIME_VERIFIER_REQUIRED')
    return file_reference(WAIVER)

def require_functional_contract(value,binding,waiver,source_commit):
    true=('runtime_semantic_verifier_required','functional_demo_operational_acceptance','saved_stream_recovery_identical',
        'completed_operation_boundary_checks','permanent_charges_preserved','unchanged_attempt_usd_inr_guards')
    false=('independent_manual_review_required','independent_manual_review_performed','independent_factual_quality_acceptance',
        'human_signoff','runtime_semantic_verifier_bypassed','public_browser_acceptance')
    if (value.get('schema')!='motomedic-owner-waived-functional-demo-acceptance-v1' or
        value.get('classification')!='ACTUAL_HOSTED_FUNCTIONAL_OPERATIONAL_ACCEPTANCE' or value.get('decision')!='FUNCTIONAL_DEMO_ACCEPTED' or
        value.get('serving_manifest_sha256')!=binding['serving_manifest_sha256'] or value.get('runtime_lock')!=binding['runtime_lock'] or
        value.get('images')!=binding['images'] or value.get('source_commit')!=source_commit or value.get('owner_waiver')!=waiver or
        any(value.get(key)is not True for key in true) or any(value.get(key)is not False for key in false) or
        type(value.get('delivered_case_count'))is not int or value['delivered_case_count']!=6 or
        set(value.get('case_files',{}))!=set(CASE_IDS) or
        value.get('role_cache_creation_and_reads_observed')!={'private_draft':True,'semantic_verifier':True}):
        raise ValueError('FRESH_SIX_CASE_DELIVERY_CACHE_FUNCTIONAL_ACCEPTANCE_REQUIRED')
    return True

def require_delivery_cache_audit(audit,binding,hosted_sha):
    proofs=audit.get('current_role_cache_usage_proofs',{})
    if (audit.get('schema')!='motomedic-haiku-functional-delivery-cache-audit-v3' or audit.get('passed')is not True or
        audit.get('serving_manifest_sha256')!=binding['serving_manifest_sha256'] or audit.get('runtime_lock')!=binding['runtime_lock'] or
        audit.get('hosted_receipt_sha256')!=hosted_sha or audit.get('provider_calls_by_auditor')!=0 or audit.get('cloud_mutations')!=0 or
        audit.get('source_factual_quality_acceptance')is not False or audit.get('public_browser_acceptance')is not False or
        audit.get('permanent_ledger_proof',{}).get('passed')is not True or
        set(proofs)!={'private_draft','semantic_verifier'} or any(
            proofs[role].get('current_role_creation_then_read_usage_proven')is not True for role in proofs)):
        raise ValueError('ACTUAL_CURRENT_ROLE_DELIVERY_CACHE_AUDIT_V3_REQUIRED')
    return True

def functional_evidence(binding):
    value=json.loads(ACCEPTANCE.read_bytes());waiver=owner_waiver(binding)
    image_binding=json.loads((cloud.OUT/'hosted_image_binding_v10_13.json').read_bytes())
    require_functional_contract(value,binding,waiver,image_binding['source_commit'])
    path,hosted=bound_file(value['hosted_receipt']);audit_path,audit=bound_file(value['delivery_cache_audit'])
    require_delivery_cache_audit(audit,binding,sha(path))
    job=value['hosted_receipt'].get('cloud_build_id')
    if not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',job or '') or path!=cloud.OUT/'hosted_runs'/job/'receipt.json':
        raise ValueError('EXACT_ACTUAL_HOSTED_FUNCTIONAL_JOB_REQUIRED')
    submission_path,submission=bound_file(value['evaluator_submission'])
    source_path,source=bound_file(value['evaluator_source'])
    if (submission['operation']['metadata']['build']['id']!=job or submission['config']['source']['storageSource']!={
        'bucket':cloud.BUCKET,'object':source['object'],'generation':source['generation']} or
        source['serving_manifest_sha256']!=binding['serving_manifest_sha256'] or source['runtime_lock']!=binding['runtime_lock'] or
        hosted.get('cloud_build_id')!=job or hosted.get('runtime_lock')!=binding['runtime_lock'] or
        hosted.get('engineering_transport_and_route_passed')is not True or hosted.get('case_count')!=6 or
        hosted.get('engineering_completed_cases')!=6 or hosted.get('stopped_early')is not False or
        hosted.get('post_retries')!=0 or hosted.get('allocation_reset')is not False or hosted.get('allocation_refund')is not False or
        hosted.get('completed_operation_boundary_checks')is not True or hosted.get('case_files')!=value['case_files']):
        raise ValueError('ACTUAL_HOSTED_FUNCTIONAL_COMPLETION_SOURCE_BINDING_CHANGED')
    inventory_path=path.parent/'download_inventory.json';inventory=json.loads(inventory_path.read_bytes())
    if inventory.get('cloud_build_id')!=job or inventory['files']['receipt.json']['sha256']!=sha(path):
        raise ValueError('ACTUAL_HOSTED_RECEIPT_DOWNLOAD_BINDING_CHANGED')
    for case in CASE_IDS:
        case_path=path.parent/(case+'.json');expected=value['case_files'][case]
        if sha(case_path)!=expected or inventory['files'][case+'.json']['sha256']!=expected:
            raise ValueError('ACTUAL_FUNCTIONAL_CASE_ARTIFACT_HASH_CHANGED')
        item=json.loads(case_path.read_bytes())
        if (item.get('case_id')!=case or item.get('status')!='SAVED_STREAMED_RECOVERED' or item.get('expected_route_matched')is not True or
            item.get('exact_saved_stream')is not True or item.get('exact_recovered_view')is not True or item.get('error') or item.get('post_retries')!=0):
            raise ValueError('ACTUAL_FUNCTIONAL_CASE_DELIVERY_NOT_COMPLETE')
    return {'acceptance':file_reference(ACCEPTANCE),'owner_waiver':waiver,'hosted_receipt':value['hosted_receipt'],
        'delivery_cache_audit':value['delivery_cache_audit'],'download_inventory':file_reference(inventory_path),
        'evaluator_submission':value['evaluator_submission'],'evaluator_source':value['evaluator_source'],
        'case_files':value['case_files'],'source_commit':image_binding['source_commit'],
        'independent_factual_quality_acceptance':False,'public_browser_acceptance':False}

def ledger_state():
    values={};hashes={};immutable={}
    for name in (PRIMARY,MONEY,GRANT_DOCUMENT,'grounded-provider-global-v1'):
        body=run.api('GET','https://firestore.googleapis.com/v1/projects/'+cloud.PROJECT+'/databases/(default)/documents/arm_a_usage/'+name)
        fields=body['fields'];hashes[name]=rollback.digest(fields)
        if name!='grounded-provider-global-v1':values[name]={key:firestore_value(value) for key,value in fields.items()}
        mutable={PRIMARY:{'reserved_attempts','reserved_tokens'},MONEY:{'reserved_nanodollars','reservation_count'},
            GRANT_DOCUMENT:set(),'grounded-provider-global-v1':{'events','expires_at'}}[name]
        immutable[name]=rollback.digest({key:value for key,value in fields.items() if key not in mutable})
    ceiling,authorization=resolve_token_ceiling(values[PRIMARY],values[GRANT_DOCUMENT])
    if ceiling!=2000000 or values[PRIMARY].get('maximum_attempts')!=100 or values[MONEY].get('maximum_nanodollars')!=1000000000:
        raise ValueError('EXACT_APPROVED_TOKEN_ATTEMPT_SHARED_DOLLAR_GUARDS_REQUIRED')
    return {'maximum_tokens':ceiling,'token_ceiling_authorization':authorization,'full_document_field_sha256':hashes,
        'immutable_non_charge_field_sha256':immutable,
        'reserved_attempts':values[PRIMARY]['reserved_attempts'],'reserved_tokens':values[PRIMARY]['reserved_tokens'],
        'reserved_nanodollars':values[MONEY]['reserved_nanodollars'],'reservation_count':values[MONEY]['reservation_count']}

def require_retained_ledger(before,after,*,exact_charges=False):
    if (before.get('maximum_tokens')!=after.get('maximum_tokens') or before.get('token_ceiling_authorization')!=after.get('token_ceiling_authorization') or
        before.get('immutable_non_charge_field_sha256')!=after.get('immutable_non_charge_field_sha256')):
        raise ValueError('PRIMARY_GRANT_CAPS_OR_OTHER_LEDGER_BINDINGS_CHANGED')
    for key,limit in (('reserved_attempts',100),('reserved_tokens',2000000),('reserved_nanodollars',1000000000),('reservation_count',None)):
        left,right=before.get(key),after.get(key)
        if type(left)is not int or type(right)is not int or not 0<=left<=right or (limit is not None and right>limit) or (exact_charges and left!=right):
            raise ValueError('HISTORICAL_CHARGES_RESET_REFUNDED_OR_EXCEEDED')
    return True

def flag(configuration,expected):
    containers=configuration.get('containers',[])
    if len(containers)!=1:raise ValueError('ONE_EXACT_UI_CONTAINER_REQUIRED')
    rows=containers[0].get('env',[]);matches=[row for row in rows if row.get('name')==FLAG]
    if len({row['name'] for row in rows})!=len(rows) or len(matches)!=1 or matches[0]!={'name':FLAG,'value':expected}:
        raise ValueError('EXACT_PLAIN_UI_ANSWER_ENABLEMENT_FLAG_REQUIRED')
    return matches[0]

def enabled_configuration(paused):
    result=deepcopy(paused);flag(result,'false')['value']='true';return result

def require_only_flag_delta(paused,enabled):
    flag(paused,'false');flag(enabled,'true')
    if enabled_configuration(paused)!=enabled:raise ValueError('ONLY_FALSE_TO_TRUE_UI_FLAG_DELTA_ALLOWED')
    return True

def candidate_template(paused_template,paused_configuration):
    configuration=enabled_configuration(paused_configuration)
    # launchStage is derived Revision output / Service-level input. It is not
    # a RevisionTemplate field, and remains part of the full actual hash check.
    # https://docs.cloud.google.com/run/docs/reference/rest/v2/projects.locations.services#RevisionTemplate
    writable={'scaling','vpcAccess','timeout','serviceAccount','containers','volumes','executionEnvironment',
        'encryptionKey','maxInstanceRequestConcurrency','serviceMesh','encryptionKeyRevocationAction',
        'encryptionKeyShutdownDuration','sessionAffinity','nodeSelector','gpuZonalRedundancyDisabled'}
    if set(configuration)-writable-{'launchStage'}:raise ValueError('UNREVIEWED_REVISION_MATERIAL_TEMPLATE_FIELD')
    template=deepcopy(paused_template)
    for key,value in configuration.items():
        if key in writable:template[key]=deepcopy(value)
    template['revision']=ENABLED
    return template,configuration

def ui_service_configuration(service):
    keys=('ingress','launchStage','binaryAuthorization','scaling','invokerIamDisabled','defaultUriDisabled',
        'iapEnabled','description','labels','annotations','customAudiences','buildConfig')
    return {key:deepcopy(service[key]) for key in keys if key in service}

def current_ui(binding):
    service=run.api('GET',run.PREFIX+UI);rollback.require_service(UI,service,binding)
    revision=rollback.routed_revision(service);actual=run.api('GET',run.PREFIX+UI+'/revisions/'+revision)
    rollback.require_ready_revision(actual,revision)
    configuration=rollback.revision_configuration(actual,service['template'])
    flag(configuration,'false')
    return service,{'revision':revision,'template':deepcopy(service['template']),'revision_configuration':configuration,
        'revision_configuration_sha256':rollback.digest(configuration),'service_scaling':deepcopy(service.get('scaling',{})),
        'service_configuration':ui_service_configuration(service)}

def policies():
    result={}
    for name in core.SERVICES+(UI,):
        value=run.api('GET',run.PREFIX+name+':getIamPolicy?options.requestedPolicyVersion=3')
        rows=core.policy_rows(value)
        if any('allAuthenticatedUsers' in row.get('members',[]) for row in value.get('bindings',[])) or not any(
            row.get('role')=='roles/run.invoker' and not row.get('condition') and 'allUsers' in row.get('members',[]) for row in value.get('bindings',[])):
            raise ValueError('EXACT_EXISTING_PUBLIC_INVOKER_SCOPE_REQUIRED')
        result[name]={'normalized_binding_sha256':rollback.digest(rows),'etag':value.get('etag'),'version':value.get('version',1)}
    return result

def core_rows(binding):
    rows={}
    for name in core.SERVICES:
        service,row=core.actual_revision(name,binding)
        row['service_configuration']=ui_service_configuration(service);rows[name]=row
    return rows

def prepare(guard_path):
    absent('initial.json','candidate_submission.json')
    binding,_=rollback.release();evidence=functional_evidence(binding);guard=preview.guard_receipt(guard_path)
    service,row=current_ui(binding)
    snapshot={'schema':'motomedic-owner-waived-functional-ui-promotion-initial-v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'binding':binding,'functional_evidence':evidence,'guard':guard,'ui':row,'core':core_rows(binding),'public_iam':policies(),
        'provider_ledger':ledger_state(),'independent_factual_quality_acceptance':False,'provider_calls':0,'cloud_writes':0}
    write('initial.json',snapshot);return {'prepared':True,'paused_revision':row['revision'],'enabled_revision':ENABLED,'provider_calls':0}

def check_unchanged(initial,*,exact_charges=False):
    binding,_=rollback.release()
    if binding!=initial['binding'] or functional_evidence(binding)!=initial['functional_evidence']:
        raise ValueError('FUNCTIONAL_PROMOTION_FROZEN_OR_ACCEPTANCE_BINDING_CHANGED')
    if preview.guard_receipt(initial['guard']['path'])!=initial['guard']:
        raise ValueError('EXACT_FRESH_GUARD_RECEIPT_CHANGED')
    if core_rows(binding)!=initial['core'] or policies()!=initial['public_iam']:
        raise ValueError('CORE_CONFIGURATION_OR_PUBLIC_IAM_CHANGED_DURING_UI_PROMOTION')
    service=run.api('GET',run.PREFIX+UI)
    if ui_service_configuration(service)!=initial['ui']['service_configuration']:
        raise ValueError('UI_INGRESS_IAM_CHECK_OR_OTHER_SERVICE_CONFIGURATION_CHANGED')
    require_retained_ledger(initial['provider_ledger'],ledger_state(),exact_charges=exact_charges)
    return binding

def create():
    absent('candidate_submission.json');initial=read('initial.json');binding=check_unchanged(initial,exact_charges=True)
    service,row=current_ui(binding)
    if row!=initial['ui']:raise ValueError('EXACT_PAUSED_UI_BASELINE_CHANGED')
    template,configuration=candidate_template(row['template'],row['revision_configuration'])
    request={'template':template,'traffic':[{'type':'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION','revision':row['revision'],'percent':100}]}
    if not service.get('etag'):raise ValueError('UI_CREATION_CONCURRENCY_ETAG_REQUIRED')
    request['etag']=service['etag']
    # Journal exact reviewed intent before the single UI-only PATCH.
    absent('candidate_intent.json');write('candidate_intent.json',{'request':request,'enabled_configuration':configuration,
        'paused_revision':row['revision'],'initial_sha256':sha(OUT/'initial.json'),'provider_calls':0})
    operation=run.api('PATCH',run.PREFIX+UI+'?updateMask=template,traffic',request)
    write('candidate_submission.json',{'operation':operation,'request':request,'provider_calls':0,'core_or_iam_or_billing_changes':False})
    return {'enabled_revision_created':ENABLED,'traffic_remains_paused':True,'provider_calls':0}

def candidate_status():
    initial=read('initial.json');binding=check_unchanged(initial);saved=read('candidate_submission.json')
    operation=run.api('GET','https://run.googleapis.com/v2/'+saved['operation']['name'])
    if operation.get('done')is not True:return {'candidate_ready':False,'provider_calls':0}
    if operation.get('error'):raise ValueError('FUNCTIONAL_ENABLED_UI_CREATION_FAILED')
    service=run.api('GET',run.PREFIX+UI);rollback.require_service(UI,service,binding)
    if (rollback.routed_revision(service)!=initial['ui']['revision'] or service.get('latestCreatedRevision','').split('/')[-1]!=ENABLED or
        service['template'].get('revision','').split('/')[-1]!=ENABLED or service.get('scaling',{})!=initial['ui']['service_scaling']):
        raise ValueError('ENABLED_UI_MUST_BE_NEW_WITH_TRAFFIC_STILL_PAUSED')
    actual=run.api('GET',run.PREFIX+UI+'/revisions/'+ENABLED)
    ready=[row for row in actual.get('conditions',[]) if row.get('type')=='Ready']
    if len(ready)!=1 or ready[0].get('state')!='CONDITION_SUCCEEDED':return {'candidate_ready':False,'provider_calls':0}
    rollback.require_ready_revision(actual,ENABLED)
    configuration=rollback.revision_configuration(actual,saved['request']['template'])
    require_only_flag_delta(initial['ui']['revision_configuration'],configuration)
    row={'revision':ENABLED,'template':saved['request']['template'],'revision_configuration':configuration,
        'revision_configuration_sha256':rollback.digest(configuration),'service_scaling':deepcopy(service.get('scaling',{}))}
    value={'schema':'motomedic-functional-ui-enabled-candidate-v1','binding':binding,'ui':row,'only_answer_flag_changed':True,
        'traffic_still_paused':True,'provider_calls':0,'independent_factual_quality_acceptance':False}
    if (OUT/'candidate_ready.json').exists():
        if read('candidate_ready.json')!=value:raise ValueError('IMMUTABLE_ENABLED_UI_CANDIDATE_RECEIPT_CHANGED')
    else:write('candidate_ready.json',value)
    return {'candidate_ready':True,'revision':ENABLED,'provider_calls':0}

def route(stage):
    if stage not in ('enabled','paused_rollback','enabled_restore'):raise ValueError('EXACT_FUNCTIONAL_UI_ROUTING_STAGE_REQUIRED')
    absent(stage+'_traffic.json',stage+'_intent.json');initial=read('initial.json');binding=check_unchanged(initial)
    if stage=='paused_rollback':read('enabled_health.json')
    if stage=='enabled_restore':read('paused_rollback_health.json');require_paused_browser()
    candidate=read('candidate_ready.json')
    row=initial['ui'] if stage=='paused_rollback' else candidate['ui']
    service=run.api('GET',run.PREFIX+UI);rollback.require_service(UI,service,binding)
    expected_from=initial['ui']['revision'] if stage in ('enabled','enabled_restore') else ENABLED
    if rollback.routed_revision(service)!=expected_from:raise ValueError('FUNCTIONAL_UI_ROUTE_TRANSITION_SOURCE_CHANGED')
    actual=run.api('GET',run.PREFIX+UI+'/revisions/'+row['revision']);rollback.require_ready_revision(actual,row['revision'])
    if rollback.digest(rollback.revision_configuration(actual,row['template']))!=row['revision_configuration_sha256']:
        raise ValueError('EXACT_FUNCTIONAL_UI_ROUTE_TARGET_CONFIGURATION_CHANGED')
    if not service.get('etag'):raise ValueError('UI_TRAFFIC_CONCURRENCY_ETAG_REQUIRED')
    request={'etag':service['etag'],'traffic':[{'type':'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION','revision':row['revision'],'percent':100}]}
    write(stage+'_intent.json',{'request':request,'stage':stage,'provider_calls':0})
    operation=run.api('PATCH',run.PREFIX+UI+'?updateMask=traffic',request)
    write(stage+'_traffic.json',{'request':request,'operation':operation,'stage':stage,'binding':binding,'provider_calls':0})
    return {'stage':stage,'target_revision':row['revision'],'provider_calls':0}

def health(stage):
    if stage not in ('enabled','paused_rollback','enabled_restore'):raise ValueError('EXACT_FUNCTIONAL_UI_HEALTH_STAGE_REQUIRED')
    absent(stage+'_health.json');initial=read('initial.json');binding=check_unchanged(initial)
    saved=read(stage+'_traffic.json');operation=run.api('GET','https://run.googleapis.com/v2/'+saved['operation']['name'])
    if operation.get('done')is not True or operation.get('error'):return {'stage':stage,'health_ready':False,'provider_calls':0}
    row=initial['ui'] if stage=='paused_rollback' else read('candidate_ready.json')['ui']
    service=run.api('GET',run.PREFIX+UI);rollback.require_service(UI,service,binding)
    if rollback.routed_revision(service)!=row['revision'] or service.get('scaling',{})!=initial['ui']['service_scaling']:
        raise ValueError('FUNCTIONAL_UI_ACTUAL_TRAFFIC_OR_SERVICE_SCALING_CHANGED')
    actual=run.api('GET',run.PREFIX+UI+'/revisions/'+row['revision']);rollback.require_ready_revision(actual,row['revision'])
    configuration=rollback.revision_configuration(actual,row['template'])
    if rollback.digest(configuration)!=row['revision_configuration_sha256']:raise ValueError('FUNCTIONAL_UI_EXACT_ROUTED_MATERIAL_CONFIGURATION_CHANGED')
    flag(configuration,'false' if stage=='paused_rollback' else 'true')
    result=rollback.get_health(UI,service,binding,url=preview.URL)
    check_unchanged(initial)
    write(stage+'_health.json',{'schema':'motomedic-functional-ui-routed-health-v1','stage':stage,'binding':binding,
        'revision':row['revision'],'revision_configuration_sha256':row['revision_configuration_sha256'],'anonymous_ui_health':result,
        'core_and_iam_unchanged':True,'provider_ledger_after':ledger_state(),'permanent_grant_caps_and_charges_retained':True,
        'legitimate_bounded_public_usage_does_not_disable_rollback':True,'provider_calls_by_health_check':0,'independent_factual_quality_acceptance':False})
    return {'stage':stage,'health_ready':True,'revision':row['revision'],'provider_calls':0}

def browser_paths(mode):
    if mode not in ('paused','enabled'):raise ValueError('EXACT_FUNCTIONAL_BROWSER_MODE_REQUIRED')
    return ROOT/('tmp/public_evaluator/functional-v13-'+mode+'-browser-v1')

def require_paused_browser():
    path=browser_paths('paused')/'receipt.json';value=json.loads(path.read_bytes())
    initial=read('initial.json')
    if (value.get('status')!='PASS_PUBLIC_PAUSED_SHELL' or value.get('expected_release_manifest_sha256')!=initial['binding']['serving_manifest_sha256'] or
        value.get('ui_turn_submissions')!=0 or value.get('provider_calls_by_this_observer')!=0 or
        value.get('question_input_disabled')is not True or value.get('paused_message_visible')is not True):
        raise ValueError('ACTUAL_ANONYMOUS_PAUSED_ROLLBACK_BROWSER_REQUIRED')
    record=read('paused_browser.json')
    if record['browser_receipt_sha256']!=sha(path):raise ValueError('PAUSED_ROLLBACK_BROWSER_RECEIPT_CHANGED')
    return file_reference(path)

def require_routed_ui(stage,initial,binding):
    row=initial['ui'] if stage=='paused_rollback' else read('candidate_ready.json')['ui']
    service=run.api('GET',run.PREFIX+UI);rollback.require_service(UI,service,binding)
    if rollback.routed_revision(service)!=row['revision']:
        raise ValueError('EXACT_BROWSER_ROUTED_UI_REVISION_REQUIRED')
    actual=run.api('GET',run.PREFIX+UI+'/revisions/'+row['revision']);rollback.require_ready_revision(actual,row['revision'])
    configuration=rollback.revision_configuration(actual,row['template'])
    if rollback.digest(configuration)!=row['revision_configuration_sha256']:
        raise ValueError('EXACT_BROWSER_ROUTED_UI_CONFIGURATION_CHANGED')
    flag(configuration,'false' if stage=='paused_rollback' else 'true')
    return {'revision':row['revision'],'revision_configuration_sha256':row['revision_configuration_sha256']}

def browser(mode):
    if mode not in ('paused','enabled'):raise ValueError('EXACT_FUNCTIONAL_BROWSER_MODE_REQUIRED')
    target=mode+'_browser.json';absent(target);initial=read('initial.json')
    stage='paused_rollback' if mode=='paused' else 'enabled_restore';read(stage+'_health.json')
    binding=check_unchanged(initial);require_routed_ui(stage,initial,binding);output=browser_paths(mode)
    if output.exists():raise ValueError('NEVER_OVERWRITE_FUNCTIONAL_BROWSER_OUTPUT')
    bundle=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node'
    environment=os.environ.copy();environment['NODE_PATH']=str(bundle/'node_modules');environment.pop('MOTOMEDIC_PRIVATE_TEST_ID_TOKEN',None)
    script=ROOT/('tmp/public_evaluator/browser_preview_v13_v1.cjs' if mode=='paused' else 'tmp/public_evaluator/browser_acceptance_v13.cjs')
    args=[str(bundle/'bin/node.exe'),str(script),'--execute-authorized','--url',preview.URL,
        '--release-sha',initial['binding']['serving_manifest_sha256'],'--output',str(output)]
    before=ledger_state();result=subprocess.run(args,cwd=ROOT,env=environment,timeout=300 if mode=='paused' else 2800)
    receipt_path=output/'receipt.json'
    if not receipt_path.exists():raise ValueError('FUNCTIONAL_BROWSER_RECEIPT_MISSING')
    value=json.loads(receipt_path.read_bytes());after=ledger_state()
    if result.returncode or value.get('expected_release_manifest_sha256')!=initial['binding']['serving_manifest_sha256']:
        raise ValueError('ACTUAL_FUNCTIONAL_PUBLIC_BROWSER_DID_NOT_PASS')
    require_retained_ledger(before,after)
    if mode=='paused':
        if value.get('status')!='PASS_PUBLIC_PAUSED_SHELL' or value.get('ui_turn_submissions')!=0 or value.get('provider_calls_by_this_observer')!=0:
            raise ValueError('PAUSED_ROLLBACK_BROWSER_CREATED_PROVIDER_WORK')
    elif value.get('status')!='PASS_UI_BOUNDARY_OBSERVATION' or value.get('ui_turn_submissions')!=1 or len(value.get('turns',[]))!=1:
        raise ValueError('ACTUAL_ANONYMOUS_DIRECT_BROWSER_REQUIRED')
    check_unchanged(initial);routed=require_routed_ui(stage,initial,binding)
    write(target,{'schema':'motomedic-functional-ui-browser-evidence-v1','mode':mode,'browser_receipt_path':receipt_path.relative_to(ROOT).as_posix(),
        'browser_receipt_sha256':sha(receipt_path),'script_sha256':sha(script),'provider_ledger_before':before,'provider_ledger_after':after,
        'independent_factual_quality_acceptance':False,'human_signoff':False,'provider_work_forbidden':mode=='paused',
        'public_browser_passed':True,'routed_ui_after_browser':routed,'core_and_public_iam_unchanged_after_browser':True,
        'provider_counts_for_enabled_browser_require_correlated_operation_audit':mode=='enabled'})
    return {'mode':mode,'public_browser_passed':True,'independent_factual_quality_acceptance':False}

if __name__=='__main__':
    cloud.token=console.token
    actions=('prepare','create','candidate_status','route','health','browser')
    if sys.argv[1:]==['--check-only']:print(json.dumps({'actions':actions,'cloud_actions_executed':False,'provider_calls':0,
        'legacy_manual_acceptance_gate_unchanged':True,'owner_waiver_exact_sha256':WAIVER_SHA,
        'independent_factual_quality_acceptance':False,'only_ui_answer_flag_change_authorized':True}))
    elif len(sys.argv)==3 and sys.argv[1]in ('prepare','route','health','browser'):print(json.dumps(globals()[sys.argv[1]](sys.argv[2])))
    elif len(sys.argv)==2 and sys.argv[1]in ('create','candidate_status'):print(json.dumps(globals()[sys.argv[1]]()))
    else:raise SystemExit('ONE_EXACT_FUNCTIONAL_UI_PROMOTION_ACTION_REQUIRED')
