"""Synthetic functional promotion boundaries; no cloud or provider calls."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tmp'))
import functional_ui_promotion_v13_v1 as promote

class FunctionalPromotionTests(unittest.TestCase):
    def configuration(self):
        # Actual reviewed v13 UI material; Service-derived launchStage stays bound.
        ready=json.loads((promote.cloud.OUT/'private_readiness_v10_13_v2.json').read_bytes())
        return deepcopy(ready['services'][promote.UI]['revision_configuration'])
    def template(self,configuration):
        result=deepcopy(configuration);result.pop('launchStage',None)
        result['revision']='paused-exact';result['annotations']={'preserved':'exact'}
        return result
    def ledger(self):
        return {'maximum_tokens':2000000,'token_ceiling_authorization':{'scope_sha256':'a'*64},
            'immutable_non_charge_field_sha256':{'primary':'a'*64,'shared':'b'*64,'grant':'c'*64,'global':'d'*64},
            'reserved_attempts':10,'reserved_tokens':500000,'reserved_nanodollars':200000000,'reservation_count':4}
    def binding(self):
        return {'serving_manifest_sha256':'a'*64,'runtime_lock':'b'*64,'images':{'backend':'backend@sha256:'+'c'*64,'ui':'ui@sha256:'+'d'*64}}
    def acceptance(self):
        binding=self.binding();waiver={'path':'exact/waiver','sha256':'e'*64}
        true=('runtime_semantic_verifier_required','functional_demo_operational_acceptance','saved_stream_recovery_identical',
            'completed_operation_boundary_checks','permanent_charges_preserved','unchanged_attempt_usd_inr_guards')
        false=('independent_manual_review_required','independent_manual_review_performed','independent_factual_quality_acceptance',
            'human_signoff','runtime_semantic_verifier_bypassed','public_browser_acceptance')
        value={'schema':'motomedic-owner-waived-functional-demo-acceptance-v1','classification':'ACTUAL_HOSTED_FUNCTIONAL_OPERATIONAL_ACCEPTANCE',
            'decision':'FUNCTIONAL_DEMO_ACCEPTED','serving_manifest_sha256':binding['serving_manifest_sha256'],
            'runtime_lock':binding['runtime_lock'],'images':binding['images'],'source_commit':'commit',
            'owner_waiver':waiver,'delivered_case_count':6,'case_files':{case:'f'*64 for case in promote.CASE_IDS},
            'role_cache_creation_and_reads_observed':{'private_draft':True,'semantic_verifier':True}}
        value.update({key:True for key in true});value.update({key:False for key in false})
        return value,binding,waiver
    def audit(self):
        binding=self.binding()
        return {'schema':'motomedic-haiku-functional-delivery-cache-audit-v3','passed':True,
            'serving_manifest_sha256':binding['serving_manifest_sha256'],'runtime_lock':binding['runtime_lock'],
            'hosted_receipt_sha256':'e'*64,'provider_calls_by_auditor':0,'cloud_mutations':0,
            'source_factual_quality_acceptance':False,'public_browser_acceptance':False,'permanent_ledger_proof':{'passed':True},
            'current_role_cache_usage_proofs':{role:{'current_role_creation_then_read_usage_proven':True}
                for role in ('private_draft','semantic_verifier')},
            'role_cache_proofs':{role:{'exact_role_prefix_creation_then_read_proven':False}
                for role in ('private_draft','semantic_verifier')}}
    def test_candidate_changes_only_answer_flag_and_never_writes_launchstage_inside_template(self):
        paused=self.configuration();before=deepcopy(paused);template=self.template(paused)
        declared,actual=promote.candidate_template(template,paused)
        self.assertEqual(paused,before);self.assertNotIn('launchStage',declared)
        self.assertEqual(actual['launchStage'],before['launchStage']);self.assertEqual(declared['revision'],promote.ENABLED)
        self.assertEqual(declared['annotations'],template['annotations'])
        self.assertTrue(promote.require_only_flag_delta(before,actual))
        # Complete material hashes still bind fields that aren't writable input.
        actual['launchStage']='BETA'
        with self.assertRaises(ValueError):promote.require_only_flag_delta(before,actual)
    def test_secret_identity_scaling_network_resources_and_extra_material_delta_reject(self):
        paused=self.configuration();enabled=promote.enabled_configuration(paused)
        for changed in ('image','secret','serviceAccount','scaling','cpu','network','timeout','env','unknown'):
            value=deepcopy(enabled)
            if changed=='image':value['containers'][0]['image']='unbound'
            elif changed=='secret':next(row for row in value['containers'][0]['env'] if 'valueSource'in row)['valueSource']['secretKeyRef']['version']='latest'
            elif changed=='cpu':value['containers'][0]['resources']['limits']['cpu']='2'
            elif changed=='env':value['containers'][0]['env'].append({'name':'NEW_ENV','value':'new'})
            elif changed=='network':value['vpcAccess']={'connector':'changed'}
            elif changed=='scaling':value['scaling']['maxInstanceCount']=2
            else:value[changed]='changed'
            with self.subTest(changed=changed),self.assertRaises(ValueError):promote.require_only_flag_delta(paused,value)
        bad=deepcopy(paused);bad['unreviewedRevisionField']=True
        with self.assertRaises(ValueError):promote.candidate_template(self.template(paused),bad)
    def test_duplicate_secret_derived_missing_or_nonboolean_flag_reject(self):
        for mutation in ('duplicate','secret','missing','case'):
            paused=self.configuration();rows=paused['containers'][0]['env'];row=next(row for row in rows if row['name']==promote.FLAG)
            if mutation=='duplicate':rows.append(deepcopy(row))
            elif mutation=='secret':row.pop('value');row['valueSource']={'secretKeyRef':{'secret':'arbitrary','version':'1'}}
            elif mutation=='missing':rows.remove(row)
            else:row['value']='FALSE'
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):promote.enabled_configuration(paused)
    def test_monotonic_bounded_public_usage_retains_rollback_but_exact_creation_rejects_growth(self):
        before=self.ledger();after=deepcopy(before)
        for key in ('reserved_attempts','reserved_tokens','reserved_nanodollars','reservation_count'):after[key]+=1
        self.assertTrue(promote.require_retained_ledger(before,after))
        with self.assertRaises(ValueError):promote.require_retained_ledger(before,after,exact_charges=True)
    def test_charge_refund_caps_authorization_static_bindings_and_malformed_counters_reject(self):
        for mutation in ('refund','cap','grant','static','attempt_exceeded','token_exceeded','dollar_exceeded','boolean'):
            before=self.ledger();after=deepcopy(before)
            if mutation=='refund':after['reserved_nanodollars']-=1
            elif mutation=='cap':after['maximum_tokens']=3000000
            elif mutation=='grant':after['token_ceiling_authorization']['scope_sha256']='f'*64
            elif mutation=='static':after['immutable_non_charge_field_sha256']['global']='f'*64
            elif mutation=='attempt_exceeded':after['reserved_attempts']=101
            elif mutation=='token_exceeded':after['reserved_tokens']=2000001
            elif mutation=='dollar_exceeded':after['reserved_nanodollars']=1000000001
            else:after['reserved_attempts']=True
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):promote.require_retained_ledger(before,after)
    def test_owner_waiver_is_exact_and_does_not_waive_source_or_runtime_verifier(self):
        binding,_=promote.rollback.release()
        with patch.object(promote.run,'api') as api:
            waiver=promote.owner_waiver(binding);self.assertEqual(waiver['sha256'],promote.WAIVER_SHA);api.assert_not_called()
        value=json.loads(promote.WAIVER.read_bytes());value['runtime_semantic_verifier_bypass_authorized']=True
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory:
            path=Path(directory)/'changed.json';path.write_text(json.dumps(value),encoding='utf-8')
            with patch.object(promote,'WAIVER',path),patch.object(promote,'WAIVER_SHA',promote.sha(path)),self.assertRaises(ValueError):
                promote.owner_waiver(binding)
    def test_six_case_contract_never_claims_manual_factual_browser_acceptance_or_verifier_bypass(self):
        value,binding,waiver=self.acceptance();self.assertTrue(promote.require_functional_contract(value,binding,waiver,'commit'))
        for key in ('independent_factual_quality_acceptance','independent_manual_review_performed','human_signoff',
            'runtime_semantic_verifier_bypassed','public_browser_acceptance','images','runtime_lock','owner_waiver','case_files'):
            changed=deepcopy(value)
            if key=='case_files':changed[key].pop(promote.CASE_IDS[-1])
            elif key in ('images','owner_waiver'):changed[key]={'changed':True}
            elif key=='runtime_lock':changed[key]='f'*64
            else:changed[key]=True
            with self.subTest(key=key),self.assertRaises(ValueError):promote.require_functional_contract(changed,binding,waiver,'commit')
    def test_current_role_audit_is_required_without_fabricating_exact_evidence_checkpoint_reuse(self):
        value=self.audit();self.assertTrue(promote.require_delivery_cache_audit(value,self.binding(),'e'*64))
        for key in ('schema','passed','hosted_receipt_sha256','source_factual_quality_acceptance','public_browser_acceptance','proof','ledger'):
            changed=deepcopy(value)
            if key=='schema':changed[key]='old-audit'
            elif key=='passed':changed[key]=False
            elif key=='hosted_receipt_sha256':changed[key]='f'*64
            elif key=='proof':changed['current_role_cache_usage_proofs']['private_draft']['current_role_creation_then_read_usage_proven']=False
            elif key=='ledger':changed['permanent_ledger_proof']['passed']=False
            else:changed[key]=True
            with self.subTest(key=key),self.assertRaises(ValueError):promote.require_delivery_cache_audit(changed,self.binding(),'e'*64)
    def test_preflight_unknown_route_browser_modes_and_overwrite_reject_without_requests(self):
        with patch.object(promote.run,'api') as api:
            for action in (promote.route,promote.health,promote.browser,promote.browser_paths):
                with self.assertRaises(ValueError):action('other')
            api.assert_not_called()
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(promote,'OUT',Path(directory)):
            promote.write('existing.json',{'immutable':True})
            with self.assertRaises(FileExistsError):promote.write('existing.json',{'changed':True})
            with self.assertRaises(ValueError):promote.absent('existing.json')
    def test_ui_service_auth_ingress_scaling_and_audiences_are_separate_exact_bindings(self):
        service={'ingress':'INGRESS_TRAFFIC_ALL','launchStage':'GA','scaling':{'maxInstanceCount':1},
            'invokerIamDisabled':False,'customAudiences':['exact'],'annotations':{'exact':'a'},
            'etag':'mutable-output','traffic':[],'latestReadyRevision':'mutable-output'}
        baseline=promote.ui_service_configuration(service)
        self.assertNotIn('etag',baseline);self.assertNotIn('traffic',baseline)
        for key in ('ingress','launchStage','scaling','invokerIamDisabled','customAudiences','annotations'):
            changed=deepcopy(service);changed[key]='changed'
            self.assertNotEqual(promote.ui_service_configuration(changed),baseline)
    def test_create_journals_exact_ui_only_patch_and_retains_paused_traffic(self):
        binding=self.binding();paused=self.configuration();template=self.template(paused)
        row={'revision':'paused-exact','template':template,'revision_configuration':paused,
            'revision_configuration_sha256':promote.rollback.digest(paused),'service_scaling':{'maxInstanceCount':1},
            'service_configuration':{'launchStage':'GA'}}
        initial={'ui':row};service={'etag':'exact-ui-etag'}
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(promote,'OUT',Path(directory)),\
            patch.object(promote,'read',return_value=initial),patch.object(promote,'check_unchanged',return_value=binding),\
            patch.object(promote,'current_ui',return_value=(service,row)),\
            patch.object(promote,'sha',return_value='a'*64),patch.object(promote.run,'api',return_value={'name':'operation'}) as api:
            self.assertTrue(promote.create()['traffic_remains_paused'])
            api.assert_called_once();method,url,request=api.call_args.args
            self.assertEqual(method,'PATCH');self.assertEqual(url,promote.run.PREFIX+promote.UI+'?updateMask=template,traffic')
            self.assertEqual(request['etag'],'exact-ui-etag');self.assertNotIn('launchStage',request['template'])
            self.assertEqual(request['traffic'],[{'type':'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION','revision':'paused-exact','percent':100}])
            self.assertTrue((Path(directory)/'candidate_intent.json').exists())
            self.assertTrue((Path(directory)/'candidate_submission.json').exists())
    def test_staged_candidate_binds_exact_ready_actual_revision_not_latest_ready_output(self):
        binding=self.binding();paused=self.configuration();template=self.template(paused)
        declared,enabled=promote.candidate_template(template,paused)
        initial={'binding':binding,'ui':{'revision':'paused-exact','revision_configuration':paused,'service_scaling':{'maxInstanceCount':1}}}
        saved={'operation':{'name':'operation'},'request':{'template':declared}}
        service={'trafficStatuses':[{'revision':'paused-exact','percent':100}],'latestCreatedRevision':promote.ENABLED,
            'latestReadyRevision':'unrelated-misleading-output','template':declared,'scaling':{'maxInstanceCount':1}}
        actual=deepcopy(enabled);actual.update(name=promote.ENABLED,conditions=[{'type':'Ready','state':'CONDITION_SUCCEEDED'}])
        records={'initial.json':initial,'candidate_submission.json':saved}
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(promote,'OUT',Path(directory)),\
            patch.object(promote,'read',side_effect=lambda name:records[name]),patch.object(promote,'check_unchanged',return_value=binding),\
            patch.object(promote.rollback,'require_service'),\
            patch.object(promote.run,'api',side_effect=[{'done':True},service,actual]):
            self.assertTrue(promote.candidate_status()['candidate_ready'])
            self.assertTrue((Path(directory)/'candidate_ready.json').exists())
        actual['scaling']['maxInstanceCount']=5
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(promote,'OUT',Path(directory)),\
            patch.object(promote,'read',side_effect=lambda name:records[name]),patch.object(promote,'check_unchanged',return_value=binding),\
            patch.object(promote.rollback,'require_service'),\
            patch.object(promote.run,'api',side_effect=[{'done':True},service,actual]),self.assertRaises(ValueError):
            promote.candidate_status()
    def test_paused_rollback_uses_original_material_flag_and_traffic_only_patch(self):
        paused=self.configuration();template=self.template(paused)
        row={'revision':'paused-exact','template':template,'revision_configuration':paused,
            'revision_configuration_sha256':promote.rollback.digest(paused)}
        records={'initial.json':{'ui':row},'enabled_health.json':{},'candidate_ready.json':{}}
        service={'etag':'exact-current','trafficStatuses':[{'revision':promote.ENABLED,'percent':100}]}
        actual=deepcopy(paused);actual.update(name='paused-exact',conditions=[{'type':'Ready','state':'CONDITION_SUCCEEDED'}])
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(promote,'OUT',Path(directory)),\
            patch.object(promote,'read',side_effect=lambda name:records[name]),patch.object(promote,'check_unchanged',return_value=self.binding()),\
            patch.object(promote.rollback,'require_service'),\
            patch.object(promote.run,'api',side_effect=[service,actual,{'name':'operation'}]) as api:
            self.assertEqual(promote.route('paused_rollback')['target_revision'],'paused-exact')
            method,url,request=api.call_args.args
            self.assertEqual(method,'PATCH');self.assertEqual(url,promote.run.PREFIX+promote.UI+'?updateMask=traffic')
            self.assertEqual(set(request),{'etag','traffic'});self.assertEqual(request['traffic'][0]['revision'],'paused-exact')
            self.assertEqual(sum(call.args[0]!='GET' for call in api.call_args_list),1)

if __name__=='__main__':unittest.main()
