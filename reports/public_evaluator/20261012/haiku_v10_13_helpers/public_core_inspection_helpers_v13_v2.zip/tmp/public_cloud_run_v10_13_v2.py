import json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import submit_hosted_v10 as cloud
from urllib.request import Request

PREFIX='https://run.googleapis.com/v2/projects/'+cloud.PROJECT+'/locations/us-central1/services/'
NAMES=('motomedic-arm-a','motomedic-rider-ui','motomedic-answer-worker')
BACKEND_SA='motomedic-arm-a@'+cloud.PROJECT+'.iam.gserviceaccount.com'
UI_SA='motomedic-rider-ui@'+cloud.PROJECT+'.iam.gserviceaccount.com'
BACKEND_URL='https://motomedic-arm-a-279945185781.us-central1.run.app'
TASK_SA='motomedic-answer-tasks@'+cloud.PROJECT+'.iam.gserviceaccount.com'
WORKER_URL='https://motomedic-answer-worker-279945185781.us-central1.run.app'
def expected_inspection_environment(name):
    if name=='motomedic-rider-ui':return {'MOTOMEDIC_RIDER_ANSWERS_ENABLED':'false'}
    if name not in ('motomedic-arm-a','motomedic-answer-worker'):raise ValueError('UNKNOWN_INSPECTION_SERVICE')
    worker=name=='motomedic-answer-worker'
    return {'MOTOMEDIC_PUBLIC_INSPECTION_ENABLED':'true',
        'MOTOMEDIC_SERVICE_AUDIENCE':WORKER_URL if worker else BACKEND_URL,
        'MOTOMEDIC_SERVICE_ALLOWED_CALLERS':TASK_SA if worker else UI_SA+','+BACKEND_SA}

def require_inspection_environment(name, actual):
    containers=actual.get('containers',[])
    if len(containers)!=1:raise ValueError('ONE_BOUND_INSPECTION_CONTAINER_REQUIRED')
    rows=containers[0].get('env',[])
    environment={row['name']:row for row in rows}
    if len(environment)!=len(rows):raise ValueError('DUPLICATE_INSPECTION_ENVIRONMENT_NAME')
    for key,value in expected_inspection_environment(name).items():
        row=environment.get(key,{})
        if row.get('value')!=value or 'valueSource' in row:raise ValueError('EXACT_INSPECTION_ENVIRONMENT_REQUIRED')
    if name!='motomedic-rider-ui' and environment.get('MOTOMEDIC_RIDER_ANSWERS_ENABLED',{}).get('value')=='false':
        raise ValueError('PRIVATE_ENGINEERING_ANSWER_SUBMISSION_MUST_REMAIN_ENABLED')
    return expected_inspection_environment(name)

def api(method,url,body=None):
    req=Request(url,data=None if body is None else json.dumps(body).encode(),method=method,
        headers={'Authorization':'Bearer '+cloud.token(),'Content-Type':'application/json'})
    try:
        with cloud.build_opener(cloud.NoRedirect()).open(req,timeout=60) as r:return json.load(r)
    except cloud.HTTPError as e:
        error=json.loads(e.read(65536)).get('error',{})
        raise RuntimeError('RUN_HTTP_'+str(e.code)+':'+error.get('message','')) from None
def read():
    results={}
    for name in NAMES:
        try:results[name]=api('GET',PREFIX+name)
        except RuntimeError as e:
            if 'RUN_HTTP_404:' in str(e):continue
            raise
    cloud.dump('cloud_run_current_readback_v1.json' if (cloud.OUT/'cloud_run_readback_v1.json').exists() else 'cloud_run_readback_v1.json',results)
    print(json.dumps({name:{'uri':v.get('uri'),'revision':v.get('latestReadyRevision'),
        'ready':v.get('terminalCondition'),'template':v.get('template')} for name,v in results.items()}))
def deploy(kind):
    name={'backend':'motomedic-arm-a','worker':'motomedic-answer-worker','ui':'motomedic-rider-ui'}[kind]
    results=json.loads((cloud.OUT/'hosted_build_results_v10_13.json').read_bytes())
    result=results['ui' if kind=='ui' else 'backend']
    if result['status']!='SUCCESS':raise RuntimeError('HOSTED_IMAGE_NOT_BUILT')
    img=result['results']['images'][0];image=img['name'].split(':serving-')[0]+'@'+img['digest']
    if kind=='ui':
        env={'MOTOMEDIC_RIDER_API_URL':'https://motomedic-arm-a-279945185781.us-central1.run.app',
            'MOTOMEDIC_PUBLIC_HOST':'motomedic-rider-ui-279945185781.us-central1.run.app',
            'MOTOMEDIC_EDGE_POLICY':'gcp-public-cloud-run-cookie-v2','MOTOMEDIC_RIDER_ACCESS':'public_gateway','MOTOMEDIC_RIDER_AUTH':'cloud_run','MOTOMEDIC_RIDER_ANSWERS_ENABLED':'false'}
        secrets={'MOTOMEDIC_VISITOR_SECRET':'motomedic-rider-visitor-v1'}
    else:
        env={'MOTOMEDIC_CLAUDE_FALLBACK_ENABLED':'false','MOTOMEDIC_PUBLIC_NETWORK_REQUIRED':'false',
             'MOTOMEDIC_TASK_QUEUE':'projects/'+cloud.PROJECT+'/locations/us-central1/queues/motomedic-verified-answers',
             'MOTOMEDIC_TASK_WORKER_URL':WORKER_URL+'/internal/operations/run',
             'MOTOMEDIC_TASK_SERVICE_ACCOUNT':'motomedic-answer-tasks@'+cloud.PROJECT+'.iam.gserviceaccount.com',
             'MOTOMEDIC_EDGE_SERVICE_ACCOUNT':UI_SA,
             'MOTOMEDIC_PUBLIC_INSPECTION_ENABLED':'true',
             'MOTOMEDIC_SERVICE_AUDIENCE':WORKER_URL if kind=='worker' else BACKEND_URL,
             'MOTOMEDIC_SERVICE_ALLOWED_CALLERS':TASK_SA if kind=='worker' else UI_SA+','+BACKEND_SA}
        secrets={'MOTOMEDIC_VISITOR_SECRET':'motomedic-rider-visitor-v1',
                 'ANTHROPIC_API_KEY':'motomedic-evaluator-anthropic-v1'}
    values=[{'name':k,'value':v} for k,v in env.items()]
    values += [{'name':k,'valueSource':{'secretKeyRef':{'secret':v,'version':'1'}}} for k,v in secrets.items()]
    container={'image':image,'ports':[{'containerPort':8080}],'env':values,
        'resources':{'limits':{'cpu':'1' if kind=='ui' else '2','memory':'512Mi' if kind=='ui' else '8Gi'},
                     'startupCpuBoost':True,'cpuIdle':True},
        'startupProbe':{'httpGet':{'path':'/health' if kind=='ui' else '/healthz','port':8080},'initialDelaySeconds':0,'periodSeconds':10,'timeoutSeconds':5,'failureThreshold':24}}
    template={'serviceAccount':UI_SA if kind=='ui' else BACKEND_SA,'containers':[container],
        'scaling':{'minInstanceCount':1 if kind=='backend' else 0,'maxInstanceCount':1},
        'timeout':'1200s','maxInstanceRequestConcurrency':6 if kind=='backend' else 4 if kind=='ui' else 1}
    body={'name':'projects/'+cloud.PROJECT+'/locations/us-central1/services/'+name,'template':template,
          'traffic':[{'type':'TRAFFIC_TARGET_ALLOCATION_TYPE_LATEST','percent':100}],
          'ingress':'INGRESS_TRAFFIC_ALL','labels':{'motomedic-release':'v10-13'}}
    if kind=='worker' and not (cloud.OUT/'deployment_worker_submission_v1.json').exists():
        body.pop('name')
        op=api('POST',PREFIX.rstrip('/')+'?serviceId='+name,body)
    else:op=api('PATCH',PREFIX+name+'?updateMask=template,traffic,ingress,labels',body)
    cloud.dump('deployment_'+kind+'_v10_13_v2_submission.json',{'request':body,'operation':op,'public_iam_changed':False})
    print(json.dumps({'kind':kind,'operation':op['name'],'image':image}))
def poll(kind):
    receipt=json.loads((cloud.OUT/('deployment_'+kind+'_v10_13_v2_submission.json')).read_bytes())
    op=api('GET','https://run.googleapis.com/v2/'+receipt['operation']['name'])
    cloud.dump('deployment_'+kind+'_v10_13_v2_result.json',op)
    print(json.dumps({'kind':kind,'done':op.get('done',False),'error':op.get('error'),
        'ready':op.get('response',{}).get('terminalCondition'),'revision':op.get('response',{}).get('latestReadyRevision')}))
if __name__=='__main__':
    if sys.argv[1]=='read':read()
    elif sys.argv[1]=='deploy':deploy(sys.argv[2])
    else:poll(sys.argv[2])
