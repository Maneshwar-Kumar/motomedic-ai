"""Submit exact prepared build archives using the existing machine login."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from urllib.parse import quote, urlencode
from urllib.request import Request, build_opener
from urllib.error import HTTPError

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from cloud.serving_artifacts import GCSReader, ObjectReference, NoRedirect, digest

PROJECT = 'motomedic-ai-20261009'
BUCKET = PROJECT + '-indices'
OUT = ROOT / 'reports/public_evaluator/20261012'
VERSION = sys.argv[2] if len(sys.argv)>2 else 'v9'
CLI = Path.home() / 'AppData/Local/Google/Cloud SDK/google-cloud-sdk/bin/gcloud.cmd'

def token():
    result = subprocess.run([str(CLI), 'auth', 'print-access-token', '--account=maneshwarkumar@gmail.com', '--quiet'], capture_output=True, text=True, check=True)
    return result.stdout.strip()

def api(url, data=None):
    headers = {'Authorization':'Bearer '+token()}
    if data is not None:
        headers['Content-Type']='application/json'
        data=json.dumps(data).encode()
    try:
        with build_opener(NoRedirect()).open(Request(url, data=data, headers=headers),timeout=60) as response:
            return json.load(response)
    except HTTPError as exc:
        body=exc.read(65536)
        print(json.dumps({'http_status':exc.code, 'error':json.loads(body).get('error',{}).get('message','Cloud API rejected request')}),flush=True)
        raise RuntimeError('HOSTED_BUILD_API_REJECTED') from None

def dump(name, data):
    (OUT/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

def submit():
    prep=json.loads((OUT/('hosted_build_preparation_'+VERSION+'.json')).read_bytes())
    uploads, builds = {}, {}
    for kind in ('backend','ui'):
        context=prep['contexts'][kind]
        archive=ROOT/context['source_archive']
        if digest(archive)!=context['source_archive_sha256']:
            raise ValueError('LOCAL_ARCHIVE_CHANGED')
        object_name='serving/'+VERSION+'/'+prep['input_tree_sha256']+'/'+kind+'-'+context['source_archive_sha256']+'.tar.gz'
        url='https://storage.googleapis.com/upload/storage/v1/b/'+BUCKET+'/o?'+urlencode({'uploadType':'media','name':object_name,'ifGenerationMatch':'0'})
        request=Request(url,data=archive.read_bytes(),headers={'Authorization':'Bearer '+token(),'Content-Type':'application/gzip'},method='POST')
        try:
            with build_opener(NoRedirect()).open(request,timeout=60) as response:
                metadata=json.load(response)
        except HTTPError as exc:
            if exc.code!=412:
                raise RuntimeError('ARCHIVE_UPLOAD_FAILED_HTTP_'+str(exc.code)) from None
            metadata=api('https://storage.googleapis.com/storage/v1/b/'+BUCKET+'/o/'+quote(object_name,safe=''))
        reference={'uri':'gs://'+BUCKET+'/'+object_name,'generation':str(metadata['generation']),'sha256':context['source_archive_sha256'],'maximum_bytes':archive.stat().st_size}
        GCSReader(token=token).fetch(ObjectReference(**reference), ROOT/'tmp/hosted-upload-verification'/VERSION/archive.name)
        uploads[kind]=reference
        dump('hosted_build_uploads_'+VERSION+'.json',uploads)
        config_path=ROOT/context['path']/'cloudbuild.json'
        if digest(config_path)!=context['cloudbuild_sha256']:
            raise ValueError('BUILD_RECIPE_CHANGED')
        config=json.loads(config_path.read_bytes())
        config['source']={'storageSource':{'bucket':BUCKET,'object':object_name,'generation':reference['generation']}}
        operation=api('https://cloudbuild.googleapis.com/v1/projects/'+PROJECT+'/builds',config)
        builds[kind]=operation
        dump('hosted_build_submissions_'+VERSION+'.json',builds)
        build=operation.get('metadata',{}).get('build',{})
        print(json.dumps({'kind':kind,'build_id':build.get('id'),'status':build.get('status'),'logUrl':build.get('logUrl'),'source_generation':reference['generation']}),flush=True)

def poll():
    submissions=json.loads((OUT/('hosted_build_submissions_'+VERSION+'.json')).read_bytes())
    results={}
    for kind,operation in submissions.items():
        build_id=operation['metadata']['build']['id']
        build=api('https://cloudbuild.googleapis.com/v1/projects/'+PROJECT+'/builds/'+build_id)
        results[kind]=build
        print(json.dumps({'kind':kind,'id':build_id,'status':build['status'],'logUrl':build.get('logUrl'),'images':build.get('results',{}).get('images',[])}),flush=True)
    dump('hosted_build_results_'+VERSION+'.json',results)

if __name__=='__main__':
    (submit if sys.argv[1]=='submit' else poll)()
