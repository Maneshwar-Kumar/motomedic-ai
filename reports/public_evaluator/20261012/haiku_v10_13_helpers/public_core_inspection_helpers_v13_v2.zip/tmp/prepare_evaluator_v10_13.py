import gzip,hashlib,io,json,sys,tarfile
from pathlib import Path
from urllib.parse import urlencode
sys.path.insert(0,str(Path(__file__).resolve().parent))
import submit_hosted_v10 as cloud
from cloud.grounded_generation.verified_qa import Config
from cloud.grounded_generation.role_contracts import HAIKU_VERIFIER
from cloud.grounded_generation.role_router import ROUTING_CONTRACT
from evidence_registry import content_hash
sys.path.insert(0,str(cloud.ROOT/'tmp/public_evaluator'))
from phase_budget_v10_13 import make_budget
ROOT,OUT=cloud.ROOT,cloud.OUT
MANIFEST=OUT/'serving_manifest_v10_13.json'
def prepare():
    release=json.loads(MANIFEST.read_bytes())
    sha=hashlib.sha256(MANIFEST.read_bytes()).hexdigest()
    prep=json.loads((OUT/'hosted_build_preparation_v10_13.json').read_bytes())
    lock=Config(verifier_contract=HAIKU_VERIFIER,routing_contract=ROUTING_CONTRACT)
    cloud.dump('expected_runtime_lock_v10_13.json',{'classification':'SYNTHETIC_CODE_BINDING_EXPECTATION_ONLY',
        'runtime_lock':lock.lock,'versions':lock.versions(),'hosted_health_confirmed':False,'provider_calls':0})
    paths=['rider_ui/__init__.py','rider_ui/identity.py','rider_ui/client.py','rider_ui/safeguards.py',
        'rider_ui/verified_sse.py','controller_contracts.py','tmp/public_evaluator/hosted_client_v10_13.py',
        'tmp/public_evaluator/count_only_context_v10_13.py','tmp/public_evaluator/phase_budget_v10_13.py',
        'tmp/public_evaluator/count_history_v1.json',
        'reports/public_evaluator/20261012/owner_model_scope_v3.json',
        'reports/public_evaluator/20261012/haiku_v10_12/owner_anthropic_payload_scope_v2.json',
        'cloud/grounded_generation/token_ceiling.py',
        'cloud/grounded_generation/__init__.py','cloud/grounded_generation/claude_budget.py',
        'evidence_registry.py','generation_providers.py','generation_contracts.py',
        'reports/public_evaluator/20261012/original_page_evaluator_plan_v2.json']
    hashes={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in paths}
    for name,value in hashes.items():
        if name in release['file_sha256'] and release['file_sha256'][name]!=value:raise ValueError('FROZEN_CLIENT_INPUT_CHANGED')
    inventory={'schema':'motomedic-hosted-evaluator-client-inputs-v1','serving_manifest_sha256':sha,
        'source_commit':prep['source_commit'],'file_sha256':hashes,'provider_calls':0,'manual_or_models_in_archive':False}
    inventory.update(model_routing_contract=ROUTING_CONTRACT,
        model_routing_contract_sha256=content_hash(ROUTING_CONTRACT),
        owner_anthropic_payload_scope_sha256='cf469c78449b70bba8cfc245cbb6ed5f3cf301e56102e1fe7fc2f1c415d189e9')
    p=ROOT/'tmp/public_evaluator/client_inputs_v10_13.json'
    if p.exists():raise ValueError('VERSIONED_CLIENT_INVENTORY_ALREADY_EXISTS')
    p.write_text(json.dumps(inventory,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    paths.append('tmp/public_evaluator/client_inputs_v10_13.json');hashes[paths[-1]]=hashlib.sha256(p.read_bytes()).hexdigest()
    source=io.BytesIO()
    with gzip.GzipFile(fileobj=source,mode='wb',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for name in sorted(paths):
                raw=(ROOT/name).read_bytes();row=tarfile.TarInfo(name);row.size=len(raw);row.mode=0o644;row.mtime=0
                archive.addfile(row,io.BytesIO(raw))
    raw=source.getvalue();archive_sha=hashlib.sha256(raw).hexdigest()
    obj='serving/engineering-clients/v10_13/'+archive_sha+'.tar.gz'
    req=cloud.Request('https://storage.googleapis.com/upload/storage/v1/b/'+cloud.BUCKET+'/o?'+urlencode(
        {'uploadType':'media','name':obj,'ifGenerationMatch':'0'}),data=raw,method='POST',
        headers={'Authorization':'Bearer '+cloud.token(),'Content-Type':'application/gzip'})
    with cloud.build_opener(cloud.NoRedirect()).open(req,timeout=60) as res:meta=json.load(res)
    value={'schema':'hosted-original-page-client-source-v1','uri':'gs://'+cloud.BUCKET+'/'+obj,
        'object':obj,'generation':str(meta['generation']),'sha256':archive_sha,'bytes':len(raw),'files':hashes,
        'service_account':'motomedic-arm-a@'+cloud.PROJECT+'.iam.gserviceaccount.com',
        'image':json.loads((OUT/'hosted_image_binding_v10_3.json').read_bytes())['images']['ui'],
        'client_image_scope':'PINNED_V10_3_UI_TRANSPORT_LIBRARIES_ONLY_NOT_SERVING_RUNTIME',
        'count_backend_image':json.loads((OUT/'hosted_image_binding_v10_13.json').read_bytes())['images']['backend'],
        'count_image_scope':'CURRENT_V10_13_BACKEND_ACTUAL_RETRIEVAL_NATIVE_COUNTERS_ONLY',
        'source_inventory_sha256':hashes['tmp/public_evaluator/client_inputs_v10_13.json'],
        'provider_calls':0,'model_execution':'PRIVATE_CLOUD_RUN_WORKER_ONLY',
        'serving_manifest_sha256':sha,'runtime_lock':lock.lock,
        'model_routing_contract_sha256':content_hash(ROUTING_CONTRACT),
        'owner_anthropic_payload_scope_sha256':'cf469c78449b70bba8cfc245cbb6ed5f3cf301e56102e1fe7fc2f1c415d189e9',
        'artifact_prefix':'engineering-acceptance/public-v10_3/'}
    cloud.dump('evaluator_client_source_v9.json',value)
    print(json.dumps(value))
def packed_client_arguments(arguments):
    """Cloud Build transports one lossless compressed budget; serving argv stays exact."""
    import base64
    if (not arguments or arguments[0]!='-B' or
            arguments[1]!='tmp/public_evaluator/hosted_client_v10_13.py' or
            arguments[-2]!='--measured-phase-budget-json'):
        raise ValueError('EXACT_EVALUATOR_ARGUMENTS_REQUIRED')
    compressed=base64.b64encode(gzip.compress(arguments[-1].encode('utf-8'),mtime=0)).decode('ascii')
    wrapper=('import base64,gzip,runpy,sys; from pathlib import Path; '
        'budget=gzip.decompress(base64.b64decode(sys.argv[1],validate=True)).decode("utf-8"); '
        'sys.argv=sys.argv[2:]+["--measured-phase-budget-json",budget]; '
        'sys.path.insert(0,str(Path(sys.argv[0]).resolve().parent)); '
        'runpy.run_path(sys.argv[0],run_name="__main__")')
    result=['-B','-c',wrapper,compressed]+arguments[1:-2]
    if any(len(value.encode('utf-8'))>10000 for value in result):
        raise ValueError('CLOUD_BUILD_ARGUMENT_BYTE_LIMIT')
    return result

def submit():
    src=json.loads((OUT/'evaluator_client_source_v9.json').read_bytes())
    deployment=json.loads((OUT/'deployment_backend_v10_13_result.json').read_bytes())
    if deployment.get('response',{}).get('terminalCondition',{}).get('state')!='CONDITION_SUCCEEDED':raise ValueError('PRIVATE_RUNTIME_NOT_READY')
    count_job=json.loads((OUT/'count_only_submission_v10_13_v1.json').read_bytes())['operation']['metadata']['build']['id']
    count_path=OUT/'hosted_runs'/count_job/'count_receipt.json'
    budget=make_budget(json.loads(count_path.read_bytes()),src,
        hashlib.sha256(count_path.read_bytes()).hexdigest(),ROUTING_CONTRACT)
    run_dir='tmp/public_evaluator/hosted-run-v8'
    config={'serviceAccount':'projects/'+cloud.PROJECT+'/serviceAccounts/'+src['service_account'],
        'source':{'storageSource':{'bucket':cloud.BUCKET,'object':src['object'],'generation':src['generation']}},
        'steps':[{'name':'docker.io/library/python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1',
                  'entrypoint':'python','args':['-c','from pathlib import Path; p=Path("/workspace/'+run_dir+'"); p.mkdir(parents=True,exist_ok=True); p.chmod(0o777)']},
            {'name':src['image'],'entrypoint':'python','args':['-B','tmp/public_evaluator/hosted_client_v10_13.py',
                '--backend','https://motomedic-arm-a-279945185781.us-central1.run.app','--runtime-lock',src['runtime_lock'],
                '--allocated-job-id','$BUILD_ID','--output','/workspace/'+run_dir,
                '--artifact-uri','gs://'+cloud.BUCKET+'/engineering-acceptance/public-v10_3/$BUILD_ID',
                '--project',cloud.PROJECT,'--read-ledger','--stop-on-system-error','--check-completed-boundaries',
                '--measured-phase-budget-json',json.dumps(budget,sort_keys=True,separators=(',',':'))],
             'env':['PYTHONPATH=/workspace','MOTOMEDIC_HOSTED_PROVIDER_VALIDATION=true','MOTOMEDIC_CLOUD_BUILD_ID=$BUILD_ID'],
             'secretEnv':['MOTOMEDIC_VISITOR_SECRET']}],
        'availableSecrets':{'secretManager':[{'versionName':'projects/'+cloud.PROJECT+'/secrets/motomedic-rider-visitor-v1/versions/1','env':'MOTOMEDIC_VISITOR_SECRET'}]},
        'options':{'logging':'CLOUD_LOGGING_ONLY'},'timeout':'1800s'}
    config['steps'][1]['args']=packed_client_arguments(config['steps'][1]['args'])
    op=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds',config)
    cloud.dump('evaluator_client_submission_v8.json',{'config':config,'operation':op})
    print(json.dumps({'id':op['metadata']['build']['id'],'status':op['metadata']['build']['status']}))
def poll():
    bid=json.loads((OUT/'evaluator_client_submission_v8.json').read_bytes())['operation']['metadata']['build']['id']
    result=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds/'+bid)
    cloud.dump('evaluator_client_build_v8.json',result);print(json.dumps({'id':bid,'status':result['status']}))

def count_config(src, binding):
    if (binding['serving_manifest_sha256'] != src['serving_manifest_sha256'] or
            binding['runtime_revision'] != 'v10_13' or
            not binding['images']['backend'].startswith('us-central1-docker.pkg.dev/'+cloud.PROJECT+'/motomedic/arm-a@sha256:') or
            'tmp/public_evaluator/count_only_context_v10_13.py' not in src['files'] or
            src.get('count_backend_image') != binding['images']['backend']):
        raise ValueError('COUNT_ONLY_SOURCE_IMAGE_BINDING_CHANGED')
    run_dir='tmp/public_evaluator/count-only-v10_13'
    return {'serviceAccount':'projects/'+cloud.PROJECT+'/serviceAccounts/'+src['service_account'],
        'source':{'storageSource':{'bucket':cloud.BUCKET,'object':src['object'],'generation':src['generation']}},
        'steps':[{'name':'docker.io/library/python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1',
            'entrypoint':'python','args':['-c','from pathlib import Path; p=Path("/workspace/'+run_dir+'"); p.mkdir(parents=True,exist_ok=True); p.chmod(0o777)']},
            {'name':binding['images']['backend'],'entrypoint':'python','args':['-B','tmp/public_evaluator/count_only_context_v10_13.py',
                '--client-input-inventory','tmp/public_evaluator/client_inputs_v10_13.json',
                '--runtime-lock',src['runtime_lock'],'--manifest-sha',src['serving_manifest_sha256'],
                '--allocated-job-id','$BUILD_ID','--output','/workspace/'+run_dir,
                '--artifact-uri','gs://'+cloud.BUCKET+'/engineering-acceptance/public-v10_3/$BUILD_ID',
                '--project',cloud.PROJECT],
             'env':['PYTHONPATH=/workspace:/app','K_SERVICE=motomedic-count-only-hosted-validation',
                'MOTOMEDIC_HOSTED_PROVIDER_VALIDATION=true','MOTOMEDIC_HOSTED_COUNT_ONLY=true','MOTOMEDIC_CLOUD_BUILD_ID=$BUILD_ID',
                'MOTOMEDIC_CLAUDE_FALLBACK_ENABLED=false','HF_HUB_OFFLINE=1','TRANSFORMERS_OFFLINE=1'],
             'secretEnv':['ANTHROPIC_API_KEY']}],
        'availableSecrets':{'secretManager':[
            {'versionName':'projects/'+cloud.PROJECT+'/secrets/motomedic-evaluator-anthropic-v1/versions/1','env':'ANTHROPIC_API_KEY'}]},
        'options':{'logging':'CLOUD_LOGGING_ONLY','machineType':'E2_HIGHCPU_8'},'timeout':'1200s'}

def submit_count():
    target=OUT/'count_only_submission_v10_13_v1.json'
    if target.exists():raise ValueError('COUNT_ONLY_SUBMISSION_ALREADY_RECORDED_USE_POLL')
    src=json.loads((OUT/'evaluator_client_source_v9.json').read_bytes())
    binding=json.loads((OUT/'hosted_image_binding_v10_13.json').read_bytes())
    config=count_config(src,binding)
    op=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds',config)
    cloud.dump(target.name,{'config':config,'operation':op,'generation_authorized':False,'provider_reservations_authorized':False})
    print(json.dumps({'id':op['metadata']['build']['id'],'status':op['metadata']['build']['status'],'generation_authorized':False}))

def poll_count():
    bid=json.loads((OUT/'count_only_submission_v10_13_v1.json').read_bytes())['operation']['metadata']['build']['id']
    result=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds/'+bid)
    cloud.dump('count_only_build_v10_13_v1.json',result)
    print(json.dumps({'id':bid,'status':result['status'],'generation_authorized':False}))

if __name__=='__main__':{'prepare':prepare,'submit':submit,'poll':poll,
    'submit_count':submit_count,'poll_count':poll_count}[sys.argv[1]]()
