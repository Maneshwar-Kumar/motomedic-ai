import json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import submit_hosted_v10 as cloud
def logs(scope, identifier):
    if scope=='build':
        flt='resource.type="build" AND resource.labels.build_id="'+identifier+'"'
    else:
        flt='resource.type="cloud_run_revision" AND resource.labels.service_name="'+identifier+'" AND timestamp>="2026-10-11T20:40:00Z"'
    rows=cloud.api('https://logging.googleapis.com/v2/entries:list',{'resourceNames':['projects/'+cloud.PROJECT],
        'filter':flt,'orderBy':'timestamp desc','pageSize':100}).get('entries',[])
    records=[]
    for row in reversed(rows):
        payload=row.get('jsonPayload')
        text=row.get('textPayload','')
        if scope=='build':
            try:value=json.loads(text[text.find('{'):])
            except (ValueError,TypeError):value=payload
            if isinstance(value,dict) and value.get('schema_version')=='hosted-cached-verifier-capability-v1':
                cloud.dump('cache_probe_capability_v2.json',value)
                print(json.dumps(value))
                continue
            if isinstance(value,dict):
                allowed=('case_id','operation_id','request_sha256','status','route','error','response_sha256',
                         'exact_saved_stream','exact_recovered_view','total_seconds','receipt_sha256',
                         'case_count','engineering_completed_cases','independent_factual_review_pending',
                         'artifact_file','generation','sha256','credential_logged','credentials_logged')
                selected={k:value[k] for k in allowed if k in value and isinstance(value[k],(str,int,float,bool,type(None)))}
                if selected:
                    records.append({'timestamp':row.get('timestamp'),'scalars':selected})
                    continue
        # Only fixed operational startup/trace lines; no request bodies or JWTs.
        safe=('Traceback','Error','ERROR','Exception','Permission','denied','Listening','Booting','Worker','Started','motomedic','Pulling','Digest:')
        if scope=='build' and len(text)<1200 and any(s in text for s in safe) and not any(s in text for s in ('Bearer','API_KEY','authorization','Authorization','natural_language','evidence')):
            records.append({'timestamp':row.get('timestamp'),'message':text})
        elif scope=='run':
            if 'Traceback' in text and not any(s in text for s in ('Bearer','API_KEY','Authorization','natural_language')):
                records.append({'timestamp':row.get('timestamp'),'startup_exception_tail':'\n'.join(text.splitlines()[-8:])})
            if 'httpRequest' in row:
                req=row['httpRequest'];records.append({'timestamp':row.get('timestamp'),'status':req.get('status'),
                    'method':req.get('requestMethod'),'latency':req.get('latency'),'path':req.get('requestUrl','').split('?')[0],
                    'revision':row.get('resource',{}).get('labels',{}).get('revision_name')})
            elif len(text)<1500 and any(s in text for s in safe) and not any(s in text for s in ('Bearer','API_KEY','Authorization','natural_language')):
                records.append({'timestamp':row.get('timestamp'),'message':text})
            elif isinstance(payload,dict) and payload.get('event')=='arm_a_auth_rejected':records.append(payload)
    print(json.dumps(records[-40:]))
    cloud.dump('logs_'+scope+'_'+identifier+'.json',records)
if __name__=='__main__':logs(sys.argv[1],sys.argv[2])
