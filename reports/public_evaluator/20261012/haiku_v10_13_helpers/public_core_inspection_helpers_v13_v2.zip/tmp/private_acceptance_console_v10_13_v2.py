"""Fixed private v10.13 operations; launching alone performs no cloud action.

The coordinator invokes one named action per JSON line. No arbitrary shell,
provider-key read, public IAM, billing or allocation action is exposed.
"""
import hashlib
import importlib
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import re
import runpy
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
import public_cloud_run_v10_13_v2 as run
import prepare_evaluator_v10_13 as evaluator
import public_hosted_logs as logs

cloud = run.cloud
cloud.VERSION = 'v10_13'
VERSION = cloud.VERSION
SOURCE_RECEIPT = 'evaluator_client_source_v9.json'
SUBMISSION = 'evaluator_client_submission_v8.json'
COUNT_SUBMISSION = 'count_only_submission_v10_13_v1.json'
GET_ROLE = 'projects/' + cloud.PROJECT + '/roles/motomedicSnapshotObjectGet'
MEMBER = 'serviceAccount:' + run.BACKEND_SA
cached = [None, 0]
SDK_CATEGORIES = {'CredentialRefreshError', 'ApiPermissionError', 'SDKDependencyError',
    'SDKTimeoutError', 'SDKAuthenticationCommandError'}


class SDKCommandFailure(RuntimeError):
    def __init__(self, category):
        self.sdk_error_category = category
        super().__init__('SDK_AUTHENTICATION_UNAVAILABLE')


def sdk_identity(kind):
    environment = os.environ.copy()
    environment.pop('PYTHONPATH', None)
    try:
        result = subprocess.run([str(cloud.CLI), 'auth', kind,
            '--account=maneshwarkumar@gmail.com', '--quiet'], capture_output=True,
            text=True, env=environment, timeout=45)
    except subprocess.TimeoutExpired:
        raise SDKCommandFailure('SDKTimeoutError') from None
    if result.returncode:
        error = (result.stderr or '').lower()
        if any(value in error for value in ('invalid_grant', 'reauth', 'could not refresh', 'refresherror')):
            category = 'CredentialRefreshError'
        elif any(value in error for value in ('permission_denied', 'permission denied', 'forbidden')):
            category = 'ApiPermissionError'
        elif any(value in error for value in ('modulenotfounderror', 'importerror', 'protobuf')):
            category = 'SDKDependencyError'
        else:
            category = 'SDKAuthenticationCommandError'
        raise SDKCommandFailure(category) from None
    value = result.stdout.strip()
    if not value or any(character.isspace() for character in value):
        raise SDKCommandFailure('SDKAuthenticationCommandError')
    return value


def read(name):
    return json.loads((cloud.OUT / name).read_bytes())


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def token():
    if time.time() > cached[1]:
        cached[:] = [sdk_identity('print-access-token'), time.time() + 2400]
    return cached[0]


cloud.token = token


def release():
    path = cloud.OUT / 'serving_manifest_v10_13.json'
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    if (cloud.OUT / 'serving_manifest_v10_13.sha256').read_text().split()[0] != sha:
        raise ValueError('CURRENT_MANIFEST_SIDECAR_CHANGED')
    return sha


def build_submit():
    sha = release()
    if read('hosted_build_preparation_v10_13.json')['serving_manifest_sha256'] != sha:
        raise ValueError('CURRENT_PREPARATION_CHANGED')
    if (cloud.OUT / 'hosted_build_submissions_v10_13.json').exists():
        raise ValueError('BUILD_SUBMISSION_ALREADY_RECORDED_USE_POLL')
    cloud.submit()


def deploy(kind):
    sha = release()
    binding = read('hosted_image_binding_v10_13.json')
    if binding['serving_manifest_sha256'] != sha:
        raise ValueError('CURRENT_IMAGE_BINDING_CHANGED')
    result = read('hosted_build_results_v10_13.json')['ui' if kind == 'ui' else 'backend']
    image = result['results']['images'][0]
    expected = image['name'].split(':serving-')[0] + '@' + image['digest']
    if binding['images']['ui' if kind == 'ui' else 'backend'] != expected:
        raise ValueError('BOUND_IMAGE_CHANGED')
    if (cloud.OUT / ('deployment_' + kind + '_v10_13_v2_submission.json')).exists():
        raise ValueError('DEPLOYMENT_ALREADY_RECORDED_USE_POLL')
    run.deploy(kind)


def readiness():
    import rollback_public_v10_13 as rollback
    binding,manifest=rollback.release()
    sha=binding['serving_manifest_sha256']
    auth_paths=('cloud/arm_a/public_inspection_auth.py','cloud/arm_a/test_public_inspection_auth.py',
        'cloud/arm_a/app.py','rider_ui/public_gateway.py','rider_ui/app.py','rider_ui/client.py')
    frozen=manifest.get('file_sha256',{})
    hashes={path:hashlib.sha256((cloud.ROOT/path).read_bytes()).hexdigest() for path in auth_paths}
    if any(frozen.get(path)!=value for path,value in hashes.items()):
        raise ValueError('PUBLIC_INSPECTION_AND_PREVIEW_AUTH_SOURCES_NOT_FROZEN')
    policies=rollback.private_policies(include_ui=True)
    identity=sdk_identity('print-identity-token')
    results={}
    for name in run.NAMES:
        service=run.api('GET',run.PREFIX+name)
        rollback.require_service(name,service,binding)
        revision=rollback.routed_revision(service)
        actual=run.api('GET',run.PREFIX+name+'/revisions/'+revision)
        rollback.require_ready_revision(actual,revision)
        configuration=rollback.revision_configuration(actual,service['template'])
        environment=run.require_inspection_environment(name,actual)
        health=rollback.get_health(name,service,binding,identity)
        results[name]={'health':health['health'],'revision':revision,'traffic':service.get('trafficStatuses'),
            'image':service['template']['containers'][0]['image'],'provider_calls':0,
            'revision_configuration':configuration,'revision_configuration_sha256':rollback.digest(configuration),
            'inspection_environment':environment,'actual_ready_revision_bound':True}
    name='private_readiness_v10_13_v2.json'
    if (cloud.OUT/name).exists():raise ValueError('NEVER_OVERWRITE_PRIVATE_V2_READINESS')
    rollback.dump(name,{'schema':'motomedic-private-preview-inspection-readiness-v2',
        'serving_manifest_sha256':sha,'runtime_lock':binding['runtime_lock'],'services':results,
        'frozen_auth_source_sha256':hashes,'private_policy_sha256':{name:rollback.digest(policy) for name,policy in policies.items()},
        'private_backend_worker_engineering_validation_enabled':True,'ui_answer_submission_paused':True,
        'public_inspection_flags_ready_but_iam_private':True,'provider_calls':0,'public_iam_changed':False,
        'quality_acceptance':False})
    print(json.dumps({'private_services_ready':list(results),'provider_calls':0,
        'ui_answer_submission_paused':True,'public_inspection_iam_still_private':True}),flush=True)


def prepare_client():
    release()
    if (cloud.OUT / SOURCE_RECEIPT).exists():
        raise ValueError('CLIENT_SOURCE_ALREADY_RECORDED')
    evaluator.prepare()


def source_policy_replacement(policy, prior, source):
    """Change exactly one existing conditional get binding; retain every other row."""
    if not policy.get('etag'):
        raise ValueError('IAM_CONCURRENCY_ETAG_REQUIRED')
    if not re.fullmatch(r'serving/engineering-clients/v10_13/[0-9a-f]{64}\.tar\.gz', source['object']):
        raise ValueError('EXACT_V10_13_SOURCE_OBJECT_REQUIRED')
    if (source['object'].split('/')[-1] != source['sha256'] + '.tar.gz' or
            source['service_account'] != run.BACKEND_SA or
            source['artifact_prefix'] != 'engineering-acceptance/public-v10_3/' or
            not re.fullmatch(r'[0-9]+', source['generation'])):
        raise ValueError('CURRENT_SOURCE_REFERENCE_CHANGED')
    prefix = 'projects/_/buckets/' + cloud.BUCKET + '/objects/'
    previous_expression = "resource.name == '" + prefix + prior['source']['object'] + "'"
    matches = [row for row in policy.get('bindings', []) if row.get('role') == GET_ROLE and
        row.get('members') == [MEMBER] and row.get('condition', {}).get('expression') == previous_expression and
        row.get('condition', {}).get('title') == 'motomedic-backend-exact-evaluator-client-v10-12-v8']
    if len(matches) != 1:
        raise ValueError('EXACT_PREVIOUS_SOURCE_GRANT_REQUIRED')
    updated = json.loads(json.dumps(policy))
    updated['version'] = 3
    updated['bindings'] = [row for row in updated['bindings'] if row != matches[0]]
    current = {'role': GET_ROLE, 'members': [MEMBER], 'condition': {
        'expression': "resource.name == '" + prefix + source['object'] + "'",
        'title': 'motomedic-backend-exact-evaluator-client-v10-13-v9',
        'description': 'Read only the exact authorized v10_13 hosted engineering client archive'}}
    updated['bindings'].append(current)
    return updated, matches[0], current


def grant_client_source():
    sha = release()
    source = read(SOURCE_RECEIPT)
    if source['serving_manifest_sha256'] != sha:
        raise ValueError('CLIENT_SOURCE_MANIFEST_CHANGED')
    target = cloud.OUT / 'operations/client_source_grant_v9.json'
    if target.exists():
        raise ValueError('CLIENT_SOURCE_GRANT_ALREADY_RECORDED')
    prior = read('operations/client_source_grant_v8.json')
    endpoint = 'https://storage.googleapis.com/storage/v1/b/' + cloud.BUCKET + '/iam'
    policy = run.api('GET', endpoint + '?optionsRequestedPolicyVersion=3')
    updated, previous, current = source_policy_replacement(policy, prior, source)
    # Preserve all unrelated identities/conditions with optimistic etag concurrency.
    result = run.api('PUT', endpoint, updated)
    after = run.api('GET', endpoint + '?optionsRequestedPolicyVersion=3')
    if (current not in after.get('bindings', []) or previous in after.get('bindings', []) or
            sorted((digest(row) for row in after['bindings'] if row != current)) !=
            sorted((digest(row) for row in policy['bindings'] if row != previous))):
        raise ValueError('EXACT_SOURCE_GRANT_READBACK_FAILED')
    cloud.dump('operations/client_source_grant_v9.json', {
        'schema_version': 'hosted-evaluator-client-source-grant-v9',
        'project_id': cloud.PROJECT, 'source': source,
        'prior_receipt': 'reports/public_evaluator/20261012/operations/client_source_grant_v8.json',
        'authorization': 'Owner-approved v10_13 private hosted client; replace only exact prior source get condition',
        'removed_binding': previous, 'added_binding': current,
        'unrelated_bindings_unchanged': True, 'prior_policy_sha256': digest(policy),
        'result_policy_sha256': digest(result), 'readback_policy_sha256': digest(after),
        'public_iam_changed': False, 'artifact_create_prefix_changed': False,
        'provider_key_payload_read': False, 'provider_calls': 0})
    print(json.dumps({'exact_client_source_grant_ready': True, 'generation': source['generation'],
        'public_iam_changed': False, 'provider_calls': 0}), flush=True)


def start_evaluation():
    source = read(SOURCE_RECEIPT)
    grant = read('operations/client_source_grant_v9.json')
    if grant['source'] != source or source['serving_manifest_sha256'] != release():
        raise ValueError('HOSTED_CLIENT_GRANT_BINDING_CHANGED')
    if (cloud.OUT / SUBMISSION).exists():
        raise ValueError('EVALUATION_SUBMISSION_ALREADY_RECORDED_USE_POLL')
    require_count_preflight(source)
    evaluator.submit()


def validate_count_receipt(receipt, source):
    from cloud.grounded_generation.role_router import ROUTING_CONTRACT
    from evidence_registry import content_hash
    if (receipt.get('schema') != 'motomedic-hosted-native-count-role-preflight-v4' or
            receipt.get('classification') != 'HOSTED_NATIVE_COUNTERS_AND_ROLE_FORECAST_ONLY' or
            receipt.get('owner_model_scope_sha256') != '65755e0a6b79f2df542c1c4b5f4f2e382a6857f7ee5ff5803d64988204e5ad0f' or
            receipt.get('model_routing_contract_sha256') != content_hash(ROUTING_CONTRACT) or
            source.get('model_routing_contract_sha256') != content_hash(ROUTING_CONTRACT) or
            receipt.get('serving_manifest_sha256') != source['serving_manifest_sha256'] or
            receipt.get('runtime_lock') != source['runtime_lock'] or
            receipt.get('script_sha256') != source['files']['tmp/public_evaluator/count_only_context_v10_13.py'] or
            receipt.get('history_sha256') != source['files']['tmp/public_evaluator/count_history_v1.json'] or
            receipt.get('preflight_passed') is not True or
            receipt.get('selected_draft_native_window_eligible') is not True or
            receipt.get('selected_draft_counter_request_passed') is not True or
            receipt.get('known_verifier_count_request_passed') is not True or
            receipt.get('verifier_synthetic_stress_native_window_eligible') is not True or
            receipt.get('actual_finalized_verifier_count_demonstrated') is not False or
            receipt.get('future_finalized_verifier_quota_status') != 'UNKNOWN_MANDATORY_ACTUAL_FINAL_COUNT' or
            type(receipt.get('generation_calls')) is not int or receipt.get('generation_calls') != 0 or
            type(receipt.get('reservation_calls')) is not int or receipt.get('reservation_calls') != 0 or
            type(receipt.get('planned_native_counter_calls')) is not int or receipt.get('planned_native_counter_calls') != 36 or
            type(receipt.get('native_counter_calls')) is not int or receipt.get('native_counter_calls') != 36 or
            type(receipt.get('case_count')) is not int or receipt.get('case_count') != 6 or
            receipt.get('transport_allowlist_enforced') is not True or
            type(receipt.get('counter_transport_calls')) is not int or receipt.get('counter_transport_calls') != 36 or
            type(receipt.get('model_metadata_transport_calls')) is not int or receipt.get('model_metadata_transport_calls') != 0 or
            type(receipt.get('prohibited_transport_calls')) is not int or receipt.get('prohibited_transport_calls') != 0 or
            receipt.get('provider_allocation_delta_zero') is not True or
            receipt.get('ledger_before') != receipt.get('ledger_after') or
            not isinstance(receipt.get('ledger_before'), dict)):
        raise ValueError('HOSTED_COUNT_ONLY_PREFLIGHT_NOT_ACCEPTED')
    sys.path.insert(0,str(cloud.ROOT/'tmp/public_evaluator'))
    from phase_budget_v10_13 import make_budget
    try:
        make_budget(receipt, source, '0'*64, ROUTING_CONTRACT)
    except (ValueError, KeyError, TypeError):
        raise ValueError('HOSTED_COUNT_ROLE_PHASE_FORECAST_INVALID') from None


def require_count_preflight(source):
    submission = read(COUNT_SUBMISSION)
    bid = submission['operation']['metadata']['build']['id']
    result = read('count_only_build_v10_13_v1.json')
    expected = evaluator.count_config(source, read('hosted_image_binding_v10_13.json'))
    if (result.get('id') != bid or result.get('status') != 'SUCCESS' or
            submission['config'] != expected or
            result.get('source', {}).get('storageSource') != expected['source']['storageSource']):
        raise ValueError('HOSTED_COUNT_ONLY_BUILD_BINDING_CHANGED')
    relative = 'hosted_runs/' + bid + '/count_receipt.json'
    receipt = read(relative)
    inventory = read('hosted_runs/' + bid + '/download_inventory.json')
    path = cloud.OUT / relative
    if (inventory['cloud_build_id'] != bid or
            inventory['files']['count_receipt.json']['sha256'] != hashlib.sha256(path.read_bytes()).hexdigest() or
            receipt.get('cloud_build_id') != bid):
        raise ValueError('HOSTED_COUNT_ONLY_RECEIPT_BINDING_CHANGED')
    validate_count_receipt(receipt, source)


def start_count_only():
    source = read(SOURCE_RECEIPT)
    grant = read('operations/client_source_grant_v9.json')
    if grant['source'] != source or source['serving_manifest_sha256'] != release():
        raise ValueError('COUNT_ONLY_CLIENT_GRANT_BINDING_CHANGED')
    evaluator.submit_count()


def evaluation_id():
    return read(SUBMISSION)['operation']['metadata']['build']['id']


def count_only_id():
    return read(COUNT_SUBMISSION)['operation']['metadata']['build']['id']


def download_count_only():
    sys.argv = ['download_evaluator_artifacts.py', count_only_id()]
    runpy.run_path(str(cloud.ROOT / 'tmp/download_evaluator_artifacts.py'), run_name='__main__')


def download():
    sys.argv = ['download_evaluator_artifacts.py', evaluation_id()]
    runpy.run_path(str(cloud.ROOT / 'tmp/download_evaluator_artifacts.py'), run_name='__main__')


def browser():
    path = cloud.ROOT / 'tmp/launch_evaluator_browser_v10_13.py'
    result = subprocess.run([sys.executable, str(path), 'private-shell'], timeout=420)
    print(json.dumps({'private_browser_exit_code': result.returncode}), flush=True)


def rollback_action(name):
    helper = importlib.import_module('rollback_public_v10_13')
    helper.identity_token = lambda: sdk_identity('print-identity-token')
    print(json.dumps(getattr(helper, name)()), flush=True)


def read_guard():
    """Read exact existing guard/billing metadata and allowlisted cost scalars."""
    billing = {}
    for project in (cloud.PROJECT, 'motomedic-inference-20261009'):
        value = run.api('GET', 'https://cloudbilling.googleapis.com/v1/projects/' + project + '/billingInfo')
        billing[project] = value.get('billingEnabled')
    service = run.api('GET', run.PREFIX + 'motomedic-budget-guard')
    allowed = {'BUDGET_INR', 'STOP_INR', 'SIMULATE', 'BUDGET_DISPLAY_NAME'}
    settings = {row['name']: row.get('value') for row in service['template']['containers'][0].get('env', [])
        if row.get('name') in allowed and 'value' in row}
    rows = run.api('POST', 'https://logging.googleapis.com/v2/entries:list', {
        'resourceNames': ['projects/' + cloud.PROJECT],
        'filter': 'resource.type="cloud_run_revision" AND resource.labels.service_name="motomedic-budget-guard"',
        'orderBy': 'timestamp desc', 'pageSize': 50}).get('entries', [])
    scalars = []
    for row in rows:
        value = row.get('jsonPayload')
        if not isinstance(value, dict):
            try:
                value = json.loads(row.get('textPayload', ''))
            except (ValueError, TypeError):
                continue
        if not isinstance(value, dict):
            continue
        cost = value.get('cost_inr') if isinstance(value, dict) else None
        if (value.get('project') == cloud.PROJECT and type(cost) in (int, float) and
                math.isfinite(cost) and cost >= 0 and type(value.get('stop')) is bool):
            scalars.append({'timestamp': row.get('timestamp'), 'cost_inr': cost, 'stop': value['stop']})
            if len(scalars) == 3:
                break
    now = datetime.now(timezone.utc)
    name = 'operations/guard_readback_v10_13_' + now.strftime('%Y%m%dT%H%M%S%fZ') + '.json'
    value = {'schema_version': 'private-v10_13-guard-readback-v1', 'read_at_utc': now.isoformat(),
        'project_id': cloud.PROJECT, 'guard_revision': service.get('latestReadyRevision'),
        'guard_settings': settings, 'billing_enabled': billing, 'latest_guard_log_scalars': scalars,
        'recorded_scope_matches': settings.get('BUDGET_INR') == '2700' and
            settings.get('STOP_INR') == '2540' and settings.get('SIMULATE') == 'false' and
            billing[cloud.PROJECT] is True and billing['motomedic-inference-20261009'] is False and
            bool(scalars) and scalars[0]['stop'] is False,
        'delayed_reporting_prevents_instantaneous_cap': True, 'cloud_writes': 0,
        'billing_changed': False, 'provider_calls': 0, 'raw_logs_or_request_bodies_saved': False}
    if (cloud.OUT / name).exists():
        raise ValueError('NEVER_OVERWRITE_GUARD_READBACK')
    cloud.dump(name, value)
    print(json.dumps({'receipt': str(cloud.OUT / name), **value}), flush=True)


ACTIONS = {
    'submit_builds': build_submit, 'build_status': cloud.poll,
    'deploy_backend': lambda: deploy('backend'), 'deploy_worker': lambda: deploy('worker'),
    'deploy_ui': lambda: deploy('ui'),
    'backend_status': lambda: run.poll('backend'), 'worker_status': lambda: run.poll('worker'),
    'ui_status': lambda: run.poll('ui'), 'readiness': readiness,
    'prepare_client': prepare_client, 'grant_client_source': grant_client_source,
    'start_count_only': start_count_only, 'count_only_status': evaluator.poll_count,
    'count_only_logs': lambda: logs.logs('build', count_only_id()),
    'download_count_only': download_count_only,
    'start_evaluation': start_evaluation, 'evaluation_status': evaluator.poll,
    'evaluation_logs': lambda: logs.logs('build', evaluation_id()),
    'download_evaluation': download,
    'operations_logs': lambda: (logs.logs('run', 'motomedic-arm-a'), logs.logs('run', 'motomedic-answer-worker')),
    'private_browser': browser,
    'read_guard': read_guard,
    'rollback_create': lambda: rollback_action('create'),
    'rollback_status': lambda: rollback_action('poll'),
    'route_candidate': lambda: rollback_action('route_candidate'),
    'health_candidate': lambda: rollback_action('health_candidate'),
    'route_rollback': lambda: rollback_action('route_rollback'),
    'health_rollback': lambda: rollback_action('health_rollback'),
    'route_restore': lambda: rollback_action('route_restore'),
    'health_restore': lambda: rollback_action('health_restore'),
}


def main():
    print(json.dumps({'console': 'PRIVATE_V10_13_V2_PREVIEW_DEPLOY_ACCEPTANCE_ONLY', 'ready': True,
        'public_access_actions': False, 'billing_actions': False, 'allocation_actions': False,
        'iam_action': 'EXACT_CONDITIONAL_CLIENT_SOURCE_GET_REPLACEMENT_ONLY',
        'provider_key_payload_read': False, 'actions': sorted(ACTIONS)}), flush=True)
    if '--check-only' in sys.argv:
        return
    for line in sys.stdin:
        request = None
        try:
            request = json.loads(line)
            if set(request) != {'action'} or request['action'] not in ACTIONS:
                raise ValueError('FIXED_ACTION_REQUIRED')
            ACTIONS[request['action']]()
            print(json.dumps({'action': request['action'], 'complete': True}), flush=True)
        except Exception as exc:
            print(json.dumps({'action': request.get('action') if isinstance(request, dict) else None,
                'complete': False, 'error_class': type(exc).__name__,
                **({'sdk_error_category': exc.sdk_error_category} if
                   getattr(exc, 'sdk_error_category', None) in SDK_CATEGORIES else {}),
                'raw_error_logged': False}), flush=True)


if __name__ == '__main__':
    main()
