"""Synthetic public core scope/IAM/probe boundaries; no network or providers."""
import base64
from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
import public_core_inspection_v13_v1 as core

class CoreTests(unittest.TestCase):
    def test_only_all_users_invoker_added_and_every_prior_row_preserved(self):
        policy={'etag':'synthetic','version':3,'bindings':[{'role':'roles/run.invoker','members':['serviceAccount:existing']},
            {'role':'other-role','members':['unchanged'],'condition':{'expression':'exact-old-scope'}}]}
        before=deepcopy(policy);after=core.public_invoker_policy(policy)
        self.assertEqual(policy,before);self.assertEqual(after['bindings'][0]['members'],['serviceAccount:existing','allUsers'])
        self.assertEqual(after['bindings'][1],before['bindings'][1]);self.assertEqual(after['etag'],before['etag'])
    def test_missing_etag_any_public_role_and_multiple_unconditional_invokers_reject(self):
        for policy in ({'bindings':[]},{'etag':'x','bindings':[{'role':'other-role','members':['allAuthenticatedUsers']}]},
            {'etag':'x','bindings':[{'role':'roles/run.invoker','members':['a']},{'role':'roles/run.invoker','members':['b']}]}):
            with self.assertRaises(ValueError):core.public_invoker_policy(policy)
    def test_synthetic_forged_token_uses_exact_audience_and_expected_email_but_no_real_signature(self):
        for name,email in (('motomedic-arm-a',core.run.UI_SA),('motomedic-answer-worker',core.run.TASK_SA)):
            parts=core.forged_token(name).split('.');claims=json.loads(base64.urlsafe_b64decode(parts[1]+'='*(-len(parts[1])%4)))
            self.assertEqual(claims['aud'],core.URLS[name]);self.assertEqual(claims['email'],email)
            self.assertIs(claims['email_verified'],True);self.assertEqual(parts[2],'invalid_signature')
    def test_unknown_core_actions_reject_without_requests(self):
        with patch.object(core.run,'api') as api:
            for action in (core.open_service,core.probe):
                with self.assertRaises(ValueError):action('unapproved-service')
            api.assert_not_called()
    def test_probe_rejects_when_fake_auth_reaches_any_non401_handler(self):
        name='motomedic-answer-worker';inspection={'binding':{},'services':{}}
        policy={'etag':'synthetic','bindings':[{'role':'roles/run.invoker','members':['allUsers']}]}
        reply=lambda method,url,*args:(200,{'ready':True}) if method=='GET' else (400,{'error':'INVALID_WORKER_REQUEST','technical_content':False})
        with patch.object(core,'read',side_effect=lambda path:inspection if path=='inspection.json' else {'policy':policy}),\
            patch.object(core,'check_current',return_value={}),patch.object(core.run,'api',return_value=policy),\
            patch.object(core,'ledger_audit',return_value={'retained':'unchanged'}),\
            patch.object(core,'anonymous_json',side_effect=reply),patch.object(core.rollback,'get_health',return_value={'health':{'ready':True}}),\
            patch.object(core,'write') as write:
            with self.assertRaisesRegex(ValueError,'FORGED_OPERATION_NOT_REJECTED'):core.probe(name)
            write.assert_not_called()
    def test_negative_worker_body_never_contains_operation_identifiers_and_changed_ledger_fails(self):
        name='motomedic-answer-worker';inspection={'binding':{},'services':{}}
        policy={'etag':'synthetic','bindings':[{'role':'roles/run.invoker','members':['allUsers']}]}
        seen=[]
        def reply(method,url,body=None,headers=None):
            if method=='GET':return 200,{'ready':True}
            seen.append(body);return 401,{'error':'AUTH_REQUIRED','technical_content':False}
        with patch.object(core,'read',side_effect=lambda path:inspection if path=='inspection.json' else {'policy':policy}),\
            patch.object(core,'check_current',return_value={}),patch.object(core.run,'api',return_value=policy),\
            patch.object(core,'ledger_audit',side_effect=[{'retained':1},{'retained':2}]),\
            patch.object(core,'anonymous_json',side_effect=reply),patch.object(core.rollback,'get_health',return_value={'health':{'ready':True}}),\
            patch.object(core,'write') as write:
            with self.assertRaisesRegex(ValueError,'CHANGED_PROVIDER_ALLOCATION'):core.probe(name)
            self.assertEqual(seen,[{}, {}, {}]);write.assert_not_called()

if __name__=='__main__':unittest.main()
