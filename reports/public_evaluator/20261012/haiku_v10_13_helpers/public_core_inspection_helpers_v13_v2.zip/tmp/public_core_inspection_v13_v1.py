"""Owner-approved anonymous core inspection, retaining signed operation gates."""
from copy import deepcopy
from datetime import datetime,timezone
import base64
import hashlib
import json
from pathlib import Path
import sys
import time
from urllib.error import HTTPError

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'))
import public_cloud_run_v10_13_v2 as run
import private_acceptance_console_v10_13_v2 as console
import rollback_public_v10_13 as rollback
import public_ui_preview_v13_v2 as preview
cloud=run.cloud
OUT=cloud.OUT/'haiku_v10_13_helpers/public_core_inspection_v1'
QDRANT='motomedic-qdrant'
SERVICES=('motomedic-arm-a','motomedic-answer-worker',QDRANT)
URLS={'motomedic-arm-a':run.BACKEND_URL,'motomedic-answer-worker':run.WORKER_URL,
    QDRANT:'https://motomedic-qdrant-279945185781.us-central1.run.app'}
AUTH_REVIEW=cloud.OUT/'public_review/auth_source_review_v1.json'
QDRANT_PROOF=cloud.OUT/'haiku_v10_13_helpers/qdrant_image_proof_v1/image_source_receipt.json'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def write(name,value):
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/name).open('x',encoding='utf-8') as target:json.dump(value,target,indent=2,sort_keys=True);target.write('\n')

def public_invoker_policy(policy):
    """The sole IAM difference is allUsers in one unconditioned invoker row."""
    if not policy.get('etag'):raise ValueError('CORE_IAM_CONCURRENCY_ETAG_REQUIRED')
    if any(set(row.get('members',[])).intersection(rollback.PUBLIC_MEMBERS) for row in policy.get('bindings',[])):
        raise ValueError('CORE_ALREADY_PUBLIC_REQUIRE_EXISTING_INSPECTION_RECEIPT')
    value=deepcopy(policy)
    rows=[row for row in value.get('bindings',[]) if row.get('role')=='roles/run.invoker' and not row.get('condition')]
    if len(rows)>1:raise ValueError('AMBIGUOUS_CORE_INVOKER_BINDING')
    if rows:rows[0]['members'].append('allUsers')
    else:value.setdefault('bindings',[]).append({'role':'roles/run.invoker','members':['allUsers']})
    return value

def policy_rows(policy):return sorted(rollback.digest(row) for row in policy.get('bindings',[]))

def auth_review(binding,manifest):
    value=json.loads(AUTH_REVIEW.read_bytes())
    if (value.get('schema')!='motomedic-public-inspection-auth-source-review-v1' or value.get('passed')is not True or
        value.get('serving_manifest_sha256')!=binding['serving_manifest_sha256'] or value.get('provider_calls')!=0 or value.get('cloud_calls')!=0):
        raise ValueError('CURRENT_PUBLIC_AUTH_SOURCE_REVIEW_REQUIRED')
    required={'cloud/arm_a/public_inspection_auth.py','cloud/arm_a/app.py','cloud/arm_a/rider_api.py',
        'cloud/arm_a/durable_dispatch.py','cloud/arm_a/public_admission.py','cloud/arm_a/test_public_inspection_auth.py'}
    hashes=value.get('source_sha256',{})
    if set(hashes)!=required or any(sha(ROOT/name)!=expected or manifest['file_sha256'].get(name)!=expected for name,expected in hashes.items()):
        raise ValueError('FROZEN_CORE_AUTH_REVIEWED_SOURCE_CHANGED')
    checks=value.get('checks',{})
    keys=('anonymous_health_only_when_inspection_flag_true','existing_signed_visitor_and_tasks_bindings_retained',
        'foreign_signed_service_account_and_valid_visitor_cookie_denied_before_dispatch',
        'google_signature_issuer_audience_and_verified_caller_allowlist_required','private_behavior_preserved',
        'stripped_alternate_header_cannot_override_verified_identity')
    if any(checks.get(key)is not True for key in keys) or checks.get('tests_passed')!=49:
        raise ValueError('PUBLIC_CORE_AUTH_BOUNDARY_SYNTHETIC_CHECKS_REQUIRED')
    return {'path':AUTH_REVIEW.relative_to(ROOT).as_posix(),'sha256':sha(AUTH_REVIEW),'source_sha256':hashes}

def qdrant_proof():
    value=json.loads(QDRANT_PROOF.read_bytes());status=json.loads((ROOT/'cloud/deployment_status.json').read_bytes())
    if (value.get('schema')!='motomedic-existing-qdrant-read-only-image-source-proof-v1' or value.get('image')!=status['image'] or
        value.get('qdrant_started')is not False or value.get('index_download_or_load')is not False or value.get('provider_calls')!=0 or
        value.get('actual_baked_wrapper',{}).get('matches_reviewed_source')is not True or
        value.get('read_only_endpoints')!=['GET /health','POST /query'] or
        value.get('actual_baked_wrapper',{}).get('actual_boot_sha256')!=sha(ROOT/'cloud/qdrant/boot.py') or
        any(sha(ROOT/name)!=expected for name,expected in value.get('file_sha256',{}).items())):
        raise ValueError('ACTUAL_EXISTING_QDRANT_READ_ONLY_IMAGE_SOURCE_PROOF_REQUIRED')
    return {'path':QDRANT_PROOF.relative_to(ROOT).as_posix(),'sha256':sha(QDRANT_PROOF),'proof':value},status

def actual_revision(name,binding):
    service=run.api('GET',run.PREFIX+name)
    if service.get('invokerIamDisabled')is True or service.get('reconciling')is True or service.get('terminalCondition',{}).get('state')!='CONDITION_SUCCEEDED':
        raise ValueError('EXACT_CORE_SERVICE_READY_AND_IAM_CHECK_REQUIRED')
    revision=rollback.routed_revision(service);actual=run.api('GET',run.PREFIX+name+'/revisions/'+revision)
    rollback.require_ready_revision(actual,revision);configuration=rollback.revision_configuration(actual,service['template'])
    if name!=QDRANT:
        rollback.require_service(name,service,binding);run.require_inspection_environment(name,actual)
    else:
        proof,status=qdrant_proof();container=configuration['containers'][0]
        env=container.get('env',[]);values={row['name']:row.get('value') for row in env}
        if (len(values)!=len(env) or container['image']!=status['image'] or configuration.get('serviceAccount')!='motomedic-qdrant@'+cloud.PROJECT+'.iam.gserviceaccount.com' or
            values.get('INDEX_ID')!=status['selected_index_id'] or values.get('INDEX_BUNDLE_SHA256')!=status['index_bundle_sha256'] or
            values.get('INDEX_BUNDLE_URL')!='https://storage.googleapis.com/'+status['index_bundle_uri'][5:] or
            configuration.get('scaling')!={'minInstanceCount':1,'maxInstanceCount':1}):
            raise ValueError('EXACT_EXISTING_QDRANT_IMAGE_INDEX_CONFIGURATION_REQUIRED')
    return service,{'revision':revision,'image':configuration['containers'][0]['image'],
        'revision_configuration':configuration,'revision_configuration_sha256':rollback.digest(configuration)}

def ledger_audit():
    """Hash full REST fields without retaining events or unrelated raw metadata."""
    names=('grounded-primary-nonrecurring-v1','owner-haiku-fallback-20261011-validation-v1',
        'grounded-primary-nonrecurring-v1-owner-token-ceiling-grant-v1','grounded-provider-global-v1')
    result={}
    for name in names:
        url='https://firestore.googleapis.com/v1/projects/'+cloud.PROJECT+'/databases/(default)/documents/arm_a_usage/'+name
        try:value=run.api('GET',url)
        except RuntimeError as error:
            if 'RUN_HTTP_404:' not in str(error) or name in names[:2]:raise
            result[name]={'exists':False};continue
        fields=value.get('fields',{})
        result[name]={'exists':True,'complete_fields_sha256':rollback.digest(fields)}
    return result

def prepare(scope_path,guard_path):
    if (OUT/'inspection.json').exists():raise ValueError('NEVER_OVERWRITE_CORE_OPENING_INSPECTION')
    scope=preview.owner_scope(scope_path);guard=preview.guard_receipt(guard_path);authorized=scope['scope']['authorized']
    if authorized.get('anonymous_backend_worker_health_inspection')is not True or authorized.get('public_qdrant_existing_read_only_wrapper')is not True:
        raise ValueError('DIRECT_OWNER_ANONYMOUS_CORE_INSPECTION_SCOPE_REQUIRED')
    binding,manifest=rollback.release();auth=auth_review(binding,manifest);qproof,status=qdrant_proof()
    readiness_path=cloud.OUT/'private_readiness_v10_13_v2.json';readiness=json.loads(readiness_path.read_bytes())
    if readiness.get('serving_manifest_sha256')!=binding['serving_manifest_sha256']:raise ValueError('CORE_PRIVATE_READINESS_MANIFEST_CHANGED')
    preview_path=preview.OUT/'public_health.json';ui_preview=json.loads(preview_path.read_bytes())
    if ui_preview.get('binding')!=binding or ui_preview.get('answer_submission_paused')is not True or ui_preview.get('quality_acceptance')is not False:
        raise ValueError('CURRENT_PAUSED_PUBLIC_UI_PREVIEW_REQUIRED')
    policies=rollback.private_policies();services={}
    for name in SERVICES:
        service,row=actual_revision(name,binding)
        if name!=QDRANT:
            prior=readiness['services'][name]
            if row['revision_configuration_sha256']!=prior.get('revision_configuration_sha256') or row['image']!=prior['image']:
                raise ValueError('EXACT_READY_CORE_CONFIGURATION_CHANGED_AFTER_READINESS')
        services[name]=row
    ui_service=run.api('GET',run.PREFIX+preview.UI);rollback.require_service(preview.UI,ui_service,binding)
    ui_revision=rollback.routed_revision(ui_service);ui_actual=run.api('GET',run.PREFIX+preview.UI+'/revisions/'+ui_revision)
    rollback.require_ready_revision(ui_actual,ui_revision);preview.paused_ui(ui_actual)
    ui_config=rollback.revision_configuration(ui_actual,ui_service['template'])
    ui_policy=run.api('GET',run.PREFIX+preview.UI+':getIamPolicy?options.requestedPolicyVersion=3')
    applied=preview.read('iam_application.json')
    if policy_rows(ui_policy)!=policy_rows(applied['ui_policy']):raise ValueError('CURRENT_PAUSED_UI_PUBLIC_POLICY_CHANGED')
    inspection={'schema':'motomedic-owner-approved-core-inspection-preparation-v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'binding':binding,'owner_scope':scope,'guard':guard,'auth_review':auth,'qdrant_image_source_proof':qproof,
        'private_readiness_sha256':sha(readiness_path),'paused_ui_preview_sha256':sha(preview_path),'services':services,
        'prior_core_policies':policies,'ui_policy_sha256':rollback.digest(ui_policy),'ui_revision':ui_revision,
        'ui_configuration_sha256':rollback.digest(ui_config),'ledger_before':ledger_audit(),
        'quality_acceptance':False,'provider_calls':0,'billing_changed':False,'counter_writes':0}
    write('inspection.json',inspection);return {'prepared':True,'core_services':list(SERVICES),'provider_calls':0,'public_iam_changed':False}

def check_current(name,inspection):
    binding,manifest=rollback.release()
    if binding!=inspection['binding']:raise ValueError('PUBLIC_CORE_FROZEN_BINDING_CHANGED')
    auth_review(binding,manifest);qdrant_proof()
    current_scope=preview.owner_scope(inspection['owner_scope']['path'])
    if current_scope!=inspection['owner_scope']:raise ValueError('PUBLIC_CORE_OWNER_SCOPE_CHANGED')
    preview.guard_receipt(inspection['guard']['path'])
    ui=run.api('GET',run.PREFIX+preview.UI);rollback.require_service(preview.UI,ui,binding)
    ui_revision=rollback.routed_revision(ui);ui_actual=run.api('GET',run.PREFIX+preview.UI+'/revisions/'+ui_revision)
    rollback.require_ready_revision(ui_actual,ui_revision);preview.paused_ui(ui_actual)
    ui_config=rollback.revision_configuration(ui_actual,ui['template'])
    ui_policy=run.api('GET',run.PREFIX+preview.UI+':getIamPolicy?options.requestedPolicyVersion=3')
    if (ui_revision!=inspection['ui_revision'] or rollback.digest(ui_config)!=inspection['ui_configuration_sha256'] or
        rollback.digest(ui_policy)!=inspection['ui_policy_sha256']):raise ValueError('PUBLIC_CORE_PAUSED_UI_CONFIG_OR_POLICY_CHANGED')
    service,row=actual_revision(name,binding)
    if row!=inspection['services'][name]:raise ValueError('PUBLIC_CORE_ACTUAL_ROUTED_REVISION_CONFIGURATION_CHANGED')
    return service

def open_service(name):
    if name not in SERVICES:raise ValueError('ONE_EXACT_CORE_INSPECTION_SERVICE_REQUIRED')
    target='iam_'+name+'.json'
    if (OUT/target).exists():raise ValueError('CORE_PUBLIC_IAM_ALREADY_RECORDED_USE_PROBE')
    inspection=read('inspection.json');check_current(name,inspection)
    prior=inspection['prior_core_policies'][name];expected=public_invoker_policy(prior)
    current=run.api('GET',run.PREFIX+name+':getIamPolicy?options.requestedPolicyVersion=3')
    recovered=False
    if policy_rows(current)==policy_rows(prior):
        if current.get('etag')!=prior.get('etag'):raise ValueError('CORE_PRIOR_IAM_ETAG_CHANGED_REQUIRE_FRESH_REVIEW')
        run.api('POST',run.PREFIX+name+':setIamPolicy',{'policy':expected})
    elif policy_rows(current)==policy_rows(expected):recovered=True
    else:raise ValueError('CORE_IAM_CHANGED_OUTSIDE_EXACT_OWNER_APPROVED_ADDITION')
    after=run.api('GET',run.PREFIX+name+':getIamPolicy?options.requestedPolicyVersion=3')
    if policy_rows(after)!=policy_rows(expected):raise ValueError('EXACT_CORE_PUBLIC_INVOKER_READBACK_FAILED')
    check_current(name,inspection)
    write(target,{'schema':'motomedic-core-public-invoker-application-v1','service':name,'policy':after,
        'prior_policy_sha256':rollback.digest(prior),'inspection_sha256':sha(OUT/'inspection.json'),
        'all_users_invoker_only_added':True,'unrelated_policy_rows_preserved':True,'existing_exact_public_policy_recovered':recovered,
        'provider_calls':0,'quality_acceptance':False})
    return {'service':name,'public_url':URLS[name],'all_users_invoker_only_added':True,'provider_calls':0,'anonymous_probe_pending':True}

def anonymous_json(method,url,body=None,headers=None):
    request=cloud.Request(url,method=method,data=None if body is None else json.dumps(body).encode(),
        headers={'Content-Type':'application/json',**(headers or {})})
    try:
        with cloud.build_opener(cloud.NoRedirect()).open(request,timeout=45) as response:
            return response.status,json.loads(response.read(65536))
    except HTTPError as error:
        raw=error.read(65536)
        try:value=json.loads(raw)
        except ValueError:value={'json_body':False}
        return error.code,value

def forged_token(name):
    encode=lambda value:base64.urlsafe_b64encode(json.dumps(value,separators=(',',':')).encode()).decode().rstrip('=')
    email=run.TASK_SA if name=='motomedic-answer-worker' else run.UI_SA
    claims={'iss':'https://accounts.google.com','aud':URLS[name],'sub':'public-inspection-negative-test',
        'email':email,'email_verified':True,'iat':int(time.time()),'exp':int(time.time())+600}
    return encode({'alg':'RS256','kid':'synthetic-no-google-key'})+'.'+encode(claims)+'.invalid_signature'

def probe(name):
    if name not in SERVICES:raise ValueError('ONE_EXACT_CORE_INSPECTION_SERVICE_REQUIRED')
    inspection=read('inspection.json');service=check_current(name,inspection);applied=read('iam_'+name+'.json')
    current=run.api('GET',run.PREFIX+name+':getIamPolicy?options.requestedPolicyVersion=3')
    if policy_rows(current)!=policy_rows(applied['policy']):raise ValueError('PUBLIC_CORE_IAM_CHANGED_AFTER_OPENING')
    before=ledger_audit();url=URLS[name];health_path='/health' if name==QDRANT else '/v1/health'
    status,health=anonymous_json('GET',url+health_path)
    if status!=200:raise ValueError('PUBLIC_CORE_ANONYMOUS_HEALTH_NOT_READY')
    negatives=[];query=None
    if name==QDRANT:
        if health!={'index_id':'index_a3282c4d98cf54595e4ba168','points':532,
                'source_sha256':'cf221a29e2f9cd5af6e80a99774a697c814e8eda661c27d72e519d8a7e80da89'}:
            raise ValueError('PUBLIC_QDRANT_INDEX_SOURCE_HEALTH_CHANGED')
        code,result=anonymous_json('POST',url+'/query',{'vector':[0.0]*1024,'limit':1,
            'index_id':health['index_id'],'source_sha256':health['source_sha256']})
        if code!=200 or result.get('index_id')!=health['index_id'] or result.get('candidate_evidence_only')is not True or not isinstance(result.get('result'),dict):
            raise ValueError('PUBLIC_QDRANT_READ_ONLY_QUERY_NOT_READY')
        query={'http_status':code,'query_vector_dimensions':1024,'limit':1,'candidate_evidence_only':True,
            'raw_query_candidate_payload_saved':False,'result_points':len(result['result'].get('points',[]))}
    else:
        ready=rollback.get_health(name,service,inspection['binding'],url=url)
        if health!=ready['health']:raise ValueError('PUBLIC_CORE_HEALTH_IDENTITY_CHANGED')
        method,path=('POST','/internal/operations/run') if name=='motomedic-answer-worker' else ('GET','/v1/initial-catalogue')
        token=forged_token(name)
        for label,headers in (('ANONYMOUS',{}),('FORGED_AUTHORIZATION',{'Authorization':'Bearer '+token}),
            ('FORGED_ALTERNATE_HEADER',{'X-Serverless-Authorization':'Bearer '+token})):
            code,result=anonymous_json(method,url+path,{} if method=='POST' else None,headers)
            if code!=401 or result.get('error')!='AUTH_REQUIRED' or result.get('technical_content')is not False:
                raise ValueError('PUBLIC_CORE_UNSIGNED_OR_FORGED_OPERATION_NOT_REJECTED')
            negatives.append({'test':label,'method':method,'path':path,'http_status':code,'error':'AUTH_REQUIRED','technical_content':False})
    after=ledger_audit()
    if before!=after:raise ValueError('PUBLIC_INSPECTION_CHANGED_PROVIDER_ALLOCATION_OR_USAGE')
    check_current(name,inspection)
    receipt={'schema':'motomedic-public-core-anonymous-inspection-v1','service':name,'public_url':url,'binding':inspection['binding'],
        'anonymous_health':health,'negative_auth_checks':negatives,'read_only_query':query,'ledger_before':before,'ledger_after':after,
        'ledger_unchanged':True,'worker_probe_has_no_operation_owner_or_payload_identifiers':True,
        'provider_calls_by_probe':0,'signed_operation_gates_preserved':name!=QDRANT,
        'ui_answers_remain_paused_required':True,'quality_acceptance':False,'human_signoff':False,
        'inspection_sha256':sha(OUT/'inspection.json'),'iam_application_sha256':sha(OUT/('iam_'+name+'.json'))}
    write('anonymous_'+name+'.json',receipt);return {'service':name,'public_url':url,'anonymous_inspection_passed':True,'provider_calls':0,'quality_acceptance':False}

if __name__=='__main__':
    cloud.token=console.token
    if sys.argv[1:]==['--check-only']:print(json.dumps({'actions':['prepare','open_service','probe'],'provider_calls':0,
        'exact_owner_scope_and_crypto_frozen_source_tests_required':True,'qdrant_baked_read_only_wrapper_proof_required':True,
        'ui_paused_preview_required':True,'quality_acceptance':False,'cloud_actions_executed':False}))
    elif len(sys.argv)==4 and sys.argv[1]=='prepare':print(json.dumps(prepare(sys.argv[2],sys.argv[3])))
    elif len(sys.argv)==3 and sys.argv[1]in ('open_service','probe'):print(json.dumps(globals()[sys.argv[1]](sys.argv[2])))
    else:raise SystemExit('ONE_EXACT_PUBLIC_CORE_INSPECTION_ACTION_REQUIRED')
