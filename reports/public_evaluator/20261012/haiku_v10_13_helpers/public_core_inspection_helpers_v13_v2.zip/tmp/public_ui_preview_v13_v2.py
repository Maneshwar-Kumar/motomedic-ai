"""Separate owner-ordered shell preview; full semantic release gates stay intact."""
from datetime import datetime,timezone
from hashlib import sha256
import json
from pathlib import Path
import sys
import urllib.error

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'))
import rollback_public_v10_13 as rollback
import private_acceptance_console_v10_13_v2 as console
import public_cloud_run_v10_13_v2 as inspection_run
cloud=rollback.cloud
OUT=cloud.OUT/'haiku_v10_13_helpers/ui_preview_v2'
FLAG='MOTOMEDIC_RIDER_ANSWERS_ENABLED'
UI='motomedic-rider-ui'
URL='https://motomedic-rider-ui-279945185781.us-central1.run.app'

def digest_file(path):return sha256(path.read_bytes()).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def write(name,value):
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/name).open('x',encoding='utf-8') as target:target.write(json.dumps(value,indent=2,sort_keys=True)+'\n')

def owner_scope(path):
    resolved=(ROOT/path).resolve()
    if not resolved.is_relative_to(cloud.OUT):raise ValueError('EXACT_PRIVATE_PREVIEW_OWNER_RECEIPT_REQUIRED')
    value=json.loads(resolved.read_bytes());authorized=value.get('authorized',{});constraints=value.get('implementation_constraints',{})
    if (value.get('schema')!='motomedic-owner-public-review-scope-v1' or
        value.get('authority')!='DIRECT_USER_INSTRUCTION' or
        authorized.get('public_ui_preview_before_factual_acceptance')is not True or
        constraints.get('preview_answer_submission_paused')is not True or
        constraints.get('quality_acceptance_not_claimed_by_publication')is not True or
        constraints.get('historical_charges_and_existing_dollar_inr_attempt_limits_unchanged')is not True or
        constraints.get('no_billing_restart')is not True or
        type(value.get('exact_user_instructions'))is not list or not value['exact_user_instructions']):
        raise ValueError('EXACT_OWNER_PREVIEW_ORDER_AND_PAUSED_ANSWER_SCOPE_REQUIRED')
    return {'path':resolved.relative_to(ROOT).as_posix(),'sha256':digest_file(resolved),'scope':value}


def guard_receipt(path):
    resolved=(ROOT/path).resolve()
    if not resolved.is_relative_to(cloud.OUT/'operations'):raise ValueError('PRIVATE_CURRENT_GUARD_RECEIPT_REQUIRED')
    value=json.loads(resolved.read_bytes())
    age=(datetime.now(timezone.utc)-datetime.fromisoformat(value['read_at_utc'])).total_seconds()
    if (value.get('recorded_scope_matches')is not True or not 0<=age<=1800 or
        value.get('provider_calls')!=0 or value.get('billing_changed')is not False or
        value.get('guard_settings',{}).get('BUDGET_INR')!='2700' or value['guard_settings'].get('STOP_INR')!='2540' or
        value.get('billing_enabled',{}).get(cloud.PROJECT)is not True or
        value['billing_enabled'].get('motomedic-inference-20261009')is not False):raise ValueError('UNCHANGED_FRESH_PREVIEW_GUARD_REQUIRED')
    return {'path':resolved.relative_to(ROOT).as_posix(),'sha256':digest_file(resolved),'delayed_reporting_prevents_instantaneous_cap':True}

def paused_ui(actual):
    rows=[row for row in actual.get('containers',[{}])[0].get('env',[]) if row.get('name')==FLAG]
    if len(rows)!=1 or rows[0].get('value')!='false' or 'valueSource' in rows[0]:raise ValueError('ACTUAL_ROUTED_UI_ANSWER_SUBMISSION_MUST_BE_PAUSED')
    return True

def inspect(scope_path,guard_path):
    scope=owner_scope(scope_path);guard=guard_receipt(guard_path);binding,_=rollback.release()
    readiness_path=cloud.OUT/'private_readiness_v10_13_v2.json';ready=json.loads(readiness_path.read_bytes())
    if ready.get('serving_manifest_sha256')!=binding['serving_manifest_sha256']:raise ValueError('PREVIEW_PRIVATE_READINESS_BINDING_CHANGED')
    policies=rollback.private_policies(include_ui=True);identity=console.sdk_identity('print-identity-token');services={}
    for name in rollback.run.NAMES:
        service=rollback.run.api('GET',rollback.run.PREFIX+name);rollback.require_service(name,service,binding)
        revision=rollback.routed_revision(service);actual=rollback.run.api('GET',rollback.run.PREFIX+name+'/revisions/'+revision)
        ready_conditions=[row for row in actual.get('conditions',[]) if row.get('type')=='Ready']
        if actual.get('name','').split('/')[-1]!=revision or len(ready_conditions)!=1 or ready_conditions[0].get('state')!='CONDITION_SUCCEEDED':
            raise ValueError('PREVIEW_EXACT_ROUTED_REVISION_NOT_READY')
        configuration=rollback.revision_configuration(actual,service['template'])
        inspection_run.require_inspection_environment(name,actual)
        if name==UI:paused_ui(actual)
        health=rollback.get_health(name,service,binding,identity)
        expected=ready['services'][name]
        if (expected['image']!=service['template']['containers'][0]['image'] or health.get('health')!=expected['health'] or
                expected.get('revision')!=revision or expected.get('revision_configuration_sha256')!=rollback.digest(configuration)):
            raise ValueError('PREVIEW_ACTUAL_PRIVATE_IMAGE_OR_HEALTH_CHANGED')
        services[name]={'revision':revision,'image':expected['image'],'actual_configuration_sha256':rollback.digest(configuration),'health':health,
            'ui_answer_submission_paused':name==UI}
    return {'schema':'motomedic-owner-ordered-public-ui-preview-inspection-v2','binding':binding,'owner_order':scope,
        'guard':guard,'private_readiness_sha256':digest_file(readiness_path),'services':services,
        'private_policy_sha256':{name:rollback.digest(policy) for name,policy in policies.items()},
        'prior_ui_policy':policies[UI],'quality_acceptance':False,'semantic_release_gate_bypassed_for_shell_only_by_owner_order':True,
        'public_manual_in_repository_authorization':scope['scope']['authorized'].get('public_manual_and_manual_evidence_in_repository')is True,
        'browser_source_excerpts_added_by_this_action':False,'ui_only_answer_gate_paused':True,
        'private_backend_and_worker_engineering_validation_remains_enabled':True,'provider_calls':0,'cloud_mutations':0},policies

def open_preview(scope_path,guard_path):
    if any((OUT/name).exists() for name in ('inspection.json','iam_application.json','public_health.json')):
        raise ValueError('PREVIEW_ALREADY_RECORDED_USE_READBACK')
    inspection,policies=inspect(scope_path,guard_path);write('inspection.json',inspection)
    updated=rollback.ui_public_policy(policies[UI]);rollback.run.api('POST',rollback.run.PREFIX+UI+':setIamPolicy',{'policy':updated})
    after=rollback.run.api('GET',rollback.run.PREFIX+UI+':getIamPolicy?options.requestedPolicyVersion=3')
    if sorted(map(rollback.digest,after.get('bindings',[])))!=sorted(map(rollback.digest,updated['bindings'])):
        raise ValueError('EXACT_UI_PREVIEW_IAM_READBACK_FAILED')
    core=rollback.private_policies()
    if any(rollback.digest(core[name])!=inspection['private_policy_sha256'][name] for name in rollback.CORE):
        raise ValueError('PRIVATE_BACKEND_WORKER_QDRANT_CHANGED_DURING_PREVIEW')
    write('iam_application.json',{'schema':'motomedic-public-ui-preview-iam-v2','binding':inspection['binding'],
        'inspection_sha256':digest_file(OUT/'inspection.json'),'ui_policy':after,'core_private_unchanged':True,
        'answer_submission_paused':True,'quality_acceptance':False,'provider_calls':0})
    return public_health()

def public_health():
    inspection=read('inspection.json');applied=read('iam_application.json');binding,_=rollback.release()
    if inspection['binding']!=binding or applied['binding']!=binding:raise ValueError('PUBLIC_PREVIEW_BINDING_CHANGED')
    core=rollback.private_policies()
    if any(rollback.digest(core[name])!=inspection['private_policy_sha256'][name] for name in rollback.CORE):raise ValueError('PUBLIC_PREVIEW_CORE_IAM_CHANGED')
    service=rollback.run.api('GET',rollback.run.PREFIX+UI);rollback.require_service(UI,service,binding)
    revision=rollback.routed_revision(service);actual=rollback.run.api('GET',rollback.run.PREFIX+UI+'/revisions/'+revision);rollback.require_ready_revision(actual,revision);paused_ui(actual)
    configuration=rollback.revision_configuration(actual,service['template'])
    if revision!=inspection['services'][UI]['revision'] or rollback.digest(configuration)!=inspection['services'][UI]['actual_configuration_sha256']:
        raise ValueError('PUBLIC_PREVIEW_ROUTED_UI_CONFIG_CHANGED')
    policy=rollback.run.api('GET',rollback.run.PREFIX+UI+':getIamPolicy?options.requestedPolicyVersion=3')
    if sorted(map(rollback.digest,policy.get('bindings',[])))!=sorted(map(rollback.digest,applied['ui_policy'].get('bindings',[]))):
        raise ValueError('PUBLIC_PREVIEW_UI_IAM_CHANGED')
    try:health=rollback.get_health(UI,service,binding,url=URL)
    except urllib.error.HTTPError as error:
        if error.code not in (403,503):raise
        return {'public_url':URL,'anonymous_ui_health_ready':False,'verification_pending':True,'quality_acceptance':False,'provider_calls':0}
    result={'schema':'motomedic-public-ui-shell-preview-v2','public_url':URL,'binding':binding,'ui_revision':revision,
        'anonymous_ui_health':health,'answer_submission_paused':True,'quality_acceptance':False,
        'actual_answer_vs_manual_tests_completed':False,'full_release_accepted':False,'core_private_unchanged':True,
        'owner_order_sha256':inspection['owner_order']['sha256'],'iam_application_sha256':digest_file(OUT/'iam_application.json'),
        'public_browser_preview_observer_pending':True,'provider_calls':0,'billing_changed':False}
    write('public_health.json',result);return {'public_url':URL,'anonymous_ui_health_ready':True,'answer_submission_paused':True,'quality_acceptance':False,'provider_calls':0}

if __name__=='__main__':
    cloud.token=console.token
    if sys.argv[1:]==['--check-only']:print(json.dumps({'separate_preview_actions':['open_preview','public_health'],
        'full_release_gate_unchanged':True,'ui_only':True,'answer_submission_paused_required':True,'provider_calls':0,'cloud_actions_executed':False}))
    elif len(sys.argv)==4 and sys.argv[1]=='open_preview':print(json.dumps(open_preview(sys.argv[2],sys.argv[3])))
    elif sys.argv[1:]==['public_health']:print(json.dumps(public_health()))
    else:raise SystemExit('ONE_EXACT_OWNER_ORDERED_PREVIEW_ACTION_REQUIRED')
