"""Synthetic client grant decoding and isolated module packaging checks."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp/public_evaluator'));sys.path.insert(0,str(ROOT/'tmp'))
import hosted_client_v10_13 as client
from test_haiku_helpers_v10_13 import fixtures
import phase_budget_v10_13 as phase
from cloud.grounded_generation.role_router import ROUTING_CONTRACT

class CapacityReaderTests(unittest.TestCase):
    def test_raw_nested_grant_types_survive_firestore_transport_decoding(self):
        wire={'mapValue':{'fields':{'authority':{'stringValue':'SYNTHETIC_TEST'},
            'maximum_tokens':{'integerValue':'2000000'},'owner_approved':{'booleanValue':True},
            'binding':{'mapValue':{'fields':{'sha256':{'stringValue':'a'*64}}}},
            'unchanged':{'arrayValue':{'values':[{'integerValue':'24'},{'booleanValue':False}]}},
            'missing':{'nullValue':None}}}}
        decoded=client.firestore_value(wire)
        self.assertEqual(decoded,{'authority':'SYNTHETIC_TEST','maximum_tokens':2000000,
            'owner_approved':True,'binding':{'sha256':'a'*64},'unchanged':[24,False],'missing':None})
        self.assertIs(type(decoded['maximum_tokens']),int)
    def test_malformed_integer_or_unknown_transport_types_fail_closed(self):
        for value in ({'integerValue':True},{'integerValue':1},{'integerValue':'1.5'},{'doubleValue':1.0},
            {'booleanValue':1},{'stringValue':'x','integerValue':'1'}):
            with self.subTest(value=value),self.assertRaises(client.EvaluationFailure):client.firestore_value(value)
    def test_higher_token_maximum_without_exact_grant_cannot_admit_paid_job(self):
        source,receipt,ledgers,*_=fixtures();budget=phase.make_budget(receipt,source,'e'*64,ROUTING_CONTRACT)
        ledgers[phase.PRIMARY]['maximum_tokens']=2000000
        with self.assertRaisesRegex(Exception,'PRIMARY_TOKEN_CEILING_'):phase.capacity_check(budget,0,ledgers)
    def test_payload_scope_hash_drift_cannot_authorize_measured_budget(self):
        source,receipt,*_=fixtures();source['files'][phase.PAYLOAD_SCOPE_PATH]='f'*64
        with self.assertRaises(ValueError):phase.make_budget(receipt,source,'e'*64,ROUTING_CONTRACT)
    def test_token_validator_imports_from_exact_source_archive_dependencies_in_isolation(self):
        names=('cloud/grounded_generation/token_ceiling.py','cloud/grounded_generation/__init__.py',
            'cloud/grounded_generation/claude_budget.py','evidence_registry.py','generation_providers.py',
            'generation_contracts.py','controller_contracts.py')
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory:
            copied=Path(directory)
            for name in names:
                target=copied/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/name).read_bytes())
            result=subprocess.run([sys.executable,'-I','-c',
                'import sys;sys.path.insert(0,sys.argv[1]);from cloud.grounded_generation.token_ceiling import resolve_token_ceiling;print(resolve_token_ceiling({"maximum_tokens":999200},None))',
                str(copied)],capture_output=True,text=True,check=True,timeout=30)
            self.assertEqual(result.stdout.strip(),'(999200, None)')

if __name__=='__main__':unittest.main()
