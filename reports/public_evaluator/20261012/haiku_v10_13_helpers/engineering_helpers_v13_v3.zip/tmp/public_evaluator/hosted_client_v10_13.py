"""Hosted private engineering evaluator; no local providers or credentials."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
from urllib.parse import urlsplit, urlencode
import uuid

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
PLAN_SHA = 'a7dc784be633c14accdff256e57abb784a486076da07b149c6f2e04096ee5541'
PREFLIGHT_STAGE='CLIENT_IMPORTS'


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        allow_nan=False, separators=(',', ':')).encode()).hexdigest()


class EvaluationFailure(Exception):
    pass


def safe_code(value, default):
    return value if type(value) is str and re.fullmatch(r'[A-Z0-9_]{1,100}', value) else default


class Backend:
    def __init__(self, url, secret):
        import requests
        from rider_ui.identity import issue
        self.http = requests.Session()
        self.url, self.token, self.expiry = url, None, 0
        # Stable engineering principals keep owner/network admission across
        # reruns; new sessions never replenish provider allocations.
        self.visitor = issue(secret, principal='engineering-evaluator-20261012-v1')
        self.network = issue(secret, principal='engineering-evaluator-network-20261012-v1')

    def headers(self, accept, operation=None):
        if time.time() >= self.expiry - 60:
            from google.auth.transport.requests import Request
            from google.oauth2.id_token import fetch_id_token
            try:
                token = fetch_id_token(Request(), self.url)
                payload = json.loads(base64.urlsafe_b64decode(token.split('.')[1] +
                    '=' * (-len(token.split('.')[1]) % 4)))
                if payload.get('aud') != self.url or payload['exp'] <= time.time():
                    raise ValueError()
                self.token, self.expiry = token, payload['exp']
            except Exception:
                raise EvaluationFailure('HOSTED_ID_TOKEN_UNAVAILABLE') from None
        result = {'Authorization':'Bearer '+self.token, 'Accept':accept,
            'X-MotoMedic-Visitor':self.visitor, 'X-MotoMedic-Network':self.network}
        if operation:
            result['Idempotency-Key'] = operation
        return result

    def request(self, method, path, *, body=None, operation=None, sse=False):
        try:
            response = self.http.request(method, self.url+path, json=body,
                headers=self.headers('text/event-stream' if sse else 'application/json', operation),
                stream=True, timeout=(15, 170 if sse else 35), allow_redirects=False)
        except EvaluationFailure:
            raise
        except Exception:
            raise EvaluationFailure('BACKEND_TRANSPORT_UNCERTAIN_NO_POST_RETRY') from None
        if sse and response.status_code == 200:
            return response
        try:
            raw = bytearray()
            for chunk in response.iter_content(8192):
                raw.extend(chunk)
                if len(raw) > 256 * 1024:
                    raise EvaluationFailure('BACKEND_RESPONSE_BYTE_BOUND')
            data = json.loads(raw)
            if type(data) is not dict:
                raise ValueError()
        except EvaluationFailure:
            raise
        except Exception:
            raise EvaluationFailure('BACKEND_JSON_INVALID') from None
        finally:
            response.close()
        if response.status_code not in (200, 202):
            code = safe_code(data.get('error'), 'BACKEND_HTTP_ERROR')
            raise EvaluationFailure(code+'_'+str(response.status_code))
        return data


def firestore_value(value):
    if type(value) is not dict or len(value)!=1:raise EvaluationFailure('HOSTED_LEDGER_FIELD_SCHEMA_INVALID')
    key,item=next(iter(value.items()))
    if key=='integerValue':
        if type(item)is not str or not re.fullmatch(r'-?\d+',item):raise EvaluationFailure('HOSTED_LEDGER_INTEGER_FIELD_INVALID')
        return int(item)
    if key in ('stringValue','timestampValue'):return item
    if key=='booleanValue' and type(item)is bool:return item
    if key=='nullValue':return None
    if key=='mapValue':return {name:firestore_value(nested) for name,nested in item.get('fields',{}).items()}
    if key=='arrayValue':return [firestore_value(nested) for nested in item.get('values',[])]
    raise EvaluationFailure('HOSTED_LEDGER_FIELD_TYPE_INVALID')


def ledger(project):
    """Optional engineering readback; never changes Firestore/IAM/allocation."""
    import google.auth
    from google.auth.transport.requests import AuthorizedSession
    from cloud.grounded_generation.token_ceiling import GRANT_DOCUMENT
    credentials,_=google.auth.default(scopes=['https://www.googleapis.com/auth/datastore'])
    client=AuthorizedSession(credentials)
    records = {}
    for name in ('grounded-primary-nonrecurring-v1',
                 'owner-haiku-fallback-20261011-validation-v1',GRANT_DOCUMENT):
        response=client.get('https://firestore.googleapis.com/v1/projects/'+project+
            '/databases/(default)/documents/arm_a_usage/'+name,timeout=30,allow_redirects=False)
        if response.status_code==404:body=None
        elif response.status_code==200:
            fields=response.json().get('fields',{})
            body={key:firestore_value(value) for key,value in fields.items()}
        else:raise EvaluationFailure('HOSTED_LEDGER_READBACK_UNAVAILABLE')
        response.close()
        if name==GRANT_DOCUMENT:
            records[name]=body
            continue
        body=body or {}
        keys = ('version', 'reserved_attempts', 'reserved_tokens',
                'maximum_attempts', 'maximum_tokens', 'reserved_nanodollars',
                'reservation_count', 'maximum_nanodollars','token_ceiling_authorization')
        records[name] = {k:body[k] for k in keys if k in body}
    return records


def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False,
        allow_nan=False)+'\n', encoding='utf-8')


def completed_boundaries(backend, args, secret, path, payload, operation, view):
    """Check COMPLETE replay and another valid visitor without generating work."""
    from rider_ui.client import RUNTIME_POLICY, validate_view
    from rider_ui.identity import issue
    before = ledger(args.project)
    repeated = validate_view(backend.request('POST', path, body=payload, operation=operation),
        expected_policy=RUNTIME_POLICY)
    if repeated != view:
        raise EvaluationFailure('COMPLETE_DUPLICATE_POST_CHANGED_VIEW')
    wrong = Backend(args.backend, secret)
    wrong.visitor = issue(secret, principal='engineering-evaluator-other-20261012-v1')
    try:
        wrong.request('GET', '/v1/operations/'+operation)
    except EvaluationFailure as exc:
        if str(exc) != 'OPERATION_NOT_FOUND_404':
            raise EvaluationFailure('WRONG_VISITOR_NOT_OWNERSHIP_REJECTED') from None
    else:
        raise EvaluationFailure('WRONG_VISITOR_OPERATION_DISCLOSED')
    finally:
        wrong.http.close()
    after = ledger(args.project)
    if before != after:
        raise EvaluationFailure('COMPLETE_BOUNDARIES_CHANGED_PROVIDER_RESERVATIONS')
    return {'duplicate_post_same_operation_and_request': True,
        'duplicate_post_same_saved_view': True, 'wrong_valid_visitor_get_status': 404,
        'provider_reservations_unchanged': True, 'provider_calls': 0,
        'new_operation_or_question_created': False}


def stop_reason(result, attempted_cases, enabled):
    if not enabled:
        return None
    if result.get('route') == 'SYSTEM_ERROR' or result.get('error'):
        return 'SYSTEM_ERROR_OR_OPERATIONAL_FAILURE'
    if attempted_cases == 1 and result.get('expected_route_matched') is not True:
        return 'FIRST_CANDIDATE_PROBE_NOT_ACCEPTED'
    return None


def upload_artifacts(args):
    """Create-only uploads to the one owner-allocated private job prefix."""
    if not args.artifact_uri:
        return
    if (ROOT != Path('/workspace') or
            os.environ.get('MOTOMEDIC_HOSTED_PROVIDER_VALIDATION') != 'true' or
            not re.fullmatch(r'[0-9a-f-]{36}', os.environ.get('MOTOMEDIC_CLOUD_BUILD_ID',''))):
        raise EvaluationFailure('HOSTED_ARTIFACT_UPLOAD_CONTEXT_REQUIRED')
    target = urlsplit(args.artifact_uri)
    if (target.scheme != 'gs' or not re.fullmatch(r'[a-z0-9][a-z0-9._-]{1,220}', target.netloc) or
            target.path != '/engineering-acceptance/public-v10_3/'+args.allocated_job_id or
            target.query or target.fragment or
            not re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', args.allocated_job_id)):
        raise EvaluationFailure('EXACT_PRIVATE_ARTIFACT_PREFIX_REQUIRED')
    import google.auth
    from google.auth.transport.requests import AuthorizedSession
    credentials, _ = google.auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'])
    with AuthorizedSession(credentials) as session:
        for path in sorted(Path(args.output).glob('*.json')):
            content = path.read_bytes()
            name = target.path.lstrip('/')+'/'+path.name
            url = 'https://storage.googleapis.com/upload/storage/v1/b/'+target.netloc+'/o?'+urlencode({
                'uploadType':'media','name':name,'ifGenerationMatch':'0'})
            response = session.post(url, data=content, headers={'Content-Type':'application/json'},
                timeout=60, allow_redirects=False)
            try:
                if response.status_code not in (200, 201):
                    raise EvaluationFailure('PRIVATE_ARTIFACT_CREATE_FAILED_'+str(response.status_code))
                metadata = response.json()
                print(json.dumps({'artifact_file':path.name,'generation':str(metadata['generation']),
                    'sha256':hashlib.sha256(content).hexdigest(),'credential_logged':False}), flush=True)
            finally:
                response.close()


def run(args):
    global PREFLIGHT_STAGE
    PREFLIGHT_STAGE='CLIENT_IMPORTS'
    from rider_ui.client import MANUAL_SHA, INDEX_ID, RUNTIME_POLICY, validate_view
    from rider_ui.verified_sse import read_verified_stream, response_hash
    if (os.environ.get('MOTOMEDIC_HOSTED_PROVIDER_VALIDATION') != 'true' or
            not re.fullmatch(r'[0-9a-f-]{36}', os.environ.get('MOTOMEDIC_CLOUD_BUILD_ID','')) or
            ROOT != Path('/workspace')):
        raise EvaluationFailure('HOSTED_VALIDATION_CONTEXT_REQUIRED')
    PREFLIGHT_STAGE='SOURCE_INVENTORY'
    inventory = json.loads((ROOT/'tmp/public_evaluator/client_inputs_v10_13.json').read_bytes())
    if inventory.get('schema') != 'motomedic-hosted-evaluator-client-inputs-v1':
        raise EvaluationFailure('CLIENT_SOURCE_INVENTORY_INVALID')
    routing = inventory.get('model_routing_contract')
    if (not isinstance(routing, dict) or
            type(routing.get('version'))is not str or not routing.get('version') or
            digest(routing) != inventory.get('model_routing_contract_sha256') or
            set(routing.get('roles', {})) != {'HAIKU_DRAFT_HAIKU_VERIFY'} or
            routing.get('availability_fallback_enabled') is not False or
            routing['roles']['HAIKU_DRAFT_HAIKU_VERIFY']['draft'].get('model')!='claude-haiku-5-5' or
            routing['roles']['HAIKU_DRAFT_HAIKU_VERIFY']['verifier'].get('model')!='claude-haiku-5-5'):
        raise EvaluationFailure('CLIENT_MODEL_ROUTING_CONTRACT_INVALID')
    for relative, expected_sha in inventory['file_sha256'].items():
        source = (ROOT/relative).resolve()
        if (not source.is_relative_to(ROOT) or
                hashlib.sha256(source.read_bytes()).hexdigest() != expected_sha):
            raise EvaluationFailure('CLIENT_SOURCE_INPUT_CHANGED')
    address = urlsplit(args.backend)
    if (address.scheme != 'https' or not address.hostname or
            not address.hostname.endswith('.run.app') or address.path or
            address.query or address.fragment or address.username or address.port):
        raise EvaluationFailure('PINNED_PRIVATE_BACKEND_URL_REQUIRED')
    if not re.fullmatch(r'[0-9a-f]{64}', args.runtime_lock):
        raise EvaluationFailure('PINNED_RUNTIME_LOCK_REQUIRED')
    plan_path = ROOT / 'reports/public_evaluator/20261012/original_page_evaluator_plan_v2.json'
    if hashlib.sha256(plan_path.read_bytes()).hexdigest() != PLAN_SHA:
        raise EvaluationFailure('EVALUATOR_PLAN_IDENTITY_CHANGED')
    plan = json.loads(plan_path.read_bytes())
    PREFLIGHT_STAGE='MEASURED_BUDGET_BINDING'
    from phase_budget_v10_13 import validate_budget,capacity_check
    try:
        measured_budget = json.loads(args.measured_phase_budget_json)
        validate_budget(measured_budget, inventory, args.runtime_lock, plan)
    except Exception:
        raise EvaluationFailure('MEASURED_PHASE_CAPACITY_BINDING_CHANGED') from None
    secret = os.environ.get('MOTOMEDIC_VISITOR_SECRET', '')
    if len(secret.encode()) < 32:
        raise EvaluationFailure('MANAGED_VISITOR_SECRET_REQUIRED')
    PREFLIGHT_STAGE='PRIVATE_BACKEND_IDENTITY'
    backend = Backend(args.backend, secret)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_STAGE='PRIVATE_BACKEND_HEALTH'
    health = backend.request('GET', '/v1/health')
    expected = {'ready':True, 'manual_checksum':MANUAL_SHA, 'index_id':INDEX_ID,
        'runtime_lock':args.runtime_lock, 'answer_provider':'claude-haiku-5-5',
        'verifier_provider':'claude-haiku-5-5',
        'prompt_cache':'ANTHROPIC_ROLE_EVIDENCE_PREFIX_5M',
        'model_routing':routing,
        'architecture':'DRAFT_VERIFY_STREAM_OPEN_MANUAL_QA',
        'streaming':'DRAFT_VERIFY_STREAM',
        'reranking':'authenticated-open-hybrid-rank-disagreement-v5',
        'durable_dispatch_configured':True}
    if any(health.get(k) != v for k,v in expected.items()):
        raise EvaluationFailure('BACKEND_HEALTH_BINDING_CHANGED')
    PREFLIGHT_STAGE='PERMANENT_LEDGER_READBACK'
    before = ledger(args.project) if args.read_ledger else None
    if before is not None:
        allocation = before['grounded-primary-nonrecurring-v1']
        spent = allocation.get('reserved_attempts', 0)
        tokens = allocation.get('reserved_tokens', 0)
        from cloud.grounded_generation.token_ceiling import GRANT_DOCUMENT,resolve_token_ceiling
        maximum_tokens,_=resolve_token_ceiling(allocation,before.get(GRANT_DOCUMENT))
        if (allocation and (allocation.get('version') != 'whole-turn-capacity-v1' or
                allocation.get('maximum_attempts') != 100)):
            raise EvaluationFailure('EXISTING_PROVIDER_ALLOCATION_BINDING_CHANGED')
        if (type(spent) is not int or not 0 <= spent < 100 or
                type(tokens) is not int or not 0 <= tokens < maximum_tokens):
            raise EvaluationFailure('EXISTING_PROVIDER_ALLOCATION_EXHAUSTED')
        verifier_budget = before['owner-haiku-fallback-20261011-validation-v1']
        nanodollars = verifier_budget.get('reserved_nanodollars', 0)
        if (verifier_budget and (verifier_budget.get('version') != 'claude-fallback-nonrecurring-one-dollar-v1' or
                verifier_budget.get('maximum_nanodollars') != 1000000000)):
            raise EvaluationFailure('EXISTING_VERIFIER_ALLOCATION_BINDING_CHANGED')
        if type(nanodollars) is not int or not 0 <= nanodollars < 1000000000:
            raise EvaluationFailure('EXISTING_HAIKU_ALLOCATION_EXHAUSTED')
        # Actual route-dependent whole-turn token/cost reservations belong to
        # production admission. These readonly ledger checks assert unchanged
        # permanent guards, not affordability of unknown finalized six turns.
    PREFLIGHT_STAGE='CASE_PROVIDER_CAPACITY'
    sessions, last_case, cases = {}, {}, []
    attempted_cases, stopped_reason, boundary_checks_done = 0, None, False
    for case_index,case in enumerate(plan['cases']):
        started = time.monotonic()
        result = {'case_id':case['case_id'], 'question':case['question'],
            'question_sha256':digest(case['question']), 'session_group':case['session_group'],
            'operation_id':uuid.uuid4().hex, 'post_retries':0, 'inference_replayed':False}
        group = case['session_group']
        previous = sessions.get(group)
        predecessor = case.get('previous_case_id')
        if predecessor and (previous is None or last_case.get(group) != predecessor):
            result['error'] = 'PREDECESSOR_HAS_NO_SAVED_SESSION'
            result['status'] = 'BLOCKED_BY_PREDECESSOR'
            cases.append(result)
            save(output/(case['case_id']+'.json'), result)
            continue
        payload = {'query':case['question'], 'bike_variant':'Himalayan BS6',
            'confirmed_himalayan_bs6':True, 'manual_checksum':MANUAL_SHA,
            'index_id':INDEX_ID, 'cache_mode':'bypass'}
        path = '/v1/sessions'
        if previous:
            path += '/'+previous['session_id']+'/questions'
            payload['expected_version'] = previous['version']
            result['previous_saved_response_sha256'] = response_hash(previous)
        result['request_sha256'] = hashlib.sha256(json.dumps({'path':path,'body':payload},
            sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        result['status'] = 'POST_NOT_RETRIED'
        try:
            if not args.read_ledger:
                raise EvaluationFailure('MEASURED_CAPACITY_REQUIRES_DURABLE_LEDGER')
            result['pre_provider_capacity_check'] = capacity_check(measured_budget,case_index,ledger(args.project))
            if result['pre_provider_capacity_check']['eligible'] is not True:
                result['status'] = 'STOPPED_BEFORE_PROVIDER_WORK'
                raise EvaluationFailure('INSUFFICIENT_MEASURED_PHASE_CAPACITY')
            print(json.dumps({k:result[k] for k in ('case_id','operation_id','request_sha256','status')}), flush=True)
            attempted_cases += 1
            value = backend.request('POST', path, body=payload, operation=result['operation_id'])
            deadline = time.monotonic()+1250
            while value.get('status') == 'RUNNING':
                if value.get('operation_id') != result['operation_id'] or time.monotonic() >= deadline:
                    raise EvaluationFailure('OPERATION_WAIT_BOUND_NO_INFERENCE_RETRY')
                time.sleep(5)
                value = backend.request('GET', '/v1/operations/'+result['operation_id'])
            view = validate_view(value, expected_policy=RUNTIME_POLICY)
            if view.get('delivery', {}).get('runtime_lock') != args.runtime_lock:
                raise EvaluationFailure('SAVED_RUNTIME_LOCK_CHANGED')
            sessions[group] = view
            last_case[group] = case['case_id']
            result.update(saved_view=view, response_sha256=response_hash(view),
                route=view['response']['type'], saved_received_seconds=time.monotonic()-started)
            streamed, stages = [], []
            stream = backend.request('GET', '/v1/operations/'+result['operation_id'], sse=True)
            try:
                streamed_view = read_verified_stream(stream.iter_content(4096),
                    operation_id=result['operation_id'], on_chunk=streamed.append,
                    on_progress=stages.append, expected_policy=RUNTIME_POLICY)
            finally:
                stream.close()
            if streamed_view != view:
                raise EvaluationFailure('STREAMED_VIEW_DIFFERS_FROM_SAVED_VIEW')
            result.update(exact_saved_stream=True, streamed_text=''.join(streamed), stream_stages=stages)
            recovered = validate_view(backend.request('GET', '/v1/operations/'+result['operation_id']),
                expected_policy=RUNTIME_POLICY)
            if recovered != view:
                raise EvaluationFailure('RECOVERED_VIEW_CHANGED')
            result['exact_recovered_view'] = True
            result['status'] = 'SAVED_STREAMED_RECOVERED'
            result['expected_route_matched'] = result['route'] in case['expected_outcomes']
            if (getattr(args, 'check_completed_boundaries', False) and
                    result['expected_route_matched'] and result['route'] != 'SYSTEM_ERROR' and
                    not boundary_checks_done):
                result['completed_operation_checks'] = completed_boundaries(
                    backend, args, secret, path, payload, result['operation_id'], view)
                boundary_checks_done = True
        except EvaluationFailure as exc:
            result['error'] = safe_code(str(exc), 'ENGINEERING_VALIDATION_FAILURE')
        except Exception:
            result['error'] = 'ENGINEERING_STREAM_OR_SCHEMA_FAILURE'
        result['total_seconds'] = time.monotonic()-started
        cases.append(result)
        save(output/(case['case_id']+'.json'), result)
        print(json.dumps({k:result.get(k) for k in ('case_id','operation_id','request_sha256','status','route','error',
            'response_sha256','exact_saved_stream','exact_recovered_view','total_seconds')}), flush=True)
        stopped_reason = stop_reason(result, attempted_cases,
            getattr(args, 'stop_on_system_error', False))
        if stopped_reason:
            break
    after, ledger_after_error = None, None
    if args.read_ledger:
        try:
            after = ledger(args.project)
        except Exception:
            ledger_after_error = 'HOSTED_LEDGER_READBACK_UNAVAILABLE'
    receipt = {'schema':'motomedic-hosted-original-page-evaluator-v1',
        'classification':'HOSTED_REAL_PROVIDER_ENGINEERING_EVIDENCE_ONLY',
        'cloud_build_id':os.environ['MOTOMEDIC_CLOUD_BUILD_ID'], 'plan_sha256':PLAN_SHA,
        'allocated_job_id':args.allocated_job_id, 'client_input_inventory':inventory,
        'manual_checksum':MANUAL_SHA, 'index_id':INDEX_ID, 'runtime_lock':args.runtime_lock,
        'health':health, 'ledger_before':before, 'ledger_after':after,
        'measured_phase_budget':measured_budget,
        'ledger_after_error':ledger_after_error,
        'case_files':{c['case_id']:hashlib.sha256((output/(c['case_id']+'.json')).read_bytes()).hexdigest()
            for c in cases}, 'post_retries':0, 'allocation_reset':False, 'allocation_refund':False,
        'public_browser_acceptance':False, 'independent_factual_review_pending':True,
        'credentials_logged':False, 'raw_rider_media_logged':False}
    matched = sum(c.get('expected_route_matched') is True and c.get('exact_saved_stream') is True and
        c.get('exact_recovered_view') is True and not c.get('error') for c in cases)
    receipt.update(engineering_completed_cases=matched, case_count=len(cases),
        planned_case_count=len(plan['cases']), attempted_case_count=attempted_cases,
        stopped_early=stopped_reason is not None, stop_reason=stopped_reason,
        stop_on_system_error=getattr(args, 'stop_on_system_error', False),
        completed_operation_boundary_checks=boundary_checks_done,
        engineering_transport_and_route_passed=matched == len(plan['cases']) and stopped_reason is None,
        technical_releases=sum(c.get('route') in ('SUPPORTED','SAFETY_STOP') and
            c.get('saved_view',{}).get('response',{}).get('technical_content') is True for c in cases))
    save(output/'receipt.json', receipt)
    print(json.dumps({'receipt_sha256':hashlib.sha256((output/'receipt.json').read_bytes()).hexdigest(),
        'case_count':len(cases),'engineering_completed_cases':matched,
        'independent_factual_review_pending':True}), flush=True)
    return 0 if matched == 6 and ledger_after_error is None else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--backend', required=True)
    parser.add_argument('--runtime-lock', required=True)
    parser.add_argument('--output', default='/workspace/tmp/public_evaluator/hosted-run-v1')
    parser.add_argument('--project')
    parser.add_argument('--read-ledger', action='store_true')
    parser.add_argument('--stop-on-system-error', action='store_true')
    parser.add_argument('--check-completed-boundaries', action='store_true')
    parser.add_argument('--measured-phase-budget-json', required=True)
    parser.add_argument('--artifact-uri')
    parser.add_argument('--allocated-job-id', required=True)
    args = parser.parse_args()
    exit_code = 1
    try:
        exit_code = run(args)
    except Exception as exc:
        failure = {'error':safe_code(str(exc), 'HOSTED_EVALUATOR_PREFLIGHT_FAILURE'),
            'stage':PREFLIGHT_STAGE,
            'exception_class':type(exc).__name__ if type(exc).__name__ in ('ModuleNotFoundError','ImportError','FileNotFoundError','PermissionError','EvaluationFailure','ValueError','KeyError','TypeError') else 'UNCLASSIFIED',
            'credentials_logged':False, 'independent_factual_review_pending':True}
        print(json.dumps(failure), flush=True)
        Path(args.output).mkdir(parents=True, exist_ok=True)
        save(Path(args.output)/'preflight_failure.json', failure)
    finally:
        save(Path(args.output)/'exit_status.json', {'exit_code':exit_code,
            'allocated_job_id':args.allocated_job_id, 'independent_factual_review_pending':True})
        try:
            upload_artifacts(args)
        except Exception as exc:
            exit_code = 1
            print(json.dumps({'error':safe_code(str(exc), 'PRIVATE_ARTIFACT_UPLOAD_FAILURE'),
                'credentials_logged':False}), flush=True)
    sys.exit(exit_code)
