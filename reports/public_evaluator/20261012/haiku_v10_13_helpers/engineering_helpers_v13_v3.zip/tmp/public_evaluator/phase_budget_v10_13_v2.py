"""Read-only measured capacity checks; never allocate, refund or call providers."""
from copy import deepcopy
from decimal import Decimal, ROUND_CEILING
import hashlib
import json
import re
import uuid

OWNER_SCOPE_SHA = '65755e0a6b79f2df542c1c4b5f4f2e382a6857f7ee5ff5803d64988204e5ad0f'
PAYLOAD_SCOPE_PATH = 'reports/public_evaluator/20261012/haiku_v10_12/owner_anthropic_payload_scope_v2.json'
PAYLOAD_SCOPE_SHA = 'cf469c78449b70bba8cfc245cbb6ed5f3cf301e56102e1fe7fc2f1c415d189e9'
SCHEMA = 'motomedic-measured-initial-phase-capacity-v2'
PRIMARY = 'grounded-primary-nonrecurring-v1'
HAIKU_BUDGET = 'owner-haiku-fallback-20261011-validation-v1'
UNKNOWN = 'UNKNOWN_MANDATORY_ACTUAL_FINAL_COUNT'
NATIVE_STAGES = ('SELECTED_DRAFT','VERIFIER_WORST_STRUCTURAL_SCAFFOLD',
    'VERIFIER_BASE_FULLSOURCE_PREFIX','CORRECTION_WORST_STRUCTURAL_SCAFFOLD',
    'VERIFIER_SYNTHETIC_STRESS_ENVELOPE','VERIFIER_MINIMUM_OUTPUT_SHAPE')


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        allow_nan=False, separators=(',', ':')).encode()).hexdigest()


def integer(value, *, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError('MEASURED_CAPACITY_INTEGER_INVALID')
    return value


def total(rows):
    return {key: sum(row[key] for row in rows)
        for key in ('attempts', 'tokens', 'haiku_nanodollars')}


def phase_totals(slots, routing, role_plan, stages):
    pair = routing['roles'].get(role_plan.get('route'))
    if (not pair or role_plan.get('version') != routing['version'] or
            role_plan.get('routing_contract_sha256') != digest(routing) or
            role_plan.get('draft_model_contract_sha256') != digest(pair['draft']) or
            role_plan.get('verifier_contract_sha256') != digest(pair['verifier']) or
            type(slots) is not list or len(slots) != 2):
        raise ValueError('MEASURED_PHASE_ROLE_BINDING_CHANGED')
    primary_count=integer(role_plan.get('primary_input_tokens_counted'),minimum=1)
    if (set(routing['roles'])!={'HAIKU_DRAFT_HAIKU_VERIFY'} or
            role_plan['route']!='HAIKU_DRAFT_HAIKU_VERIFY' or
            primary_count!=role_plan.get('selected_draft_input_tokens')):
        raise ValueError('MEASURED_PHASE_FIXED_PAIR_CHANGED')
    for key in ('initial_draft_request_sha256', 'stable_context_sha256'):
        if not re.fullmatch(r'[0-9a-f]{64}', role_plan.get(key, '')):
            raise ValueError('MEASURED_PHASE_REQUEST_IDENTITY_MISSING')
    expected = [(stage, provider, attempt) for stage, provider in
        ((stages[0], pair['draft']), (stages[1], pair['verifier']))
        for attempt in range(1, provider['maximum_attempts_per_call'] + 1)]
    values = []
    for slot, (stage, provider, attempt) in zip(slots, expected, strict=True):
        allowed = {'model', 'stage', 'input_tokens', 'output_tokens', 'attempt'}
        if provider['provider'] == 'anthropic': allowed.add('maximum_nanodollars')
        if (type(slot) is not dict or set(slot) != allowed or
                slot['stage'] != stage or slot['model'] != provider['model'] or
                type(slot['attempt']) is not int or slot['attempt'] != attempt):
            raise ValueError('MEASURED_PHASE_SLOT_CHANGED')
        count = integer(slot['input_tokens'], minimum=1)
        output = integer(slot['output_tokens'], minimum=1)
        if count > provider['input_tokens'] or output != provider['output_tokens']:
            raise ValueError('MEASURED_PHASE_NATIVE_WINDOW_CHANGED')
        cost = 0
        if provider['provider'] == 'anthropic':
            prices = provider['pricing']
            band = prices['long_usd_per_million'] if count > prices['long_context_above_input_tokens'] else prices['base_usd_per_million']
            cost = int(((Decimal(count)*Decimal(str(band['cache_write'])) +
                Decimal(output)*Decimal(str(band['output'])))*1000).to_integral_value(rounding=ROUND_CEILING))
            if integer(slot['maximum_nanodollars'], minimum=1) != cost:
                raise ValueError('MEASURED_PHASE_HAIKU_WRITE_COST_CHANGED')
        values.append({'attempts': 1, 'tokens': count + output, 'haiku_nanodollars': cost})
    if stages[0] == 'draft':
        counted = integer(role_plan.get('selected_draft_input_tokens'), minimum=1)
        expected_initial = min(pair['draft']['input_tokens'], counted + 512) if pair['draft']['provider'] == 'anthropic' else counted
        if slots[0]['input_tokens'] != expected_initial:
            raise ValueError('MEASURED_INITIAL_NATIVE_COUNT_OR_COUNTER_HEADROOM_CHANGED')
    return total(values)


def make_budget(receipt, source, receipt_sha, routing):
    """Only the already verified count receipt supplies measured phase slots."""
    modules=('tools.check_installed_serving_release','cloud.serving_artifacts',
        'cloud.grounded_generation.cached_verifier','cloud.grounded_generation.role_router',
        'cloud.grounded_generation.verified_qa','cloud.grounded_generation.serving_source_authority')
    origins=source.get('expected_frozen_runtime_module_origins')
    if (source.get('count_module_origin_policy')!='ACTUAL_FROZEN_APP_IMAGE_ONLY' or
        receipt.get('runtime_module_source_scope')!='ACTUAL_FROZEN_APP_IMAGE_ONLY' or
        receipt.get('frozen_runtime_module_origins_verified')is not True or type(origins)is not dict or set(origins)!=set(modules) or
        receipt.get('runtime_module_origins')!=origins or any(type(row)is not dict or set(row)!= {'app_relative_path','sha256'} or
            row['app_relative_path']!=name.replace('.','/')+'.py' or not re.fullmatch(r'[0-9a-f]{64}',row['sha256']) for name,row in origins.items())):
        raise ValueError('MEASURED_FROZEN_RUNTIME_MODULE_ORIGINS_REQUIRED')
    if (receipt.get('schema') != 'motomedic-hosted-native-count-role-preflight-v4' or
            receipt.get('classification') != 'HOSTED_NATIVE_COUNTERS_AND_ROLE_FORECAST_ONLY' or
            receipt.get('owner_model_scope_sha256') != OWNER_SCOPE_SHA or
            receipt.get('owner_anthropic_payload_scope_sha256') != PAYLOAD_SCOPE_SHA or
            source.get('owner_anthropic_payload_scope_sha256') != PAYLOAD_SCOPE_SHA or
            source.get('files',{}).get(PAYLOAD_SCOPE_PATH) != PAYLOAD_SCOPE_SHA or
            receipt.get('model_routing_contract_sha256') != digest(routing) or
            source.get('model_routing_contract_sha256') != digest(routing) or
            receipt.get('serving_manifest_sha256') != source['serving_manifest_sha256'] or
            receipt.get('runtime_lock') != source['runtime_lock'] or
            receipt.get('script_sha256') != source['files']['tmp/public_evaluator/count_only_context_v10_13_v2.py'] or
            receipt.get('history_sha256') != source['files']['tmp/public_evaluator/count_history_v1.json'] or
            receipt.get('preflight_passed') is not True or
            any(receipt.get(key) is not True for key in (
                'selected_draft_native_window_eligible','selected_draft_counter_request_passed',
                'known_verifier_count_request_passed','verifier_synthetic_stress_native_window_eligible',
                'transport_allowlist_enforced','provider_allocation_delta_zero')) or
            any(type(receipt.get(key)) is not int or receipt.get(key) != expected for key,expected in (
                ('generation_calls',0),('reservation_calls',0),('prohibited_transport_calls',0),
                ('case_count',6),('planned_native_counter_calls',36),
                ('native_counter_calls',36),('counter_transport_calls',36),('model_metadata_transport_calls',0))) or
            not isinstance(receipt.get('ledger_before'),dict) or
            receipt.get('ledger_before') != receipt.get('ledger_after') or
            receipt.get('actual_finalized_verifier_count_demonstrated') is not False or
            receipt.get('generation_affordability_authorized') is not False or
            receipt.get('native_counter_pass_not_generation_quota_or_factual_proof') is not True or
            receipt.get('future_finalized_verifier_quota_status') != UNKNOWN or
            not re.fullmatch(r'[0-9a-f]{64}', receipt_sha) or
            str(uuid.UUID(receipt['cloud_build_id'])) != receipt['cloud_build_id'] or
            type(receipt.get('cases')) is not list or len(receipt['cases']) != 6):
        raise ValueError('MEASURED_COUNT_RECEIPT_BINDING_CHANGED')
    if receipt.get('declared_native_stage_order')!=list(NATIVE_STAGES):
        raise ValueError('MEASURED_NATIVE_STAGE_DECLARATION_CHANGED')
    rows = []
    for row in receipt['cases']:
        item = {'case_id': row['case_id'], 'question_sha256': row['question_sha256'],
            'role_plan': deepcopy(row['role_plan']),
            'initial_phase_slots': deepcopy(row['initial_phase_slots']),
            'conditional_correction_phase_slots': deepcopy(row['conditional_correction_phase_slots'])}
        item['initial_totals'] = phase_totals(item['initial_phase_slots'], routing, item['role_plan'], ('draft', 'verify'))
        item['conditional_totals'] = phase_totals(item['conditional_correction_phase_slots'], routing, item['role_plan'], ('correction', 'reverify'))
        pair=routing['roles'][item['role_plan']['route']]
        stages=row.get('native_stages',[])
        if len(stages)!=6 or [stage.get('stage') for stage in stages]!=list(NATIVE_STAGES):
            raise ValueError('MEASURED_NATIVE_COUNTER_STAGE_ORDER_CHANGED')
        for index,stage in enumerate(stages):
            provider=pair['draft'] if index in (0,3) else pair['verifier']
            if (stage.get('model')!=provider['model'] or stage.get('role')!=provider['role'] or
                    not re.fullmatch(r'[0-9a-f]{64}',stage.get('counter_body_sha256','')) or
                    type(stage.get('input_tokens_counted'))is not int or stage['input_tokens_counted']<1 or
                    type(stage.get('counter_request_bytes'))is not int or stage['counter_request_bytes']<1):
                raise ValueError('MEASURED_NATIVE_COUNTER_BODY_BINDING_CHANGED')
        if (stages[0]['input_tokens_counted']!=item['role_plan']['primary_input_tokens_counted'] or
                stages[0]['input_tokens_counted']!=item['role_plan']['selected_draft_input_tokens']):
            raise ValueError('MEASURED_SELECTED_ROLE_NATIVE_COUNT_CHANGED')
        item['native_stages']=deepcopy(stages)
        rows.append(item)
    maximum = {key: max(row['initial_totals'][key] for row in rows)
        for key in ('attempts', 'tokens', 'haiku_nanodollars')}
    return {'schema': SCHEMA, 'serving_manifest_sha256': source['serving_manifest_sha256'],
        'count_module_origin_policy':'ACTUAL_FROZEN_APP_IMAGE_ONLY','frozen_runtime_module_origins':deepcopy(origins),
        'runtime_lock': source['runtime_lock'], 'owner_model_scope_sha256': OWNER_SCOPE_SHA,
        'owner_anthropic_payload_scope_sha256':PAYLOAD_SCOPE_SHA,
        'model_routing_contract_sha256': digest(routing),
        'count_build_id': receipt['cloud_build_id'], 'count_receipt_sha256': receipt_sha,
        'count_script_sha256': receipt['script_sha256'], 'count_history_sha256': receipt['history_sha256'],
        'case_forecasts': rows,
        'retained_floor': {'purpose': 'ONE_PUBLIC_DIRECT_AND_TWO_HUMAN_INITIAL_PHASE_ENVELOPES',
            'basis': 'COMPONENTWISE_MAX_OF_SIX_MEASURED_INITIAL_PHASES', 'turns': 3,
            'maximum_measured_initial': maximum, 'required': {key: 3*value for key,value in maximum.items()},
            'arbitrary_future_question_affordability_guaranteed': False},
        'actual_finalized_verifier_count_demonstrated': False,
        'future_finalized_verifier_quota_status': UNKNOWN,
        'allocation_reservations_refunded_or_reset': False}


def validate_budget(budget, inventory, runtime_lock, plan):
    if (budget.get('schema') != SCHEMA or
            budget.get('count_module_origin_policy')!='ACTUAL_FROZEN_APP_IMAGE_ONLY' or
            inventory.get('count_module_origin_policy')!='ACTUAL_FROZEN_APP_IMAGE_ONLY' or
            budget.get('frozen_runtime_module_origins')!=inventory.get('expected_frozen_runtime_module_origins') or
            budget.get('serving_manifest_sha256') != inventory['serving_manifest_sha256'] or
            budget.get('runtime_lock') != runtime_lock or
            budget.get('owner_model_scope_sha256') != OWNER_SCOPE_SHA or
            budget.get('owner_anthropic_payload_scope_sha256') != PAYLOAD_SCOPE_SHA or
            inventory.get('owner_anthropic_payload_scope_sha256') != PAYLOAD_SCOPE_SHA or
            inventory.get('file_sha256',{}).get(PAYLOAD_SCOPE_PATH) != PAYLOAD_SCOPE_SHA or
            budget.get('model_routing_contract_sha256') != inventory['model_routing_contract_sha256'] or
            budget.get('actual_finalized_verifier_count_demonstrated') is not False or
            budget.get('future_finalized_verifier_quota_status') != UNKNOWN or
            budget.get('allocation_reservations_refunded_or_reset') is not False or
            str(uuid.UUID(budget['count_build_id'])) != budget['count_build_id']):
        raise ValueError('MEASURED_CAPACITY_SOURCE_OR_SCOPE_CHANGED')
    routing = inventory['model_routing_contract']
    rows = budget.get('case_forecasts', [])
    if len(rows) != len(plan['cases']) or len(rows) != 6:
        raise ValueError('MEASURED_CAPACITY_SIX_CASE_PLAN_REQUIRED')
    for row, case in zip(rows, plan['cases'], strict=True):
        if (row['case_id'] != case['case_id'] or row['question_sha256'] != digest(case['question']) or
                row['initial_totals'] != phase_totals(row['initial_phase_slots'], routing, row['role_plan'], ('draft','verify')) or
                row['conditional_totals'] != phase_totals(row['conditional_correction_phase_slots'], routing, row['role_plan'], ('correction','reverify'))):
            raise ValueError('MEASURED_CAPACITY_CASE_OR_TOTAL_CHANGED')
    maximum = {key: max(row['initial_totals'][key] for row in rows)
        for key in ('attempts','tokens','haiku_nanodollars')}
    expected_floor = {'purpose': 'ONE_PUBLIC_DIRECT_AND_TWO_HUMAN_INITIAL_PHASE_ENVELOPES',
        'basis': 'COMPONENTWISE_MAX_OF_SIX_MEASURED_INITIAL_PHASES', 'turns': 3,
        'maximum_measured_initial': maximum, 'required': {key: 3*value for key,value in maximum.items()},
        'arbitrary_future_question_affordability_guaranteed': False}
    if budget.get('retained_floor') != expected_floor:
        raise ValueError('MEASURED_CAPACITY_PUBLIC_HUMAN_FLOOR_CHANGED')
    for key in ('count_receipt_sha256','count_script_sha256','count_history_sha256'):
        if not re.fullmatch(r'[0-9a-f]{64}', budget.get(key, '')):
            raise ValueError('MEASURED_CAPACITY_COUNT_IDENTITY_INVALID')


def capacity_check(budget, case_index, ledgers):
    from cloud.grounded_generation.token_ceiling import GRANT_DOCUMENT,resolve_token_ceiling
    primary, haiku = ledgers[PRIMARY], ledgers[HAIKU_BUDGET]
    maximum_tokens,authorization=resolve_token_ceiling(primary,ledgers.get(GRANT_DOCUMENT))
    if (primary.get('version') != 'whole-turn-capacity-v1' or
            primary.get('maximum_attempts') != 100 or
            haiku.get('version') != 'claude-fallback-nonrecurring-one-dollar-v1' or
            haiku.get('maximum_nanodollars') != 1000000000):
        raise ValueError('PERMANENT_CAPACITY_GUARD_CHANGED')
    spent = {'attempts': integer(primary.get('reserved_attempts', 0)),
        'tokens': integer(primary.get('reserved_tokens', 0)),
        'haiku_nanodollars': integer(haiku.get('reserved_nanodollars', 0))}
    ceilings = {'attempts': 100, 'tokens': maximum_tokens, 'haiku_nanodollars': 1000000000}
    if any(spent[key] > ceilings[key] for key in ceilings):
        raise ValueError('PERMANENT_CAPACITY_ALREADY_EXCEEDED')
    rows = budget['case_forecasts']
    remaining = total([row['initial_totals'] for row in rows[case_index:]])
    conditional = rows[case_index]['conditional_totals']
    floor = budget['retained_floor']['required']
    required = total([remaining, conditional, floor])
    available = {key: ceilings[key] - spent[key] for key in ceilings}
    return {'classification': 'READONLY_MEASURED_PHASE_CAPACITY_CHECK',
        'case_id': rows[case_index]['case_id'], 'count_build_id': budget['count_build_id'],
        'count_receipt_sha256': budget['count_receipt_sha256'], 'baseline_retained_charges': spent,
        'maximum_tokens':maximum_tokens,'token_ceiling_authorization':authorization,
        'remaining_planned_initial': remaining, 'current_conditional_correction': conditional,
        'public_human_measured_floor': floor, 'required': required, 'available': available,
        'eligible': all(required[key] <= available[key] for key in ceilings),
        'allocation_changes': 0, 'refunds_or_resets': 0,
        'arbitrary_future_question_affordability_guaranteed': False}
