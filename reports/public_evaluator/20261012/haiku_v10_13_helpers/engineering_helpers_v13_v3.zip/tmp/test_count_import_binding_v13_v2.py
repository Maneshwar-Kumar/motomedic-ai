"""Synthetic import isolation and source10/count2 controls; no providers."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE));sys.path.insert(0,str(BASE/'public_evaluator'));sys.path.insert(0,str(BASE.parent))
import count_only_context_v10_13_v2 as count
import private_acceptance_console_v10_13_v3 as console
import test_haiku_helpers_v10_13_v3 as helpers

class ImportOriginTests(unittest.TestCase):
    def test_partial_workspace_cloud_package_cannot_shadow_frozen_runtime_after_client_import(self):
        with tempfile.TemporaryDirectory(dir=BASE) as temporary:
            root=Path(temporary);app=root/'app';workspace=root/'workspace'
            partial=workspace/'cloud/grounded_generation';partial.mkdir(parents=True)
            (partial/'__init__.py').write_text('')
            (workspace/'tmp/public_evaluator').mkdir(parents=True)
            for name in ('hosted_client_v10_13_v2.py','count_only_context_v10_13_v2.py'):
                (workspace/'tmp/public_evaluator'/name).write_bytes((BASE/'public_evaluator'/name).read_bytes())
            expected={}
            for name in count.RUNTIME_MODULES:
                relative=name.replace('.','/')+'.py';path=app/relative;path.parent.mkdir(parents=True,exist_ok=True)
                path.write_text('FROZEN_IMAGE_SENTINEL=True\n');expected[relative]=hashlib.sha256(path.read_bytes()).hexdigest()
            (app/'cloud/grounded_generation/__init__.py').write_text('')
            code='''import sys,json
from pathlib import Path
app,workspace,expected=sys.argv[1:]
sys.path.insert(0,app);sys.path.insert(1,str(Path(workspace)/'tmp/public_evaluator'))
import hosted_client_v10_13_v2
assert sys.path[0]==workspace
import count_only_context_v10_13_v2 as count
count.restore_frozen_app_import_priority(Path(app))
origins=count.frozen_runtime_origins(Path(app),{'file_sha256':json.loads(expected)})
assert len(origins)==6
print(json.dumps({'frozen_modules':len(origins),'app_first':sys.path[0]==app}))
'''
            result=subprocess.run([sys.executable,'-I','-c',code,str(app),str(workspace),json.dumps(expected)],capture_output=True,text=True,timeout=30)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(json.loads(result.stdout),{'frozen_modules':6,'app_first':True})
    def test_wrong_module_origin_or_frozen_module_bytes_reject_before_counter(self):
        with tempfile.TemporaryDirectory(dir=BASE) as temporary:
            root=Path(temporary);app=root/'app';app.mkdir();path=root/'outside.py';path.write_text('')
            from types import SimpleNamespace
            module=SimpleNamespace(__file__=str(path))
            with patch.object(count.importlib,'import_module',return_value=module),self.assertRaisesRegex(RuntimeError,'ORIGIN_OUTSIDE'):
                count.frozen_runtime_origins(app,{'file_sha256':{}})
            inside=app/'synthetic.py';inside.write_text('synthetic');module.__file__=str(inside)
            with patch.object(count.importlib,'import_module',return_value=module),self.assertRaisesRegex(RuntimeError,'SOURCE_BINDING_CHANGED'):
                count.frozen_runtime_origins(app,{'file_sha256':{'synthetic.py':'0'*64}})
    def test_fresh_phase_budget_rejects_missing_origin_proof_and_original_source9_script(self):
        for change in ('flag','policy','origins','oldscript'):
            source,receipt,*_=helpers.fixtures()
            if change=='flag':receipt['frozen_runtime_module_origins_verified']=False
            elif change=='policy':source['count_module_origin_policy']='WORKSPACE_RUNTIME'
            elif change=='origins':receipt['runtime_module_origins'].pop(next(iter(receipt['runtime_module_origins'])))
            else:source['files']['tmp/public_evaluator/count_only_context_v10_13.py']=source['files'].pop('tmp/public_evaluator/count_only_context_v10_13_v2.py')
            with self.subTest(change=change),self.assertRaises((ValueError,KeyError)):
                helpers.phase.make_budget(receipt,source,'e'*64,helpers.ROUTING_CONTRACT)
    def test_grant_replaces_only_exact9_with10_and_preserves_other_rows(self):
        prior={'source':{'object':'serving/engineering-clients/v10_13/'+'a'*64+'.tar.gz'}}
        source={'object':'serving/engineering-clients/v10_13/'+'b'*64+'.tar.gz','sha256':'b'*64,'generation':'123',
            'service_account':console.run.BACKEND_SA,'artifact_prefix':'engineering-acceptance/public-v10_3/'}
        old={'role':console.GET_ROLE,'members':[console.MEMBER],'condition':{'title':'motomedic-backend-exact-evaluator-client-v10-13-v9',
            'expression':"resource.name == 'projects/_/buckets/"+console.cloud.BUCKET+'/objects/'+prior['source']['object']+"'"}}
        other={'role':'existing-artifact-creator','members':['unchanged'],'condition':{'expression':'protected-prefix'}}
        policy={'etag':'synthetic','version':3,'bindings':[old,other]};before=deepcopy(policy)
        updated,removed,added=console.source_policy_replacement(policy,prior,source)
        self.assertEqual(policy,before);self.assertEqual(removed,old);self.assertIn(other,updated['bindings'])
        self.assertEqual(added['condition']['title'],'motomedic-backend-exact-evaluator-client-v10-13-v10')
    def test_fresh_receipt_names_and_paid_deployment_reference(self):
        self.assertEqual(console.SOURCE_RECEIPT,'evaluator_client_source_v10.json')
        self.assertEqual(console.COUNT_SUBMISSION,'count_only_submission_v10_13_v2.json')
        source=(BASE/'prepare_evaluator_v10_13_v2.py').read_text()
        self.assertIn('deployment_backend_v10_13_v2_result.json',source)
        self.assertNotIn("deployment_backend_v10_13_result.json",source)

if __name__=='__main__':unittest.main()
