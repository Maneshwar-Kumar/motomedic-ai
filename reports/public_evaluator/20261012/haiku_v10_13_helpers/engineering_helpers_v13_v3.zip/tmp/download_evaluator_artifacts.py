import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import submit_hosted_v10 as cloud
from cloud.serving_artifacts import GCSReader,ObjectReference
bid=sys.argv[1]
records=json.loads((cloud.OUT/('logs_build_'+bid+'.json')).read_bytes())
output=cloud.OUT/'hosted_runs'/bid
output.mkdir(parents=True,exist_ok=True)
inventory={}
for row in records:
    item=row.get('scalars',{})
    name=item.get('artifact_file')
    if name is None:continue
    if Path(name).name!=name or not name.endswith('.json'):raise ValueError('INVALID_ARTIFACT_NAME')
    ref=ObjectReference(uri='gs://'+cloud.BUCKET+'/engineering-acceptance/public-v10_3/'+bid+'/'+name,
        generation=item['generation'],sha256=item['sha256'],maximum_bytes=1048576)
    GCSReader(token=cloud.token).fetch(ref,output/name)
    inventory[name]={'generation':ref.generation,'sha256':ref.sha256,'bytes':(output/name).stat().st_size}
(output/'download_inventory.json').write_text(json.dumps({'cloud_build_id':bid,'files':inventory,'provider_calls':0},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'build_id':bid,'files':inventory}))
