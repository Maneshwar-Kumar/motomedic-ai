"""Synthetic actual browser-helper receipt integrity checks; no live requests."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import unittest

ROOT=Path(__file__).resolve().parents[1]
BUNDLE=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node'

class BrowserEvidenceTests(unittest.TestCase):
    def test_existing_versioned_browser_receipt_cannot_be_overwritten(self):
        folder=ROOT/'tmp/public_evaluator/browser-self-check-v13'
        path=folder/'receipt.json';before=path.read_bytes()
        env=os.environ.copy();env['NODE_PATH']=str(BUNDLE/'node_modules')
        result=subprocess.run([str(BUNDLE/'bin/node.exe'),str(ROOT/'tmp/public_evaluator/browser_acceptance_v13.cjs'),
            '--self-check','--output',str(folder)],capture_output=True,text=True,env=env,timeout=20)
        self.assertEqual(result.returncode,1);self.assertEqual(path.read_bytes(),before)
        self.assertEqual(json.loads(result.stdout)['failure_code'],'BROWSER_ARGUMENT_OR_RUNTIME_UNAVAILABLE')
    def test_synthetic_browser_receipt_labels_expected_policy_without_observation_claim(self):
        path=ROOT/'tmp/public_evaluator/browser-self-check-v13/receipt.json'
        value=json.loads(path.read_bytes())
        self.assertEqual(value['expected_runtime_policy'],'open-manual-haiku-draft-verify-v10_13')
        self.assertIs(value['runtime_policy_directly_observed'],False)
        self.assertNotIn('runtime_policy',value)
        self.assertEqual(value['status'],'PASS');self.assertEqual(value['external_requests'],0)
        self.assertEqual(value['actual_provider_calls'],0)
        self.assertEqual(value['script_sha256'],hashlib.sha256((ROOT/'tmp/public_evaluator/browser_acceptance_v13.cjs').read_bytes()).hexdigest())

if __name__=='__main__':unittest.main()
