"""Synthetic deployment/configuration boundaries; no network or credentials."""
import copy
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE));sys.path.insert(0,str(BASE.parent))
import public_cloud_run_v10_13_v2 as run
import private_acceptance_console_v10_13_v2 as console

class InspectionConfigurationTests(unittest.TestCase):
    def actual(self,name):
        return {'containers':[{'env':[{'name':k,'value':v} for k,v in run.expected_inspection_environment(name).items()]}]}
    def test_exact_canonical_audiences_and_callers(self):
        for name in run.NAMES:
            self.assertEqual(run.require_inspection_environment(name,self.actual(name)),run.expected_inspection_environment(name))
        api=run.expected_inspection_environment('motomedic-arm-a')
        worker=run.expected_inspection_environment('motomedic-answer-worker')
        self.assertEqual(api['MOTOMEDIC_SERVICE_AUDIENCE'],'https://motomedic-arm-a-279945185781.us-central1.run.app')
        self.assertEqual(api['MOTOMEDIC_SERVICE_ALLOWED_CALLERS'],run.UI_SA+','+run.BACKEND_SA)
        self.assertEqual(worker['MOTOMEDIC_SERVICE_ALLOWED_CALLERS'],run.TASK_SA)
    def test_every_bound_flag_audience_and_callers_fails_on_drift(self):
        for name in run.NAMES:
            for key in run.expected_inspection_environment(name):
                actual=self.actual(name)
                next(row for row in actual['containers'][0]['env'] if row['name']==key)['value']='changed'
                with self.subTest(name=name,key=key),self.assertRaises(ValueError):run.require_inspection_environment(name,actual)
    def test_duplicates_secret_values_and_backend_paused_reject(self):
        for name in run.NAMES:
            for mutation in ('duplicate','valueSource'):
                actual=self.actual(name);rows=actual['containers'][0]['env']
                if mutation=='duplicate':rows.append(copy.deepcopy(rows[0]))
                else:rows[0]['valueSource']={'secretKeyRef':{'secret':'invalid'}}
                with self.assertRaises(ValueError):run.require_inspection_environment(name,actual)
        actual=self.actual('motomedic-arm-a')
        actual['containers'][0]['env'].append({'name':'MOTOMEDIC_RIDER_ANSWERS_ENABLED','value':'false'})
        with self.assertRaises(ValueError):run.require_inspection_environment('motomedic-arm-a',actual)
    def test_captured_deploy_uses_exact_new_flags_without_iam_write(self):
        images={'backend':{'status':'SUCCESS','results':{'images':[{'name':'synthetic:serving-13','digest':'sha256:'+'a'*64}]}},
            'ui':{'status':'SUCCESS','results':{'images':[{'name':'synthetic-ui:serving-13','digest':'sha256:'+'b'*64}]}}}
        for kind,name in (('backend','motomedic-arm-a'),('worker','motomedic-answer-worker'),('ui','motomedic-rider-ui')):
            with patch.object(Path,'read_bytes',return_value=json.dumps(images).encode()),patch.object(Path,'exists',return_value=True),\
                patch.object(run,'api',return_value={'name':'synthetic-operation'}) as api,patch.object(run.cloud,'dump') as dump:
                run.deploy(kind)
                method,url,body=api.call_args.args
                self.assertEqual(method,'PATCH');self.assertNotIn(':setIamPolicy',url)
                run.require_inspection_environment(name,body['template'])
                self.assertTrue(dump.call_args.args[0].endswith('_v10_13_v2_submission.json'))
                secrets={row['name'] for row in body['template']['containers'][0]['env'] if 'valueSource' in row}
                self.assertEqual(secrets,{'MOTOMEDIC_VISITOR_SECRET'} if kind=='ui' else {'MOTOMEDIC_VISITOR_SECRET','ANTHROPIC_API_KEY'})
    def test_original_archive_bound_helper_bytes_remain_identical(self):
        import hashlib
        receipt=json.loads((BASE.parent/'reports/public_evaluator/20261012/haiku_v10_13_helpers/engineering_helpers_manifest_v13_v1.json').read_bytes())
        for path,value in receipt['file_sha256'].items():
            self.assertEqual(hashlib.sha256((BASE.parent/path).read_bytes()).hexdigest(),value,path)

if __name__=='__main__':unittest.main()
