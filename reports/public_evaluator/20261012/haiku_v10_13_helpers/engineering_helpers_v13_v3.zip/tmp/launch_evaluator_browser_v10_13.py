"""Run the browser harness against the exact frozen v10.13 release only."""
import hashlib
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'))
import submit_hosted_v10 as cloud
bundle=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node'
manifest=cloud.OUT/'serving_manifest_v10_13.json'
release_sha=hashlib.sha256(manifest.read_bytes()).hexdigest()
if (cloud.OUT/'serving_manifest_v10_13.sha256').read_text().split()[0]!=release_sha:
    raise ValueError('CURRENT_MANIFEST_SIDECAR_CHANGED')
env=os.environ.copy();env['NODE_PATH']=str(bundle/'node_modules')
args=[str(bundle/'bin/node.exe'),'tmp/public_evaluator/browser_acceptance_v13.cjs','--execute-authorized',
    '--url','https://motomedic-rider-ui-279945185781.us-central1.run.app','--release-sha',release_sha]
mode=sys.argv[1]
if mode=='private-shell':
    sdk_env=os.environ.copy();sdk_env.pop('PYTHONPATH',None)
    result=subprocess.run([str(cloud.CLI),'auth','print-identity-token',
        '--account=maneshwarkumar@gmail.com','--quiet'],capture_output=True,text=True,env=sdk_env,timeout=45)
    if result.returncode or not result.stdout.strip():raise RuntimeError('SDK_AUTHENTICATION_UNAVAILABLE')
    env['MOTOMEDIC_PRIVATE_TEST_ID_TOKEN']=result.stdout.strip()
    args+=['--shell-only','--output','tmp/public_evaluator/private-shell-output-v10_13']
elif mode=='public-shell':args+=['--shell-only','--output','tmp/public_evaluator/public-shell-output-v10_13']
elif mode=='public-answer':args+=['--output','tmp/public_evaluator/public-answer-output-v10_13']
else:raise ValueError('EXACT_BROWSER_MODE_REQUIRED')
sys.exit(subprocess.run(args,env=env).returncode)
