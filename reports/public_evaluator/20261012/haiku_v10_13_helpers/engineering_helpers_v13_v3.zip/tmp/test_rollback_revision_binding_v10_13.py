"""Synthetic exact-Revision rollback regressions; no SDK, cloud or provider calls."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import rollback_public_v10_13 as helper


class RevisionConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.template = {'containers': [{'image': 'synthetic@sha256:' + 'a' * 64,
            'env': [], 'resources': {'limits': {'cpu': '2', 'memory': '8Gi'}}}],
            'serviceAccount': 'synthetic-sa', 'timeout': '1200s',
            'maxInstanceRequestConcurrency': 6, 'scaling': {'minInstanceCount': 1, 'maxInstanceCount': 1}}
        self.actual = {**deepcopy(self.template), 'name': 'original-revision',
            'conditions': [{'type': 'Ready', 'state': 'CONDITION_SUCCEEDED'}],
            'executionEnvironment': 'EXECUTION_ENVIRONMENT_GEN2', 'launchStage': 'GA',
            'vpcAccess': {'egress': 'PRIVATE_RANGES_ONLY'}, 'volumes': [],
            'encryptionKey': 'synthetic-key', 'encryptionKeyRevocationAction': 'SHUTDOWN',
            'encryptionKeyShutdownDuration': '3600s', 'serviceMesh': {},
            'sessionAffinity': False, 'nodeSelector': {}, 'gpuZonalRedundancyDisabled': False}
        self.configuration = helper.revision_configuration(self.actual, self.template)
        self.row = {'revision': 'original-revision', 'template_sha256': helper.template_identity(self.template),
            'revision_configuration': self.configuration,
            'revision_configuration_sha256': helper.digest(self.configuration)}

    def test_exact_actual_defaulted_baseline_passes_without_changing_inputs(self):
        before = deepcopy((self.actual, self.template, self.row))
        self.assertFalse(helper.require_bound_revision(self.actual, self.template, self.row))
        self.assertEqual((self.actual, self.template, self.row), before)

    def test_changed_revision_scaling_fails_even_with_identical_container_resources(self):
        changed = deepcopy(self.actual)
        changed['scaling'] = {'minInstanceCount': 5, 'maxInstanceCount': 10}
        with self.assertRaisesRegex(ValueError, 'ACTUAL_TRAFFIC_REVISION_CONFIGURATION_DIFFERS'):
            helper.require_bound_revision(changed, self.template, self.row)

    def test_changed_scaling_cannot_replace_both_the_actual_and_declared_original_baseline(self):
        changed, template = deepcopy(self.actual), deepcopy(self.template)
        changed['scaling'] = template['scaling'] = {'minInstanceCount': 5, 'maxInstanceCount': 10}
        with self.assertRaisesRegex(ValueError, 'ACTUAL_REVISION_MATERIAL_CONFIGURATION_DIFFERS'):
            helper.require_bound_revision(changed, template, self.row)

    def test_every_material_actual_revision_field_is_bound_including_unknown_fields(self):
        for field in ('executionEnvironment', 'launchStage', 'vpcAccess', 'volumes', 'encryptionKey',
                      'encryptionKeyRevocationAction', 'encryptionKeyShutdownDuration', 'serviceMesh',
                      'sessionAffinity', 'nodeSelector', 'gpuZonalRedundancyDisabled'):
            changed = deepcopy(self.actual);changed[field] = 'synthetic-changed-value'
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, 'MATERIAL_CONFIGURATION_DIFFERS'):
                helper.require_bound_revision(changed, self.template, self.row)

        for action in ('added', 'removed'):
            changed = deepcopy(self.actual)
            if action == 'added':changed['futureRuntimeConfiguration'] = True
            else:changed.pop('executionEnvironment')
            with self.subTest(action=action), self.assertRaisesRegex(ValueError, 'MATERIAL_CONFIGURATION_DIFFERS'):
                helper.require_bound_revision(changed, self.template, self.row)

    def test_material_binding_preserves_json_types_even_when_python_values_compare_equal(self):
        changed = deepcopy(self.actual);changed['sessionAffinity'] = 0
        with self.assertRaisesRegex(ValueError, 'MATERIAL_CONFIGURATION_DIFFERS'):
            helper.require_bound_revision(changed, self.template, self.row)

    def test_explicit_template_fields_cannot_be_replaced_by_an_actual_default(self):
        template = {**deepcopy(self.template), 'executionEnvironment': 'EXECUTION_ENVIRONMENT_GEN1'}
        with self.assertRaisesRegex(ValueError, 'ACTUAL_TRAFFIC_REVISION_CONFIGURATION_DIFFERS'):
            helper.revision_configuration(self.actual, template)

    def test_only_named_output_metadata_can_change_between_immutable_revisions(self):
        candidate = deepcopy(self.actual)
        candidate.update(name='candidate-revision', uid='synthetic-candidate-uid', generation='2',
            labels={'synthetic': 'new-label'}, annotations={'synthetic': 'metadata'},
            createTime='2026-10-12T00:00:00Z', updateTime='2026-10-12T00:01:00Z',
            observedGeneration='2', logUri='https://synthetic.invalid/logs', etag='synthetic-etag',
            scalingStatus={'desiredMinInstanceCount': 0})
        row = {**deepcopy(self.row), 'revision': 'candidate-revision'}
        self.assertFalse(helper.require_bound_revision(candidate, self.template, row))
        self.assertEqual(helper.revision_configuration(candidate, self.template), self.configuration)

    def test_generated_single_container_names_are_finite_and_do_not_replace_other_fields(self):
        original = deepcopy(self.actual);original['containers'][0]['name'] = 'original-generated-1'
        baseline = helper.revision_configuration(original, self.template)
        row = {**self.row, 'revision_configuration': baseline,
            'revision_configuration_sha256': helper.digest(baseline)}
        candidate = deepcopy(self.actual);candidate['containers'][0]['name'] = 'candidate-generated-2'
        self.assertTrue(helper.require_bound_revision(candidate, self.template, row))
        candidate['containers'][0]['resources']['limits']['cpu'] = '1'
        with self.assertRaisesRegex(ValueError, 'ACTUAL_TRAFFIC_REVISION_CONFIGURATION_DIFFERS'):
            helper.require_bound_revision(candidate, self.template, row)

    def test_missing_or_changed_actual_baseline_hash_fails_closed(self):
        for mutation in ('missing', 'hash', 'body'):
            row = deepcopy(self.row)
            if mutation == 'missing':row.pop('revision_configuration')
            if mutation == 'hash':row['revision_configuration_sha256'] = '0' * 64
            if mutation == 'body':row['revision_configuration']['sessionAffinity'] = True
            with self.subTest(mutation=mutation), self.assertRaisesRegex(ValueError, 'ORIGINAL_REVISION_CONFIGURATION_BINDING_REQUIRED'):
                helper.require_bound_revision(self.actual, self.template, row)

    def test_revision_name_and_ready_condition_remain_mandatory(self):
        for mutation in ('name', 'pending', 'duplicate', 'reconciling'):
            changed = deepcopy(self.actual)
            if mutation == 'name':changed['name'] = 'different-revision'
            if mutation == 'pending':changed['conditions'][0]['state'] = 'CONDITION_PENDING'
            if mutation == 'duplicate':changed['conditions'].append(deepcopy(changed['conditions'][0]))
            if mutation == 'reconciling':changed['reconciling'] = True
            with self.subTest(mutation=mutation), self.assertRaisesRegex(ValueError, 'EXACT_IMMUTABLE_REVISION_NOT_READY'):
                helper.require_bound_revision(changed, self.template, self.row)

    def test_create_binds_actual_original_revision_before_any_candidate_patch(self):
        name = 'motomedic-arm-a'
        service = {'template': deepcopy(self.template), 'trafficStatuses': [{'percent': 100,
            'revision': 'original-revision'}]}
        calls, writes = [], {}
        def api(method, url, body=None):
            calls.append((method, url, deepcopy(body)))
            if method == 'PATCH':return {'name': 'synthetic-operation'}
            return deepcopy(self.actual if '/revisions/' in url else service)
        with patch.object(helper, 'release', return_value=({'synthetic': True}, {})), \
                patch.object(helper, 'require_absent'), patch.object(helper, 'private_policies', return_value={name: {}}), \
                patch.object(helper, 'identity_token', return_value='synthetic-token'), \
                patch.object(helper, 'require_service'), patch.object(helper, 'get_health', return_value={'http_status': 200}), \
                patch.object(helper.run, 'NAMES', (name,)), patch.object(helper.run, 'api', side_effect=api), \
                patch.object(helper, 'dump', side_effect=lambda key, value: writes.__setitem__(key, deepcopy(value))):
            helper.create()
        row = writes[helper.receipt('initial')]['services'][name]
        self.assertEqual(row['revision_configuration'], self.configuration)
        self.assertEqual(row['revision_configuration_sha256'], helper.digest(self.configuration))
        self.assertTrue(row['immutable_revision_configuration_confirmed'])
        self.assertEqual([item[0] for item in calls], ['GET', 'GET', 'PATCH'])

    def test_changed_target_revision_blocks_traffic_patch(self):
        name = 'motomedic-arm-a';row = deepcopy(self.row)
        binding = {'synthetic': True}
        initial = {'binding': binding, 'services': {name: row},
            'private_policy_sha256': {name: helper.digest({})}}
        candidate = {'binding': binding, 'services': {name: row}}
        changed = deepcopy(self.actual);changed['executionEnvironment'] = 'EXECUTION_ENVIRONMENT_GEN1'
        calls = []
        def api(method, url, body=None):
            calls.append(method)
            return changed if '/revisions/' in url else {'template': deepcopy(self.template)}
        with patch.object(helper, 'release', return_value=(binding, {})), \
                patch.object(helper, 'require_absent'), patch.object(helper, 'private_policies', return_value={name: {}}), \
                patch.object(helper, 'read', side_effect=lambda key: initial if key == helper.receipt('initial') else candidate), \
                patch.object(helper, 'require_service'), patch.object(helper.run, 'api', side_effect=api), \
                patch.object(helper, 'dump') as dump:
            with self.assertRaisesRegex(ValueError, 'MATERIAL_CONFIGURATION_DIFFERS'):helper.route('candidate')
            dump.assert_not_called()
        self.assertNotIn('PATCH', calls)

    def test_changed_routed_revision_blocks_health_receipt(self):
        name = 'motomedic-arm-a';row = deepcopy(self.row);binding = {'synthetic': True}
        routed = {'binding': binding, 'operations': {name: {'operation': {'name': 'synthetic/op'}}}}
        candidate = {'services': {name: row}}
        changed = deepcopy(self.actual);changed['sessionAffinity'] = True
        service = {'template': deepcopy(self.template), 'trafficStatuses': [{'percent': 100, 'revision': row['revision']}]}
        def api(method, url):
            if url.endswith('synthetic/op'):return {'done': True}
            return changed if '/revisions/' in url else service
        with patch.object(helper, 'release', return_value=(binding, {})), patch.object(helper, 'require_absent'), \
                patch.object(helper, 'read', side_effect=lambda key: routed if key.endswith('_traffic.json') else candidate), \
                patch.object(helper, 'identity_token', return_value='synthetic-token'), patch.object(helper, 'require_service'), \
                patch.object(helper.run, 'api', side_effect=api), patch.object(helper, 'get_health') as health, \
                patch.object(helper, 'dump') as dump:
            with self.assertRaisesRegex(ValueError, 'MATERIAL_CONFIGURATION_DIFFERS'):helper.health('candidate')
            health.assert_not_called();dump.assert_not_called()


if __name__ == '__main__':unittest.main()
