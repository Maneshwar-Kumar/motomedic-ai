"""Hash the baked wrapper in the pinned existing image; never start Qdrant."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'))
import public_cloud_run_v10_13_v2 as run
import private_acceptance_console_v10_13_v2 as console
import rollback_public_v10_13 as rollback
cloud=run.cloud
OUT=cloud.OUT/'haiku_v10_13_helpers/qdrant_image_proof_v1'
SCHEMA='motomedic-hosted-qdrant-baked-wrapper-hash-v1'
BOOT='cloud/qdrant/boot.py'
DOCKERFILE='cloud/qdrant/Dockerfile'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def write(name,value):
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/name).open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')

def baked_boot_path(dockerfile):
    copies=re.findall(r'^COPY\s+boot\.py\s+(/[^\s]+)\s*$',dockerfile,re.M)
    entries=re.findall(r'^ENTRYPOINT\s+(\[[^\n]+\])\s*$',dockerfile,re.M)
    if len(copies)!=1 or len(entries)!=1 or json.loads(entries[0])!=['python3',copies[0]]:
        raise ValueError('EXACT_DOCKERFILE_COPY_AND_ENTRYPOINT_BINDING_REQUIRED')
    return copies[0]

def recipe(image,expected,boot_path):
    if (not re.fullmatch('us-central1-docker.pkg.dev/'+re.escape(cloud.PROJECT)+'/motomedic/qdrant@sha256:[0-9a-f]{64}',image) or
        not re.fullmatch(r'[0-9a-f]{64}',expected) or boot_path!='/qdrant/boot.py'):
        raise ValueError('PINNED_EXISTING_IMAGE_AND_REVIEWED_WRAPPER_REQUIRED')
    code='from pathlib import Path; import hashlib,json; raw=Path('+repr(boot_path)+').read_bytes(); actual=hashlib.sha256(raw).hexdigest(); '+\
        'print(json.dumps({"schema":'+repr(SCHEMA)+',"actual_boot_path":'+repr(boot_path)+',"actual_boot_sha256":actual,'+\
        '"expected_boot_sha256":'+repr(expected)+',"boot_bytes":len(raw),"matches_reviewed_source":actual=='+repr(expected)+','+\
        '"qdrant_started":False,"index_download_or_load":False,"provider_calls":0,"secret_environment_supplied":False},sort_keys=True),flush=True); '+\
        'raise SystemExit(0 if actual=='+repr(expected)+' else 2)'
    return {'serviceAccount':'projects/'+cloud.PROJECT+'/serviceAccounts/'+run.BACKEND_SA,
        'steps':[{'name':image,'entrypoint':'python3','args':['-B','-c',code]}],
        'options':{'logging':'CLOUD_LOGGING_ONLY'},'timeout':'180s'}

def prepare():
    if (OUT/'preparation.json').exists():raise ValueError('NEVER_OVERWRITE_QDRANT_IMAGE_PROOF_PREPARATION')
    status=ROOT/'cloud/deployment_status.json';recorded=json.loads(status.read_bytes())
    if recorded.get('service')!='motomedic-qdrant' or recorded.get('selected_index_id')!='index_a3282c4d98cf54595e4ba168':
        raise ValueError('RECORDED_EXISTING_QDRANT_IMAGE_REQUIRED')
    boot_path=baked_boot_path((ROOT/DOCKERFILE).read_text(encoding='utf-8'))
    hashes={path:sha(ROOT/path) for path in (BOOT,DOCKERFILE,'cloud/deployment_status.json')}
    config=recipe(recorded['image'],hashes[BOOT],boot_path)
    write('preparation.json',{'schema':'motomedic-qdrant-image-proof-preparation-v1','config':config,
        'image':recorded['image'],'boot_image_path':boot_path,'file_sha256':hashes,
        'reviewed_read_only_endpoints':['GET /health','POST /query'],
        'qdrant_started':False,'index_download_or_load':False,'provider_calls':0,'secret_environment_supplied':False,
        'cloud_calls_by_preparation':0,'runtime_or_iam_or_billing_changes':False})
    return {'prepared':True,'image':recorded['image'],'boot_image_path':boot_path,'provider_calls':0,'cloud_calls':0}

def preparation():
    value=read('preparation.json')
    if any(sha(ROOT/path)!=expected for path,expected in value['file_sha256'].items()):raise ValueError('REVIEWED_QDRANT_INPUT_BYTES_CHANGED')
    if value['config']!=recipe(value['image'],value['file_sha256'][BOOT],value['boot_image_path']):raise ValueError('QDRANT_READ_ONLY_PROOF_RECIPE_CHANGED')
    return value

def submit():
    value=preparation()
    if (OUT/'submission.json').exists():raise ValueError('QDRANT_PROOF_ALREADY_SUBMITTED_USE_POLL')
    service=run.api('GET',run.PREFIX+'motomedic-qdrant')
    if service.get('invokerIamDisabled')is True or service['template']['containers'][0]['image']!=value['image']:
        raise ValueError('CURRENT_QDRANT_IMAGE_OR_IAM_CHECK_CHANGED')
    revision=rollback.routed_revision(service);actual=run.api('GET',run.PREFIX+'motomedic-qdrant/revisions/'+revision)
    rollback.require_ready_revision(actual,revision);configuration=rollback.revision_configuration(actual,service['template'])
    operation=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds',value['config'])
    write('submission.json',{'schema':'motomedic-qdrant-image-proof-submission-v1','config':value['config'],'operation':operation,
        'current_revision':revision,'current_revision_configuration_sha256':rollback.digest(configuration),
        'preparation_sha256':sha(OUT/'preparation.json'),'qdrant_or_iam_or_billing_writes':0,'provider_calls':0})
    return {'cloud_build_id':operation['metadata']['build']['id'],'qdrant_or_iam_or_billing_writes':0,'provider_calls':0}

def job_id():
    value=read('submission.json')['operation']['metadata']['build']['id']
    if not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',value):raise ValueError('EXACT_PROOF_BUILD_ID_REQUIRED')
    return value

def poll():
    value=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds/'+job_id())
    name='build_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json';write(name,value)
    return {'cloud_build_id':job_id(),'status':value['status'],'readback':name,'provider_calls':0}

def require_build_recipe(build,config,job):
    steps=build.get('steps',[])
    if (build.get('id')!=job or build.get('status')!='SUCCESS' or len(steps)!=1 or
        build.get('source') or build.get('availableSecrets') or build.get('secrets') or
        build.get('serviceAccount')!=config['serviceAccount']):raise ValueError('EXACT_SOURCELESS_QDRANT_PROOF_BUILD_NOT_SUCCESSFUL')
    # These are Cloud Build step result fields, not executable configuration.
    outputs={'status','timing','pullTiming','exitCode'}
    actual={key:item for key,item in steps[0].items() if key not in outputs}
    if actual!=config['steps'][0] or steps[0].get('status','SUCCESS')!='SUCCESS' or steps[0].get('exitCode',0)!=0:
        raise ValueError('EXACT_QDRANT_PROOF_STEP_INPUTS_CHANGED')
    return True

def record():
    value=preparation();submission=read('submission.json');job=job_id()
    if (OUT/'image_source_receipt.json').exists():raise ValueError('NEVER_OVERWRITE_QDRANT_IMAGE_SOURCE_PROOF')
    build=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds/'+job)
    require_build_recipe(build,value['config'],job)
    reply=cloud.api('https://logging.googleapis.com/v2/entries:list',{'resourceNames':['projects/'+cloud.PROJECT],
        'filter':'resource.type="build" AND resource.labels.build_id="'+job+'"','orderBy':'timestamp desc','pageSize':200})
    records=[]
    fields={'schema','actual_boot_path','actual_boot_sha256','expected_boot_sha256','boot_bytes','matches_reviewed_source',
        'qdrant_started','index_download_or_load','provider_calls','secret_environment_supplied'}
    for row in reply.get('entries',[]):
        data=row.get('jsonPayload')
        if not isinstance(data,dict):
            raw=row.get('textPayload','')
            try:data=json.loads(raw[raw.find('{'):])
            except (ValueError,TypeError):continue
        if not isinstance(data,dict) or data.get('schema')!=SCHEMA:continue
        if set(data)!=fields:raise ValueError('QDRANT_PROOF_LOG_SHAPE_CHANGED')
        if data not in records:records.append(data)
    if len(records)!=1:raise ValueError('EXACT_ONE_QDRANT_BAKED_HASH_RECORD_REQUIRED')
    observed=records[0]
    if (observed['actual_boot_path']!=value['boot_image_path'] or observed['actual_boot_sha256']!=value['file_sha256'][BOOT] or
        observed['expected_boot_sha256']!=value['file_sha256'][BOOT] or observed['boot_bytes']!=(ROOT/BOOT).stat().st_size or
        observed['matches_reviewed_source']is not True or observed['qdrant_started']is not False or
        observed['index_download_or_load']is not False or observed['provider_calls']!=0 or observed['secret_environment_supplied']is not False):
        raise ValueError('ACTUAL_BAKED_QDRANT_WRAPPER_DIFFERS')
    receipt={'schema':'motomedic-existing-qdrant-read-only-image-source-proof-v1','cloud_build_id':job,'image':value['image'],
        'boot_image_path':value['boot_image_path'],'file_sha256':value['file_sha256'],'actual_baked_wrapper':observed,
        'preparation_sha256':sha(OUT/'preparation.json'),'submission_sha256':sha(OUT/'submission.json'),
        'completed_build_sha256':rollback.digest(build),'current_revision_at_submission':submission['current_revision'],
        'current_revision_configuration_sha256_at_submission':submission['current_revision_configuration_sha256'],
        'read_only_endpoints':['GET /health','POST /query'],'qdrant_started':False,'index_download_or_load':False,
        'provider_calls':0,'raw_logs_saved':False,'qdrant_or_iam_or_billing_changes':False}
    write('image_source_receipt.json',receipt)
    return {'image_source_verified':True,'cloud_build_id':job,'receipt_sha256':sha(OUT/'image_source_receipt.json'),'provider_calls':0}

if __name__=='__main__':
    cloud.token=console.token
    if sys.argv[1:]==['--check-only']:print(json.dumps({'actions':['prepare','submit','poll','record'],'provider_calls':0,
        'model_secret_environment':False,'source_download':False,'qdrant_startup':False,'cloud_actions_executed':False}))
    elif len(sys.argv)==2 and sys.argv[1]in ('prepare','submit','poll','record'):print(json.dumps(globals()[sys.argv[1]]()))
    else:raise SystemExit('ONE_FIXED_QDRANT_IMAGE_PROOF_ACTION_REQUIRED')
