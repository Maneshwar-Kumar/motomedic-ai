"""Synthetic baked-wrapper recipe checks; no image execution or cloud calls."""
from pathlib import Path
import sys
import unittest
from copy import deepcopy

BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
import qdrant_image_source_proof_v13_v1 as proof

class RecipeTests(unittest.TestCase):
    def test_path_is_derived_from_actual_dockerfile_copy_and_entrypoint(self):
        dockerfile=(BASE.parent/proof.DOCKERFILE).read_text()
        self.assertEqual(proof.baked_boot_path(dockerfile),'/qdrant/boot.py')
        for invalid in (dockerfile.replace('COPY boot.py /qdrant/boot.py','COPY other.py /qdrant/boot.py'),
            dockerfile.replace('"/qdrant/boot.py"','"/other/boot.py"'),dockerfile+'\nCOPY boot.py /extra/boot.py\n'):
            with self.assertRaises(ValueError):proof.baked_boot_path(invalid)
    def test_single_pinned_python_override_reads_only_wrapper(self):
        image='us-central1-docker.pkg.dev/'+proof.cloud.PROJECT+'/motomedic/qdrant@sha256:'+'a'*64
        config=proof.recipe(image,'b'*64,'/qdrant/boot.py')
        self.assertNotIn('source',config);self.assertNotIn('availableSecrets',config);self.assertNotIn('secrets',config)
        self.assertEqual(len(config['steps']),1);step=config['steps'][0]
        self.assertEqual(set(step),{'name','entrypoint','args'});self.assertEqual(step['entrypoint'],'python3')
        self.assertEqual(step['name'],image);self.assertEqual(step['args'][:2],['-B','-c'])
        self.assertIn("Path('/qdrant/boot.py').read_bytes()",step['args'][2])
        self.assertNotIn('import boot',step['args'][2]);self.assertNotIn('subprocess',step['args'][2])
    def test_mutable_image_unknown_hash_and_other_paths_fail_closed(self):
        image='us-central1-docker.pkg.dev/'+proof.cloud.PROJECT+'/motomedic/qdrant@sha256:'+'a'*64
        for values in ((image+':latest','b'*64,'/qdrant/boot.py'),(image,'changed','/qdrant/boot.py'),(image,'b'*64,'/private/secret')):
            with self.assertRaises(ValueError):proof.recipe(*values)
    def test_server_result_fields_do_not_hide_changed_executable_inputs(self):
        image='us-central1-docker.pkg.dev/'+proof.cloud.PROJECT+'/motomedic/qdrant@sha256:'+'a'*64
        config=proof.recipe(image,'b'*64,'/qdrant/boot.py');job='11111111-2222-4333-8444-555555555555'
        build={**deepcopy(config),'id':job,'status':'SUCCESS'}
        build['steps'][0].update(status='SUCCESS',exitCode=0,timing={'startTime':'synthetic'},pullTiming={'startTime':'synthetic'})
        self.assertTrue(proof.require_build_recipe(build,config,job))
        for change in ('args','secretEnv','env','source','extraStep','failure'):
            changed=deepcopy(build)
            if change=='args':changed['steps'][0]['args']=['-c','unapproved code']
            elif change in ('secretEnv','env'):changed['steps'][0][change]=['UNAPPROVED']
            elif change=='source':changed['source']={'storageSource':{'object':'other-source'}}
            elif change=='extraStep':changed['steps'].append(deepcopy(changed['steps'][0]))
            else:changed['steps'][0]['exitCode']=2
            with self.assertRaises(ValueError):proof.require_build_recipe(changed,config,job)

if __name__=='__main__':unittest.main()
