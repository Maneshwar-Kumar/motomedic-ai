"""Synthetic public core scope/IAM/probe boundaries; no network or providers."""
import base64
from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import tempfile

BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
import public_core_inspection_v13_v3 as core

class CoreTests(unittest.TestCase):
    def test_actual_backend_readback_differs_only_by_member_order(self):
        capture=json.loads((BASE.parent/'reports/public_evaluator/20261012/public_review/backend_iam_readback_after_scope_v1.json').read_bytes())
        self.assertEqual(core.policy_rows({'bindings':capture['actual_bindings']}),core.policy_rows({'bindings':capture['expected_bindings']}))
        self.assertNotEqual(core.policy_rows({'bindings':capture['actual_bindings']}),core.policy_rows({'bindings':capture['prior_bindings']}))
    def test_comparator_rejects_duplicate_nonstrings_and_keeps_every_other_row_field_exact(self):
        row={'role':'roles/run.invoker','members':['serviceAccount:a','allUsers'],'condition':{'title':'exact','expression':'exact'},'other':'preserved'}
        expected=core.policy_rows({'bindings':[row]})
        for field in ('member','role','condition','other'):
            changed=deepcopy(row)
            if field=='member':changed['members'][0]='serviceAccount:changed'
            elif field=='condition':changed['condition']['expression']='changed'
            else:changed[field]='changed'
            self.assertNotEqual(expected,core.policy_rows({'bindings':[changed]}))
        for members in (['a','a'],['a',True],['a',None],['a',2],['a',{}],'a'):
            changed=deepcopy(row);changed['members']=members
            with self.assertRaises(ValueError):core.policy_rows({'bindings':[changed]})
    def test_backend_exact_existing_public_policy_is_recovered_without_repeated_setiam(self):
        prior={'etag':'old','bindings':[{'role':'roles/run.invoker','members':['serviceAccount:a','serviceAccount:b']}]}
        current={'etag':'new','bindings':[{'role':'roles/run.invoker','members':['allUsers','serviceAccount:b','serviceAccount:a']}]}
        inspection={'prior_core_policies':{'motomedic-arm-a':prior}}
        with patch.object(core,'read',return_value=inspection),patch.object(core,'check_current',return_value={}),\
            patch.object(core.run,'api',return_value=current) as api,patch.object(core,'write') as write,\
            patch.object(core,'sha',return_value='a'*64),patch.object(Path,'exists',return_value=False):
            core.open_service('motomedic-arm-a')
            self.assertTrue(write.call_args.args[1]['existing_exact_public_policy_recovered'])
            self.assertTrue(all(call.args[0]=='GET' for call in api.call_args_list))
    def test_adoption_copies_existing_v2_preparation_and_ledger_bytes_without_cloud_calls(self):
        raw=core.SOURCE_INSPECTION.read_bytes();source=json.loads(raw)
        with tempfile.TemporaryDirectory(dir=BASE) as temporary,patch.object(core,'OUT',Path(temporary)),\
            patch.object(core.rollback,'release',return_value=(source['binding'],{})),\
            patch.object(core.preview,'owner_scope',return_value=source['owner_scope']),patch.object(core.preview,'guard_receipt'),\
            patch.object(core,'auth_review'),patch.object(core,'qdrant_proof'),patch.object(core.run,'api') as api:
            result=core.adopt_v2_inspection()
            self.assertTrue(result['v2_preparation_adopted_byte_identically'])
            self.assertEqual((Path(temporary)/'inspection.json').read_bytes(),raw)
            self.assertEqual(core.read('inspection.json')['ledger_before'],source['ledger_before'])
            api.assert_not_called()
    def qdrant(self):
        status=json.loads((BASE.parent/'cloud/deployment_status.json').read_bytes())
        capture=json.loads((BASE.parent/'reports/public_evaluator/20261012/public_review/qdrant_actual_configuration_v1.json').read_bytes())
        configuration={'containers':[{'image':capture['image'],'env':deepcopy(capture['env'])}],
            'serviceAccount':'motomedic-qdrant@'+core.cloud.PROJECT+'.iam.gserviceaccount.com',
            'scaling':deepcopy(capture['bound_configuration_scaling'])}
        service={'scaling':deepcopy(capture['service_scaling']),'template':{'scaling':deepcopy(capture['template_scaling'])}}
        proof={'current_revision_at_submission':capture['revision'],'current_revision_configuration_sha256_at_submission':core.rollback.digest(configuration)}
        return service,configuration,capture['revision'],proof,status
    def test_service_warm_min_one_and_omitted_revision_min_are_bound_in_separate_scopes(self):
        service,configuration,revision,proof,status=self.qdrant()
        row=core.require_qdrant_configuration(service,configuration,revision,proof,status)
        self.assertEqual(row['service_scaling'],{'minInstanceCount':1,'maxInstanceCount':1})
        self.assertEqual(row['revision_scaling'],{'maxInstanceCount':1})
        self.assertNotIn('minInstanceCount',row['revision_scaling'])
        self.assertTrue(row['actual_revision_configuration_matches_baked_image_proof'])
    def test_image_index_url_sha_each_scaling_scope_revision_and_proof_changes_reject(self):
        for mutation in ('image','index','url','sha','service_min','service_max','template_min','revision_min','revision_max','proof','revision','other_material'):
            service,configuration,revision,proof,status=self.qdrant()
            values=configuration['containers'][0]['env']
            if mutation=='image':configuration['containers'][0]['image']='changed-image'
            elif mutation in ('index','url','sha'):
                key={'index':'INDEX_ID','url':'INDEX_BUNDLE_URL','sha':'INDEX_BUNDLE_SHA256'}[mutation]
                next(row for row in values if row['name']==key)['value']='changed'
            elif mutation=='service_min':service['scaling']['minInstanceCount']=0
            elif mutation=='service_max':service['scaling']['maxInstanceCount']=2
            elif mutation=='template_min':service['template']['scaling']['minInstanceCount']=1
            elif mutation=='revision_min':configuration['scaling']['minInstanceCount']=1
            elif mutation=='revision_max':configuration['scaling']['maxInstanceCount']=2
            elif mutation=='proof':proof['current_revision_configuration_sha256_at_submission']='0'*64
            elif mutation=='revision':revision='other-revision'
            else:configuration['executionEnvironment']='CHANGED_MATERIAL_FIELD'
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):
                core.require_qdrant_configuration(service,configuration,revision,proof,status)
    def test_only_all_users_invoker_added_and_every_prior_row_preserved(self):
        policy={'etag':'synthetic','version':3,'bindings':[{'role':'roles/run.invoker','members':['serviceAccount:existing']},
            {'role':'other-role','members':['unchanged'],'condition':{'expression':'exact-old-scope'}}]}
        before=deepcopy(policy);after=core.public_invoker_policy(policy)
        self.assertEqual(policy,before);self.assertEqual(after['bindings'][0]['members'],['allUsers','serviceAccount:existing'])
        self.assertEqual(after['bindings'][1],before['bindings'][1]);self.assertEqual(after['etag'],before['etag'])
    def test_missing_etag_any_public_role_and_multiple_unconditional_invokers_reject(self):
        for policy in ({'bindings':[]},{'etag':'x','bindings':[{'role':'other-role','members':['allAuthenticatedUsers']}]},
            {'etag':'x','bindings':[{'role':'roles/run.invoker','members':['a']},{'role':'roles/run.invoker','members':['b']}]}):
            with self.assertRaises(ValueError):core.public_invoker_policy(policy)
    def test_synthetic_forged_token_uses_exact_audience_and_expected_email_but_no_real_signature(self):
        for name,email in (('motomedic-arm-a',core.run.UI_SA),('motomedic-answer-worker',core.run.TASK_SA)):
            parts=core.forged_token(name).split('.');claims=json.loads(base64.urlsafe_b64decode(parts[1]+'='*(-len(parts[1])%4)))
            self.assertEqual(claims['aud'],core.URLS[name]);self.assertEqual(claims['email'],email)
            self.assertIs(claims['email_verified'],True);self.assertEqual(parts[2],'invalid_signature')
    def test_unknown_core_actions_reject_without_requests(self):
        with patch.object(core.run,'api') as api:
            for action in (core.open_service,core.probe):
                with self.assertRaises(ValueError):action('unapproved-service')
            api.assert_not_called()
    def test_probe_rejects_when_fake_auth_reaches_any_non401_handler(self):
        name='motomedic-answer-worker';inspection={'binding':{},'services':{}}
        policy={'etag':'synthetic','bindings':[{'role':'roles/run.invoker','members':['allUsers']}]}
        reply=lambda method,url,*args:(200,{'ready':True}) if method=='GET' else (400,{'error':'INVALID_WORKER_REQUEST','technical_content':False})
        with patch.object(core,'read',side_effect=lambda path:inspection if path=='inspection.json' else {'policy':policy}),\
            patch.object(core,'check_current',return_value={}),patch.object(core.run,'api',return_value=policy),\
            patch.object(core,'ledger_audit',return_value={'retained':'unchanged'}),\
            patch.object(core,'anonymous_json',side_effect=reply),patch.object(core.rollback,'get_health',return_value={'health':{'ready':True}}),\
            patch.object(core,'write') as write:
            with self.assertRaisesRegex(ValueError,'FORGED_OPERATION_NOT_REJECTED'):core.probe(name)
            write.assert_not_called()
    def test_negative_worker_body_never_contains_operation_identifiers_and_changed_ledger_fails(self):
        name='motomedic-answer-worker';inspection={'binding':{},'services':{}}
        policy={'etag':'synthetic','bindings':[{'role':'roles/run.invoker','members':['allUsers']}]}
        seen=[]
        def reply(method,url,body=None,headers=None):
            if method=='GET':return 200,{'ready':True}
            seen.append(body);return 401,{'error':'AUTH_REQUIRED','technical_content':False}
        with patch.object(core,'read',side_effect=lambda path:inspection if path=='inspection.json' else {'policy':policy}),\
            patch.object(core,'check_current',return_value={}),patch.object(core.run,'api',return_value=policy),\
            patch.object(core,'ledger_audit',side_effect=[{'retained':1},{'retained':2}]),\
            patch.object(core,'anonymous_json',side_effect=reply),patch.object(core.rollback,'get_health',return_value={'health':{'ready':True}}),\
            patch.object(core,'write') as write:
            with self.assertRaisesRegex(ValueError,'CHANGED_PROVIDER_ALLOCATION'):core.probe(name)
            self.assertEqual(seen,[{}, {}, {}]);write.assert_not_called()

if __name__=='__main__':unittest.main()
