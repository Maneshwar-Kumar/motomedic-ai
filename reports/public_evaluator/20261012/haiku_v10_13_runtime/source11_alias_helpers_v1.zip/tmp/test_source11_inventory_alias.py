"""Synthetic source11 archive/startup/reuse checks; no provider or cloud calls."""
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'));sys.path.insert(0,str(ROOT/'tmp/public_evaluator'))
import prepare_evaluator_v10_13_v3 as helper
import private_acceptance_console_v10_13_v4 as console

STARTUP_SCRIPT=r'''
import ast,importlib.util,json,os,sys
from pathlib import Path
root=Path(sys.argv[1]);sys.path.insert(0,str(root/'tmp/public_evaluator'));sys.path.insert(0,str(root))
path=root/'tmp/public_evaluator/hosted_client_v10_13_v2.py'
spec=importlib.util.spec_from_file_location('actual_archived_paid_client',path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
tree=ast.parse(path.read_bytes());run=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='run')
def marker(node,value):
 return isinstance(node,ast.Assign) and isinstance(node.value,ast.Constant) and node.value.value==value
start=next(i for i,node in enumerate(run.body) if marker(node,'SOURCE_INVENTORY'))
end=next(i for i,node in enumerate(run.body) if marker(node,'PRIVATE_BACKEND_IDENTITY'))
# Execute unchanged actual archive statements, ending before Backend construction.
fn=ast.FunctionDef(name='actual_source_and_budget_startup',args=run.args,
 body=[ast.Global(names=['PREFLIGHT_STAGE'])]+run.body[start:end+1]+[ast.Return(value=ast.Name(id='inventory',ctx=ast.Load()))],decorator_list=[])
exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'actual_archived_paid_client_startup','exec'),module.__dict__)
os.environ['MOTOMEDIC_VISITOR_SECRET']='synthetic-not-a-credential-32-characters'
args=type('Args',(),{'backend':'https://motomedic-arm-a-279945185781.us-central1.run.app',
 'runtime_lock':sys.argv[2],'measured_phase_budget_json':sys.argv[3]})()
try:
 inventory=module.actual_source_and_budget_startup(args)
 print(json.dumps({'stage':module.PREFLIGHT_STAGE,'checked_files':len(inventory['file_sha256']),'transport_calls':0}))
except Exception as error:
 print(json.dumps({'stage':module.PREFLIGHT_STAGE,'exception_class':type(error).__name__,'error':str(error) if isinstance(error,module.EvaluationFailure) else 'SANITIZED_EXCEPTION','transport_calls':0}))
 raise SystemExit(2)
'''


class AliasArchiveTests(unittest.TestCase):
    def setUp(self):
        self.original=json.loads((helper.OUT/helper.ORIGINAL_SOURCE).read_bytes())
        self.release=json.loads(helper.MANIFEST.read_bytes())
        self.raw,self.files,self.alias=helper.source11_archive(self.original,self.release)
        self.source={**deepcopy(self.original),'files':self.files,
            'uri':'gs://'+helper.cloud.BUCKET+'/serving/engineering-clients/v10_13/'+hashlib.sha256(self.raw).hexdigest()+'.tar.gz',
            'object':'serving/engineering-clients/v10_13/'+hashlib.sha256(self.raw).hexdigest()+'.tar.gz',
            'generation':'1','sha256':hashlib.sha256(self.raw).hexdigest(),'bytes':len(self.raw),
            'exact_byte_inventory_alias':self.alias,'derived_from_source10':{
                'path':'reports/public_evaluator/20261012/'+helper.ORIGINAL_SOURCE,
                'sha256':hashlib.sha256((helper.OUT/helper.ORIGINAL_SOURCE).read_bytes()).hexdigest()}}
        job=json.loads((helper.OUT/'count_only_submission_v10_13_v2.json').read_bytes())['operation']['metadata']['build']['id']
        count_path=helper.OUT/'hosted_runs'/job/'count_receipt.json'
        self.count=json.loads(count_path.read_bytes())
        self.budget=helper.make_budget(self.count,self.source,hashlib.sha256(count_path.read_bytes()).hexdigest(),helper.ROUTING_CONTRACT)

    def extract(self,directory):
        with tarfile.open(fileobj=io.BytesIO(self.raw),mode='r:gz') as archive:
            for item in archive.getmembers():
                target=Path(directory)/item.name
                self.assertTrue(target.resolve().is_relative_to(Path(directory).resolve()))
                self.assertTrue(item.isfile());target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(archive.extractfile(item).read())

    def startup(self,directory):
        result=subprocess.run([sys.executable,'-I','-c',STARTUP_SCRIPT,str(directory),self.source['runtime_lock'],
            json.dumps(self.budget,separators=(',',':'))],cwd=directory,capture_output=True,text=True,timeout=30)
        self.assertFalse(result.stderr,result.stderr)
        return result.returncode,json.loads(result.stdout)

    def test_archive_adds_only_identical_inventory_alias_and_preserves_every_old_byte(self):
        with tarfile.open(fileobj=io.BytesIO(self.raw),mode='r:gz') as archive:
            self.assertEqual(set(archive.getnames()),set(self.original['files'])|{helper.PAID_INVENTORY_ALIAS})
            for name,expected in self.original['files'].items():
                self.assertEqual(hashlib.sha256(archive.extractfile(name).read()).hexdigest(),expected)
            self.assertEqual(archive.extractfile(helper.PAID_INVENTORY_ALIAS).read(),archive.extractfile(helper.ORIGINAL_INVENTORY).read())
        self.assertTrue(helper.validate_source11_reuse(self.source,self.original))

    def test_actual_archived_client_passes_source_inventory_and_original_count_budget_before_transport(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory:
            self.extract(directory);code,result=self.startup(directory)
        self.assertEqual(code,0,result)
        self.assertEqual(result,{'stage':'PRIVATE_BACKEND_IDENTITY','checked_files':19,'transport_calls':0})

    def test_original_missing_alias_reproduces_actual_source_inventory_failure(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory:
            self.extract(directory);(Path(directory)/helper.PAID_INVENTORY_ALIAS).unlink()
            code,result=self.startup(directory)
        self.assertEqual(code,2);self.assertEqual(result['stage'],'SOURCE_INVENTORY')
        self.assertEqual(result['exception_class'],'FileNotFoundError');self.assertEqual(result['transport_calls'],0)

    def test_archived_input_tamper_still_fails_actual_startup(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory:
            self.extract(directory);target=Path(directory)/'tmp/public_evaluator/count_history_v1.json'
            target.write_bytes(target.read_bytes()+b' ')
            code,result=self.startup(directory)
        self.assertEqual(code,2);self.assertEqual(result['error'],'CLIENT_SOURCE_INPUT_CHANGED')

    def test_count_history_client_runtime_inventory_policy_changes_cannot_reuse_count2(self):
        for name in ('tmp/public_evaluator/count_only_context_v10_13_v2.py','tmp/public_evaluator/count_history_v1.json',
                     'tmp/public_evaluator/hosted_client_v10_13_v2.py',helper.PAID_INVENTORY_ALIAS):
            changed=deepcopy(self.source);changed['files'][name]='0'*64
            with self.subTest(name=name),self.assertRaises(ValueError):helper.validate_source11_reuse(changed,self.original)
        changed=deepcopy(self.source);changed['runtime_lock']='0'*64
        with self.assertRaises(ValueError):helper.validate_source11_reuse(changed,self.original)

    def test_original_count2_receipt_and_config_remain_accepted_without_new_calls(self):
        console.validate_count_receipt(self.count,self.original)
        original_budget=helper.make_budget(self.count,self.original,'1'*64,helper.ROUTING_CONTRACT)
        new_budget=helper.make_budget(self.count,self.source,'1'*64,helper.ROUTING_CONTRACT)
        self.assertEqual(original_budget,new_budget)
        recorded=json.loads((helper.OUT/'count_only_submission_v10_13_v2.json').read_bytes())
        binding=json.loads((helper.OUT/'hosted_image_binding_v10_13.json').read_bytes())
        self.assertEqual(recorded['config'],helper.count_config(self.original,binding))

    def test_new_exact_conditional_grant_replaces_only_source10_identity(self):
        prior=json.loads((helper.OUT/'operations/client_source_grant_v10.json').read_bytes())
        prefix='projects/_/buckets/'+helper.cloud.BUCKET+'/objects/'
        old={'role':console.GET_ROLE,'members':[console.MEMBER],'condition':{
            'expression':"resource.name == '"+prefix+prior['source']['object']+"'",
            'title':'motomedic-backend-exact-evaluator-client-v10-13-v10'}}
        untouched={'role':'unrelated-role','members':['unrelated-member'],'condition':{'expression':'unchanged'}}
        policy={'etag':'synthetic','version':3,'bindings':[old,untouched]}
        updated,removed,added=console.source_policy_replacement(policy,prior,self.source)
        self.assertEqual(removed,old);self.assertEqual(updated['bindings'][0],untouched)
        self.assertEqual(added['condition']['title'],'motomedic-backend-exact-evaluator-client-v10-13-v11')
        self.assertEqual(policy['bindings'],[old,untouched])


if __name__=='__main__':unittest.main()
