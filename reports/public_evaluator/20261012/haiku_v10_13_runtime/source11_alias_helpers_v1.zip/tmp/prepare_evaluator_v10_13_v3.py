import gzip,hashlib,io,json,sys,tarfile
from pathlib import Path
from urllib.parse import urlencode
sys.path.insert(0,str(Path(__file__).resolve().parent))
import submit_hosted_v10 as cloud
from cloud.grounded_generation.verified_qa import Config
from cloud.grounded_generation.role_contracts import HAIKU_VERIFIER
from cloud.grounded_generation.role_router import ROUTING_CONTRACT
from evidence_registry import content_hash
sys.path.insert(0,str(cloud.ROOT/'tmp/public_evaluator'))
from phase_budget_v10_13_v2 import make_budget
ROOT,OUT=cloud.ROOT,cloud.OUT
MANIFEST=OUT/'serving_manifest_v10_13.json'
RUNTIME_MODULES=('tools.check_installed_serving_release','cloud.serving_artifacts',
    'cloud.grounded_generation.cached_verifier','cloud.grounded_generation.role_router',
    'cloud.grounded_generation.verified_qa','cloud.grounded_generation.serving_source_authority')
ORIGINAL_SOURCE='evaluator_client_source_v10.json'
SOURCE11='evaluator_client_source_v11.json'
ORIGINAL_INVENTORY='tmp/public_evaluator/client_inputs_v10_13_v2.json'
PAID_INVENTORY_ALIAS='tmp/public_evaluator/client_inputs_v10_13.json'


def source11_archive(original,release):
    """Pure exact-byte source10 preservation plus the paid client's inventory alias."""
    if (original.get('serving_manifest_sha256')!=hashlib.sha256(MANIFEST.read_bytes()).hexdigest() or
            original.get('count_module_origin_policy')!='ACTUAL_FROZEN_APP_IMAGE_ONLY' or
            original.get('expected_frozen_runtime_module_origins')!={name:{'app_relative_path':name.replace('.','/')+'.py',
                'sha256':release['file_sha256'][name.replace('.','/')+'.py']} for name in RUNTIME_MODULES}):
        raise ValueError('EXACT_SOURCE10_FROZEN_RUNTIME_ORIGINS_REQUIRED')
    files=original.get('files')
    if type(files)is not dict or PAID_INVENTORY_ALIAS in files or ORIGINAL_INVENTORY not in files:
        raise ValueError('EXACT_SOURCE10_WITH_MISSING_PAID_ALIAS_REQUIRED')
    entries={}
    for name,expected in files.items():
        path=(ROOT/name).resolve()
        if not path.is_relative_to(ROOT) or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
            raise ValueError('ORIGINAL_SOURCE10_INPUT_BYTES_CHANGED')
        if name in release['file_sha256'] and release['file_sha256'][name]!=expected:
            raise ValueError('FROZEN_SOURCE10_INPUT_BINDING_CHANGED')
        entries[name]=path.read_bytes()
    original_bytes=entries[ORIGINAL_INVENTORY]
    if hashlib.sha256(original_bytes).hexdigest()!=original['source_inventory_sha256']:
        raise ValueError('EXACT_SOURCE10_INVENTORY_BYTES_REQUIRED')
    inventory=json.loads(original_bytes)
    if (inventory['file_sha256']!={name:value for name,value in files.items() if name!=ORIGINAL_INVENTORY} or
            inventory.get('serving_manifest_sha256')!=original['serving_manifest_sha256'] or
            inventory.get('model_routing_contract_sha256')!=original['model_routing_contract_sha256'] or
            inventory.get('expected_frozen_runtime_module_origins')!=original['expected_frozen_runtime_module_origins']):
        raise ValueError('ORIGINAL_SOURCE10_INVENTORY_BINDING_CHANGED')
    entries[PAID_INVENTORY_ALIAS]=original_bytes
    result=io.BytesIO()
    with gzip.GzipFile(fileobj=result,mode='wb',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for name in sorted(entries):
                raw=entries[name];row=tarfile.TarInfo(name);row.size=len(raw);row.mode=0o644;row.mtime=0
                archive.addfile(row,io.BytesIO(raw))
    hashes={name:hashlib.sha256(raw).hexdigest() for name,raw in entries.items()}
    return result.getvalue(),hashes,{'original_path':ORIGINAL_INVENTORY,'alias_path':PAID_INVENTORY_ALIAS,
        'sha256':original['source_inventory_sha256'],'byte_identical':True,'all_source10_file_bytes_preserved':True,
        'paid_client_bytes_changed':False,'count_script_history_runtime_and_role_bytes_changed':False}


def validate_source11_reuse(source,original):
    raw,archive_files,alias=source11_archive(original,json.loads(MANIFEST.read_bytes()))
    expected_sha=hashlib.sha256(raw).hexdigest()
    expected_object='serving/engineering-clients/v10_13/'+expected_sha+'.tar.gz'
    if (set(source)!=set(original)|{'derived_from_source10','exact_byte_inventory_alias'} or
            source.get('sha256')!=expected_sha or source.get('bytes')!=len(raw) or
            source.get('object')!=expected_object or source.get('uri')!='gs://'+cloud.BUCKET+'/'+expected_object or
            type(source.get('generation'))is not str or not source['generation'].isdigit()):
        raise ValueError('SOURCE11_ACTUAL_ALIAS_ARCHIVE_HASH_CHANGED')
    expected={**original['files'],PAID_INVENTORY_ALIAS:original['source_inventory_sha256']}
    if (source.get('files')!=expected or source.get('source_inventory_sha256')!=original['source_inventory_sha256'] or
            source.get('derived_from_source10')!={'path':'reports/public_evaluator/20261012/'+ORIGINAL_SOURCE,
                'sha256':hashlib.sha256((OUT/ORIGINAL_SOURCE).read_bytes()).hexdigest()} or
            source.get('exact_byte_inventory_alias')!={'original_path':ORIGINAL_INVENTORY,'alias_path':PAID_INVENTORY_ALIAS,
                'sha256':original['source_inventory_sha256'],'byte_identical':True,'all_source10_file_bytes_preserved':True,
                'paid_client_bytes_changed':False,'count_script_history_runtime_and_role_bytes_changed':False}):
        raise ValueError('SOURCE11_EXACT_ALIAS_ONLY_REUSE_BINDING_CHANGED')
    for name,value in original.items():
        if name not in ('uri','object','generation','sha256','bytes','files') and source.get(name)!=value:
            raise ValueError('SOURCE11_ORIGINAL_COUNT_RUNTIME_POLICY_CHANGED')
    return True


def prepare():
    if (OUT/SOURCE11).exists():raise ValueError('SOURCE11_ALREADY_RECORDED')
    original=json.loads((OUT/ORIGINAL_SOURCE).read_bytes());release=json.loads(MANIFEST.read_bytes())
    raw,hashes,alias=source11_archive(original,release)
    archive_sha=hashlib.sha256(raw).hexdigest();obj='serving/engineering-clients/v10_13/'+archive_sha+'.tar.gz'
    req=cloud.Request('https://storage.googleapis.com/upload/storage/v1/b/'+cloud.BUCKET+'/o?'+urlencode(
        {'uploadType':'media','name':obj,'ifGenerationMatch':'0'}),data=raw,method='POST',
        headers={'Authorization':'Bearer '+cloud.token(),'Content-Type':'application/gzip'})
    with cloud.build_opener(cloud.NoRedirect()).open(req,timeout=60) as res:meta=json.load(res)
    value={**original,'uri':'gs://'+cloud.BUCKET+'/'+obj,'object':obj,'generation':str(meta['generation']),
        'sha256':archive_sha,'bytes':len(raw),'files':hashes,'exact_byte_inventory_alias':alias,
        'derived_from_source10':{'path':'reports/public_evaluator/20261012/'+ORIGINAL_SOURCE,
            'sha256':hashlib.sha256((OUT/ORIGINAL_SOURCE).read_bytes()).hexdigest()}}
    validate_source11_reuse(value,original)
    cloud.dump(SOURCE11,value);print(json.dumps({'source_receipt':SOURCE11,'sha256':archive_sha,'inventory_alias':alias,'provider_calls':0}))

def packed_client_arguments(arguments):
    """Cloud Build transports one lossless compressed budget; serving argv stays exact."""
    import base64
    if (not arguments or arguments[0]!='-B' or
            arguments[1]!='tmp/public_evaluator/hosted_client_v10_13_v2.py' or
            arguments[-2]!='--measured-phase-budget-json'):
        raise ValueError('EXACT_EVALUATOR_ARGUMENTS_REQUIRED')
    compressed=base64.b64encode(gzip.compress(arguments[-1].encode('utf-8'),mtime=0)).decode('ascii')
    wrapper=('import base64,gzip,runpy,sys; from pathlib import Path; '
        'budget=gzip.decompress(base64.b64decode(sys.argv[1],validate=True)).decode("utf-8"); '
        'sys.argv=sys.argv[2:]+["--measured-phase-budget-json",budget]; '
        'sys.path.insert(0,str(Path(sys.argv[0]).resolve().parent)); '
        'runpy.run_path(sys.argv[0],run_name="__main__")')
    result=['-B','-c',wrapper,compressed]+arguments[1:-2]
    if any(len(value.encode('utf-8'))>10000 for value in result):
        raise ValueError('CLOUD_BUILD_ARGUMENT_BYTE_LIMIT')
    return result

def submit():
    if (OUT/'evaluator_client_submission_v9.json').exists():raise ValueError('PAID_ATTEMPT9_ALREADY_RECORDED_USE_POLL')
    src=json.loads((OUT/'evaluator_client_source_v11.json').read_bytes())
    validate_source11_reuse(src,json.loads((OUT/ORIGINAL_SOURCE).read_bytes()))
    deployment=json.loads((OUT/'deployment_backend_v10_13_v2_result.json').read_bytes())
    if deployment.get('response',{}).get('terminalCondition',{}).get('state')!='CONDITION_SUCCEEDED':raise ValueError('PRIVATE_RUNTIME_NOT_READY')
    count_job=json.loads((OUT/'count_only_submission_v10_13_v2.json').read_bytes())['operation']['metadata']['build']['id']
    count_path=OUT/'hosted_runs'/count_job/'count_receipt.json'
    budget=make_budget(json.loads(count_path.read_bytes()),src,
        hashlib.sha256(count_path.read_bytes()).hexdigest(),ROUTING_CONTRACT)
    run_dir='tmp/public_evaluator/hosted-run-v9'
    config={'serviceAccount':'projects/'+cloud.PROJECT+'/serviceAccounts/'+src['service_account'],
        'source':{'storageSource':{'bucket':cloud.BUCKET,'object':src['object'],'generation':src['generation']}},
        'steps':[{'name':'docker.io/library/python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1',
                  'entrypoint':'python','args':['-c','from pathlib import Path; p=Path("/workspace/'+run_dir+'"); p.mkdir(parents=True,exist_ok=True); p.chmod(0o777)']},
            {'name':src['image'],'entrypoint':'python','args':['-B','tmp/public_evaluator/hosted_client_v10_13_v2.py',
                '--backend','https://motomedic-arm-a-279945185781.us-central1.run.app','--runtime-lock',src['runtime_lock'],
                '--allocated-job-id','$BUILD_ID','--output','/workspace/'+run_dir,
                '--artifact-uri','gs://'+cloud.BUCKET+'/engineering-acceptance/public-v10_3/$BUILD_ID',
                '--project',cloud.PROJECT,'--read-ledger','--stop-on-system-error','--check-completed-boundaries',
                '--measured-phase-budget-json',json.dumps(budget,sort_keys=True,separators=(',',':'))],
             'env':['PYTHONPATH=/workspace','MOTOMEDIC_HOSTED_PROVIDER_VALIDATION=true','MOTOMEDIC_CLOUD_BUILD_ID=$BUILD_ID'],
             'secretEnv':['MOTOMEDIC_VISITOR_SECRET']}],
        'availableSecrets':{'secretManager':[{'versionName':'projects/'+cloud.PROJECT+'/secrets/motomedic-rider-visitor-v1/versions/1','env':'MOTOMEDIC_VISITOR_SECRET'}]},
        'options':{'logging':'CLOUD_LOGGING_ONLY'},'timeout':'1800s'}
    config['steps'][1]['args']=packed_client_arguments(config['steps'][1]['args'])
    op=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds',config)
    cloud.dump('evaluator_client_submission_v9.json',{'config':config,'operation':op})
    print(json.dumps({'id':op['metadata']['build']['id'],'status':op['metadata']['build']['status']}))
def poll():
    bid=json.loads((OUT/'evaluator_client_submission_v9.json').read_bytes())['operation']['metadata']['build']['id']
    result=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds/'+bid)
    cloud.dump('evaluator_client_build_v9.json',result);print(json.dumps({'id':bid,'status':result['status']}))

def count_config(src, binding):
    if (binding['serving_manifest_sha256'] != src['serving_manifest_sha256'] or
            binding['runtime_revision'] != 'v10_13' or
            not binding['images']['backend'].startswith('us-central1-docker.pkg.dev/'+cloud.PROJECT+'/motomedic/arm-a@sha256:') or
            'tmp/public_evaluator/count_only_context_v10_13_v2.py' not in src['files'] or
            src.get('count_backend_image') != binding['images']['backend'] or
            src.get('count_module_origin_policy')!='ACTUAL_FROZEN_APP_IMAGE_ONLY' or
            set(src.get('expected_frozen_runtime_module_origins',{}))!=set(RUNTIME_MODULES)):
        raise ValueError('COUNT_ONLY_SOURCE_IMAGE_BINDING_CHANGED')
    run_dir='tmp/public_evaluator/count-only-v10_13-v2'
    return {'serviceAccount':'projects/'+cloud.PROJECT+'/serviceAccounts/'+src['service_account'],
        'source':{'storageSource':{'bucket':cloud.BUCKET,'object':src['object'],'generation':src['generation']}},
        'steps':[{'name':'docker.io/library/python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1',
            'entrypoint':'python','args':['-c','from pathlib import Path; p=Path("/workspace/'+run_dir+'"); p.mkdir(parents=True,exist_ok=True); p.chmod(0o777)']},
            {'name':binding['images']['backend'],'entrypoint':'python','args':['-B','tmp/public_evaluator/count_only_context_v10_13_v2.py',
                '--client-input-inventory','tmp/public_evaluator/client_inputs_v10_13_v2.json',
                '--runtime-lock',src['runtime_lock'],'--manifest-sha',src['serving_manifest_sha256'],
                '--allocated-job-id','$BUILD_ID','--output','/workspace/'+run_dir,
                '--artifact-uri','gs://'+cloud.BUCKET+'/engineering-acceptance/public-v10_3/$BUILD_ID',
                '--project',cloud.PROJECT],
             'env':['PYTHONPATH=/workspace:/app','K_SERVICE=motomedic-count-only-hosted-validation',
                'MOTOMEDIC_HOSTED_PROVIDER_VALIDATION=true','MOTOMEDIC_HOSTED_COUNT_ONLY=true','MOTOMEDIC_CLOUD_BUILD_ID=$BUILD_ID',
                'MOTOMEDIC_CLAUDE_FALLBACK_ENABLED=false','HF_HUB_OFFLINE=1','TRANSFORMERS_OFFLINE=1'],
             'secretEnv':['ANTHROPIC_API_KEY']}],
        'availableSecrets':{'secretManager':[
            {'versionName':'projects/'+cloud.PROJECT+'/secrets/motomedic-evaluator-anthropic-v1/versions/1','env':'ANTHROPIC_API_KEY'}]},
        'options':{'logging':'CLOUD_LOGGING_ONLY','machineType':'E2_HIGHCPU_8'},'timeout':'1200s'}

if __name__=='__main__':{'prepare':prepare,'submit':submit,'poll':poll}[sys.argv[1]]()
