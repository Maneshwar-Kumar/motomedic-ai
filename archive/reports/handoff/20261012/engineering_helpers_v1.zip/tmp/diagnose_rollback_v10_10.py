"""Finite read-only current10 rollback diagnosis; no mutation or credential output."""
import json,os,re,sys,subprocess
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import rollback_public_v10_10 as h

def result(code,booleans=None):
 assert re.fullmatch(r'[A-Z][A-Z0-9_]*',code)
 assert booleans is None or all(type(v)is bool for v in booleans.values())
 print(json.dumps({'code':code,'comparisons':booleans or {}},sort_keys=True),flush=True)

def sanitized(error):
 value=str(error)
 return value if re.fullmatch(r'[A-Z][A-Z0-9_]*',value) else type(error).__name__.upper()

def sdk(kind):
 env=os.environ.copy();env.pop('PYTHONPATH',None)
 p=subprocess.run([str(h.cloud.CLI),'auth',kind,'--account=maneshwarkumar@gmail.com','--quiet'],capture_output=True,text=True,env=env,timeout=45)
 token=p.stdout.strip()
 if p.returncode or not token or any(c.isspace() for c in token):raise RuntimeError('SDK_AUTHENTICATION_UNAVAILABLE')
 return token

try:
 binding,_=h.release();result('RELEASE_BINDING_PASS')
 access=sdk('print-access-token');h.cloud.token=lambda:access
 try:h.private_policies(include_ui=True);result('PRIVATE_POLICIES_PASS')
 except Exception as e:result(sanitized(e));raise SystemExit(0)
 identity=sdk('print-identity-token')
 for name in h.run.NAMES:
  tag={'motomedic-arm-a':'BACKEND','motomedic-rider-ui':'UI','motomedic-answer-worker':'WORKER'}[name]
  service=h.run.api('GET',h.run.PREFIX+name)
  try:h.require_service(name,service,binding);result(tag+'_SERVICE_GUARD_PASS')
  except Exception as e:result(sanitized(e));continue
  try:revision=h.routed_revision(service)
  except Exception as e:result(sanitized(e));continue
  actual=h.run.api('GET',h.run.PREFIX+name+'/revisions/'+revision)
  compare={'containers_equal':actual.get('containers')==service['template']['containers']}
  compare.update({k+'_equal':actual.get(k)==service['template'].get(k) for k in ('serviceAccount','timeout','maxInstanceRequestConcurrency')})
  a=actual.get('containers',[{}])[0];t=service['template']['containers'][0]
  compare.update({'container_'+k+'_equal':a.get(k)==t.get(k) for k in ('name','image','env','resources','ports','startupProbe','livenessProbe','args','command','volumeMounts')})
  result(tag+'_TRAFFIC_REVISION_COMPARISONS',compare)
  try:h.get_health(name,service,binding,identity);result(tag+'_EXACT_HEALTH_PASS')
  except Exception as e:result(sanitized(e))
except SystemExit:pass
except Exception as e:result(sanitized(e))
