"""Pure packaging check: no SDK, cloud writes or provider calls."""
import base64,contextlib,copy,gzip,io,json,runpy,sys,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import prepare_evaluator_v10_10 as helper
class PackagingTests(unittest.TestCase):
 def test_exact_budget_and_full_argv_roundtrip_and_recipe_scope(self):
  captured=[]
  def fake_api(url,body):
   captured.append(copy.deepcopy(body));return {'metadata':{'build':{'id':'synthetic-build','status':'QUEUED'}}}
  with patch.object(helper.cloud,'api',side_effect=fake_api),patch.object(helper.cloud,'dump'),contextlib.redirect_stdout(io.StringIO()):helper.submit()
  config=captured[0];step=config['steps'][1];args=step['args'];self.assertTrue(all(len(x.encode('utf-8'))<=10000 for x in args))
  payload=gzip.decompress(base64.b64decode(args[3],validate=True)).decode('utf-8')
  src=json.loads((helper.OUT/'evaluator_client_source_v7.json').read_bytes())
  countid=json.loads((helper.OUT/'count_only_submission_v10_10_v1.json').read_bytes())['operation']['metadata']['build']['id']
  cp=helper.OUT/'hosted_runs'/countid/'count_receipt.json'
  original_budget=helper.make_budget(json.loads(cp.read_bytes()),src,helper.hashlib.sha256(cp.read_bytes()).hexdigest(),helper.ROUTING_CONTRACT)
  expected_budget=json.dumps(original_budget,sort_keys=True,separators=(',',':'))
  self.assertEqual(payload,expected_budget)
  original_args=args[4:]+['--measured-phase-budget-json',expected_budget]
  previous=sys.argv[:]
  try:
   sys.argv=['-c']+args[3:]
   with patch.object(runpy,'run_path') as execute:exec(args[2],{})
   self.assertEqual(sys.argv,original_args)
   execute.assert_called_once_with('tmp/public_evaluator/hosted_client_v10_10.py',run_name='__main__')
  finally:sys.argv=previous
  self.assertEqual(config['source'],{'storageSource':{'bucket':helper.cloud.BUCKET,'object':src['object'],'generation':src['generation']}})
  self.assertEqual(step['name'],src['image'])
  self.assertEqual(step['env'],['PYTHONPATH=/workspace','MOTOMEDIC_HOSTED_PROVIDER_VALIDATION=true','MOTOMEDIC_CLOUD_BUILD_ID=$BUILD_ID'])
  self.assertEqual(step['secretEnv'],['MOTOMEDIC_VISITOR_SECRET'])
  self.assertEqual(config['availableSecrets']['secretManager'],[{'versionName':'projects/'+helper.cloud.PROJECT+'/secrets/motomedic-rider-visitor-v1/versions/1','env':'MOTOMEDIC_VISITOR_SECRET'}])
  self.assertEqual(config['timeout'],'1800s');self.assertEqual(config['options'],{'logging':'CLOUD_LOGGING_ONLY'})
 def test_invalid_shape_and_uncompressible_overlong_arg_rejected(self):
  with self.assertRaisesRegex(ValueError,'EXACT_EVALUATOR_ARGUMENTS_REQUIRED'):helper.packed_client_arguments(['wrong'])
  with self.assertRaisesRegex(ValueError,'CLOUD_BUILD_ARGUMENT_BYTE_LIMIT'):helper.packed_client_arguments(['-B','tmp/public_evaluator/hosted_client_v10_10.py','x'*10001,'--measured-phase-budget-json','{}'])
if __name__=='__main__':unittest.main()
