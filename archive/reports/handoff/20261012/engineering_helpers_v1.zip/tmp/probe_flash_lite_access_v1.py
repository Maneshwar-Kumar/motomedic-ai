"""Hosted exact-model metadata/count probe; no generation or billing changes."""
import json
import os
from pathlib import Path
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import submit_hosted_v10 as cloud

def token():
 env=os.environ.copy();env.pop('PYTHONPATH',None)
 result=subprocess.run([str(cloud.CLI),'auth','print-access-token','--account=maneshwarkumar@gmail.com','--quiet'],env=env,capture_output=True,timeout=45)
 if result.returncode or not result.stdout.strip():raise RuntimeError('SDK_AUTHENTICATION_UNAVAILABLE')
 return result.stdout.decode().strip()
cloud.token=token
NAME='flash_lite_access_probe_v1'
CODE='''import json,os,urllib.request,urllib.error
key=os.environ.get('MOTOMEDIC_GEMINI_API_KEY')
result={'schema':'motomedic-hosted-flash-lite-access-v1','model':'gemini-2.5-flash-lite','generation_calls':0,'provider_reservations':0,'credentials_logged':False}
if not key: raise SystemExit('PROVIDER_UNCONFIGURED')
base='https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite'
for kind in ('metadata','count'):
 body=None if kind=='metadata' else json.dumps({'contents':[{'parts':[{'text':'Hosted model-access check.'}]}]}).encode()
 request=urllib.request.Request(base if kind=='metadata' else base+':countTokens',data=body,headers={'x-goog-api-key':key,'Content-Type':'application/json'},method='GET' if kind=='metadata' else 'POST')
 try:
  with urllib.request.urlopen(request,timeout=25) as response: value=json.load(response)
  result[kind]={'status':'SUCCESS',**({name:value.get(name) for name in ('name','version','inputTokenLimit','outputTokenLimit','supportedGenerationMethods')} if kind=='metadata' else {'totalTokens':value.get('totalTokens')})}
 except urllib.error.HTTPError as error: result[kind]={'status':'HTTP_'+str(error.code)}
 except Exception:result[kind]={'status':'TRANSPORT_OR_SCHEMA_FAILURE'}
print(json.dumps(result,sort_keys=True))
if any(result[kind]['status']!='SUCCESS' for kind in ('metadata','count')):raise SystemExit(1)
'''

def submit():
 path=cloud.OUT/(NAME+'_submission.json')
 if path.exists():raise RuntimeError('PROBE_ALREADY_SUBMITTED_USE_POLL')
 image=json.loads((cloud.OUT/'hosted_image_binding_v10_10.json').read_bytes())['images']['backend']
 config={'serviceAccount':'projects/'+cloud.PROJECT+'/serviceAccounts/motomedic-arm-a@'+cloud.PROJECT+'.iam.gserviceaccount.com',
  'steps':[{'name':image,'entrypoint':'python','args':['-B','-c',CODE],
   'secretEnv':['MOTOMEDIC_GEMINI_API_KEY']}],
  'availableSecrets':{'secretManager':[{'versionName':'projects/'+cloud.PROJECT+'/secrets/motomedic-gemini-serving-v1/versions/1','env':'MOTOMEDIC_GEMINI_API_KEY'}]},
  'options':{'logging':'CLOUD_LOGGING_ONLY'},'timeout':'300s'}
 op=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds',config)
 cloud.dump(path.name,{'config':config,'operation':op,'generation_calls':0,'billing_changes':0})
 print(json.dumps({'id':op['metadata']['build']['id'],'status':op['metadata']['build']['status'],'generation_calls':0}))

def poll():
 bid=json.loads((cloud.OUT/(NAME+'_submission.json')).read_bytes())['operation']['metadata']['build']['id']
 result=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds/'+bid)
 cloud.dump(NAME+'_build.json',result)
 print(json.dumps({'id':bid,'status':result['status']}))

def result():
 bid=json.loads((cloud.OUT/(NAME+'_submission.json')).read_bytes())['operation']['metadata']['build']['id']
 value=cloud.api('https://logging.googleapis.com/v2/entries:list',{
  'resourceNames':['projects/'+cloud.PROJECT],
  'filter':'resource.type="build" AND resource.labels.build_id="'+bid+'"',
  'orderBy':'timestamp desc','pageSize':100})
 matches=[]
 for row in value.get('entries',[]):
  line=row.get('textPayload','')
  start=line.find('{')
  if start<0:continue
  try:data=json.loads(line[start:])
  except ValueError:continue
  if data.get('schema')=='motomedic-hosted-flash-lite-access-v1' and data.get('credentials_logged') is False:
   matches.append(data)
 if len(matches)!=1:raise RuntimeError('SANITIZED_PROBE_RESULT_NOT_READY_OR_NOT_UNIQUE')
 data=matches[0]
 data.update(cloud_build_id=bid,classification='LIVE_HOSTED_EXISTING_KEY_METADATA_AND_NATIVE_COUNT',
  api_key_project_association_verified=False,billing_changes=0,quota_changes=0,
  key_scope='EXISTING_SECRET_VERSION_USED_ONLY_ON_HOSTED_RUNNER')
 target=cloud.OUT/(NAME+'_result.json')
 if target.exists():raise RuntimeError('NEVER_OVERWRITE_PROBE_RESULT')
 cloud.dump(target.name,data)
 print(json.dumps(data,sort_keys=True))

if __name__=='__main__':{'submit':submit,'poll':poll,'result':result}[sys.argv[1]]()
