"""Exact historical10 read-only rollback poll diagnosis; no writes."""
import json,re,sys,subprocess,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import rollback_public_v10_10 as h

def out(code,checks=None):
 assert re.fullmatch('[A-Z][A-Z0-9_]*',code)
 assert checks is None or all(type(v)is bool for v in checks.values())
 print(json.dumps({'code':code,'comparisons':checks or {}},sort_keys=True),flush=True)
try:
 initial=h.read(h.receipt('initial'));saved=h.read(h.receipt('candidate_operations'));binding=initial['binding']
 assert saved['binding']==binding and h.file_hash(h.cloud.OUT/'serving_manifest_v10_10.json')==binding['serving_manifest_sha256']
 env=os.environ.copy();env.pop('PYTHONPATH',None)
 p=subprocess.run([str(h.cloud.CLI),'auth','print-access-token','--account=maneshwarkumar@gmail.com','--quiet'],capture_output=True,text=True,env=env,timeout=45)
 if p.returncode or not p.stdout.strip():raise RuntimeError('SDK_AUTHENTICATION_UNAVAILABLE')
 token=p.stdout.strip();h.cloud.token=lambda:token
 for name,row in saved['operations'].items():
  tag={'motomedic-arm-a':'BACKEND','motomedic-rider-ui':'UI','motomedic-answer-worker':'WORKER'}[name]
  op=h.run.api('GET','https://run.googleapis.com/v2/'+row['operation']['name'])
  out(tag+'_OPERATION_STATE',{'done':op.get('done')is True,'has_error':bool(op.get('error')),'has_response':bool(op.get('response'))})
  if not op.get('response'):continue
  service=op['response'];original=initial['services'][name];old=original['service']['template'];new=service['template']
  try:h.require_service(name,service,binding,original['template_sha256']);out(tag+'_SERVICE_AND_TEMPLATE_PASS')
  except ValueError as e:out(str(e) if re.fullmatch('[A-Z][A-Z0-9_]*',str(e)) else 'VALUEERROR')
  keys=set(old)|set(new);out(tag+'_TEMPLATE_COMPARISONS',{key+'_equal':old.get(key)==new.get(key) for key in keys if key not in ('revision','labels')})
  a=new['containers'][0];t=old['containers'][0]
  out(tag+'_CONTAINER_COMPARISONS',{k+'_equal':a.get(k)==t.get(k) for k in set(a)|set(t)})
  out(tag+'_REVISION_AND_LABEL_COMPARISONS',{'new_ready_revision':service.get('latestReadyRevision','').split('/')[-1]!=original['revision'],'traffic_on_original':h.routed_revision(service)==original['revision'],'labels_without_canary_equal':{k:v for k,v in new.get('labels',{}).items() if k!=h.LABEL_KEY}==old.get('labels',{})})
except Exception as e:out(str(e) if re.fullmatch('[A-Z][A-Z0-9_]*',str(e)) else type(e).__name__.upper())
