"""Hosted final-image retrieval/native counters only; never generate or reserve."""
import argparse
from copy import deepcopy
from dataclasses import asdict,replace
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time

WORKSPACE=Path(__file__).resolve().parents[2]
APP=Path('/app')
sys.path.insert(0,str(Path(__file__).parent))
sys.path.insert(0,str(APP))
PLAN='reports/public_evaluator/20261012/original_page_evaluator_plan_v2.json'
PLAN_SHA='a7dc784be633c14accdff256e57abb784a486076da07b149c6f2e04096ee5541'
HISTORY='tmp/public_evaluator/count_history_v1.json'
OWNER_MODEL_SCOPE_SHA='05145aff6facd33a6e22c86696bf9a4c16a15ae08bd5b28b9706358b69b08cfb'
NATIVE_STAGES=('GEMMA_ROUTING','SELECTED_DRAFT','VERIFIER_WORST_STRUCTURAL_SCAFFOLD',
    'VERIFIER_BASE_FULLSOURCE_PREFIX','CORRECTION_WORST_STRUCTURAL_SCAFFOLD',
    'VERIFIER_SYNTHETIC_STRESS_ENVELOPE','VERIFIER_MINIMUM_OUTPUT_SHAPE')


def wire(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def counter_transport(transport, allowed_path, receipt,*,metadata=False):
    """Enforce an exact method/path before an HTTP transport can see a key."""
    def call(method,path,body,key):
        if metadata and method=='GET' and path==allowed_path.removesuffix(':countTokens'):
            receipt['model_metadata_transport_calls']+=1
            return transport(method,path,body,key)
        if method!='POST' or path!=allowed_path:
            receipt['prohibited_transport_calls']+=1
            raise RuntimeError('COUNT_TRANSPORT_PATH_PROHIBITED')
        receipt['counter_transport_calls']+=1
        record=receipt.get('_active_counter_record')
        if type(record)is dict:
            record['counter_body_sha256']=hashlib.sha256(wire(body).encode()).hexdigest()
            record['counter_request_bytes']=len(wire(body).encode())
        return transport(method,path,body,key)
    return call


def retrieval_receipt(bundle):
    """Known bounded routing/rank scalars only; no queries, hits or excerpts."""
    policy=bundle.get('retrieval_policy',{})
    scalar_keys=('version','first_stage_execution','rerank_gate_version','rerank_mode',
        'rerank_attempts','rerank_pair_count','rerank_skip_reason','recovery_attempts',
        'assembled_hit_limit','final_action')
    result={k:deepcopy(policy[k]) for k in scalar_keys if k in policy}
    signals=policy.get('initial_ranking_signals',{})
    signal_keys=('rerank_gate_version','rank_comparison_available','compared_rank_positions',
        'dense_sparse_section_overlap','relative_rrf_section_margin','ranking_uncertain',
        'rrf_margin_is_diagnostic_only')
    result['initial_ranking_signals']={k:deepcopy(signals[k]) for k in signal_keys if k in signals}
    for key in ('dense_top_distinct_parent_ids','sparse_top_distinct_parent_ids',
                'disagreeing_rank_positions','uncertainty_reasons'):
        if key in signals:result['initial_ranking_signals'][key]=deepcopy(signals[key][:3])
    stages=('dense_query_embedding_and_qdrant_rpc','bm25_scoring','initial_assembly',
            'dependency_recovery','reranking')
    result['stages_seconds']={k:policy['stages_seconds'][k] for k in stages
                             if k in policy.get('stages_seconds',{})}
    dense=policy.get('dense_rpc') or {}
    dense_keys=('backend','index_id','source_sha256','collection','remote_candidate_limit',
                'returned_points','query_embedding_only','document_embedding_calls')
    result['dense_rpc']={k:deepcopy(dense[k]) for k in dense_keys if k in dense}
    result['reranked']=bundle.get('reranked') is True
    return result


def main(args):
    from hosted_client import ledger,save,upload_artifacts,safe_code
    output=Path(args.output);output.mkdir(parents=True,exist_ok=True)
    receipt={'schema':'motomedic-hosted-native-count-role-preflight-v2',
        'classification':'HOSTED_NATIVE_COUNTERS_AND_ROLE_FORECAST_ONLY','cloud_build_id':os.environ.get('MOTOMEDIC_CLOUD_BUILD_ID'),
        'allocated_job_id':args.allocated_job_id,'serving_manifest_sha256':args.manifest_sha,
        'runtime_lock':args.runtime_lock,'script_sha256':sha(__file__),'history_sha256':sha(WORKSPACE/HISTORY),
        'owner_model_scope_sha256':OWNER_MODEL_SCOPE_SHA,
        'generation_calls':0,'reservation_calls':0,'native_counter_calls':0,'planned_native_counter_calls':42,
        'model_metadata_transport_calls':0,
        'counter_transport_calls':0,'prohibited_transport_calls':0,'transport_allowlist_enforced':False,
        'planned_case_count':6,'cases':[],'preflight_passed':False,'provider_allocation_delta_zero':False,
        'actual_finalized_verifier_count_demonstrated':False,
        'future_finalized_verifier_quota_status':'UNKNOWN_MANDATORY_ACTUAL_FINAL_COUNT',
        'history_scope':'Prior-run actual saved SYSTEM_ERROR history; prospective accepted history is unknown.',
        'verifier_scope':'Generic synthetic size-stress buffer only, never an answer/verdict or factual acceptance. Actual finalized verifier context still must be counted before generation.',
        'credentials_logged':False,'source_or_request_bodies_logged':False,'human_signoff':False}
    failure=None
    try:
        if (WORKSPACE!=Path('/workspace') or not APP.is_dir() or
                os.environ.get('MOTOMEDIC_HOSTED_PROVIDER_VALIDATION')!='true' or
                os.environ.get('MOTOMEDIC_HOSTED_COUNT_ONLY')!='true' or not os.environ.get('K_SERVICE') or
                not re.fullmatch(r'[0-9a-f-]{36}',receipt['cloud_build_id'] or '') or
                args.allocated_job_id!=receipt['cloud_build_id'] or
                not re.fullmatch(r'[0-9a-f]{64}',args.runtime_lock) or
                not re.fullmatch(r'[0-9a-f]{64}',args.manifest_sha)):
            raise RuntimeError('HOSTED_FINAL_IMAGE_COUNTER_CONTEXT_REQUIRED')
        inventory_path=(WORKSPACE/args.client_input_inventory).resolve()
        if not inventory_path.is_relative_to(WORKSPACE):raise RuntimeError('COUNT_INVENTORY_LOCATION_CHANGED')
        inventory=json.loads(inventory_path.read_bytes())
        if inventory.get('schema')!='motomedic-hosted-evaluator-client-inputs-v1':
            raise RuntimeError('COUNT_INVENTORY_SCHEMA_CHANGED')
        if inventory['serving_manifest_sha256']!=args.manifest_sha:
            raise RuntimeError('COUNT_SOURCE_MANIFEST_BINDING_CHANGED')
        for name,expected in inventory['file_sha256'].items():
            path=(WORKSPACE/name).resolve()
            if not path.is_relative_to(WORKSPACE) or sha(path)!=expected:
                raise RuntimeError('COUNT_SOURCE_INPUT_CHANGED')
        if sha(WORKSPACE/'reports/public_evaluator/20261012/owner_model_scope_v1.json')!=OWNER_MODEL_SCOPE_SHA:
            raise RuntimeError('COUNT_OWNER_MODEL_SCOPE_CHANGED')
        if sha(WORKSPACE/PLAN)!=PLAN_SHA:
            raise RuntimeError('COUNT_PLAN_CHANGED')
        history=json.loads((WORKSPACE/HISTORY).read_bytes())
        if history['plan_sha256']!=PLAN_SHA or history['schema']!='motomedic-native-count-actual-history-v1':
            raise RuntimeError('COUNT_ACTUAL_HISTORY_BINDING_CHANGED')
        from tools.check_installed_serving_release import check
        receipt['installed_inputs_verified']=check(APP)
        release=json.loads((APP/'arm_a_release.json').read_bytes())
        receipt['image_source_commit']=release['candidate_source_commit']
        from cloud.serving_artifacts import load_index
        index=load_index(release,APP/'build/serving-artifacts')
        from approved_registry import ApprovedEvidenceRegistry
        from cloud.grounded_generation.serving_source_authority import SourceAuthority
        from cloud.grounded_generation.verified_qa import (Config,Composer,model_source_context,
            compact_model_context,expand_model_context,DRAFT_POLICY,DRAFT_SCHEMA,VERIFY_POLICY,VERIFY_SCHEMA)
        from cloud.grounded_generation.cached_verifier import CachedVerifier,CachedDraft,CONTRACT
        from cloud.grounded_generation.provider import MODEL
        from cloud.grounded_generation.role_router import GemmaRole,RoleRouter,ROUTING_CONTRACT
        from cloud.grounded_generation.role_contracts import GEMMA,HAIKU,GEMMA_INPUT_TPM,OUTPUT_TOKENS
        from cloud.grounded_generation.serving_retrieval import GuardedRetriever,QUERY_CONTEXT
        from cloud.grounded_generation.serving_questions import Questions
        from cloud.arm_a.runtime_controls import TokenBudget
        from rider_ui.safeguards import diagnostic_projection
        from evidence_registry import content_hash
        config=Config(verifier_contract=CONTRACT,routing_contract=ROUTING_CONTRACT)
        receipt['model_routing_contract_sha256']=content_hash(ROUTING_CONTRACT)
        if release['model_routing_contract']!=ROUTING_CONTRACT:raise RuntimeError('COUNT_INSTALLED_MODEL_ROUTING_CHANGED')
        if config.lock!=args.runtime_lock:raise RuntimeError('COUNT_IMAGE_RUNTIME_LOCK_CHANGED')
        registry=ApprovedEvidenceRegistry.load(APP,index);authority=SourceAuthority(registry,index)
        receipt.update(manual_checksum=registry.checksum,index_id=registry.index_id,
                       source_authority_lock=authority.lock,document_parse_calls=0,document_embedding_calls=0)
        def no_reservation(*unused):
            receipt['reservation_calls']+=1
            raise RuntimeError('COUNT_JOB_FORBIDS_RESERVATION')
        class ForbiddenAdmission:
            begin_turn=no_reservation
            reserve_correction=no_reservation
            end_turn=no_reservation
        gd=GemmaRole(no_reservation,role='private_draft',pre_reserved=True)
        gv=GemmaRole(no_reservation,role='semantic_verifier',pre_reserved=True)
        hd=CachedDraft(no_reservation,pre_reserved=True)
        hv=CachedVerifier(no_reservation,pre_reserved=True)
        providers=(gd,gv,hd,hv)
        for provider in providers:
            if provider.contract['model']==GEMMA:
                provider.transport=counter_transport(provider.transport,'models/'+MODEL+':countTokens',receipt,metadata=provider is gd)
            else:provider.transport=counter_transport(provider.transport,'messages/count_tokens',receipt)
        receipt['transport_allowlist_enforced']=True
        receipt['allowed_provider_transport_paths']=['POST models/'+MODEL+':countTokens','POST messages/count_tokens',
            'GET models/'+MODEL]
        router=RoleRouter(gd,hd,gv,hv,ForbiddenAdmission())
        composer=Composer(source_authority=authority,router=router)
        if composer.config.lock!=args.runtime_lock:raise RuntimeError('COUNT_ROUTER_RUNTIME_LOCK_CHANGED')
        if args.model_metadata:
            metadata=gd.transport('GET','models/'+MODEL,None,gd.key)
            if (metadata.get('name')!='models/'+MODEL or type(metadata.get('inputTokenLimit'))is not int or
                metadata['inputTokenLimit']<256000 or type(metadata.get('outputTokenLimit'))is not int or
                metadata['outputTokenLimit']<OUTPUT_TOKENS):raise RuntimeError('GEMMA_NATIVE_METADATA_INCOMPATIBLE')
            receipt['gemma_native_metadata']={k:metadata[k] for k in ('name','inputTokenLimit','outputTokenLimit')}
        receipt['ledger_before']=ledger(args.project)
        os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
        os.environ['HF_HUB_DISABLE_PROGRESS_BARS']='1'
        from sentence_transformers import SentenceTransformer,CrossEncoder
        packaged=APP/'build/index'
        inherited=json.loads((packaged/'manifest.json').read_bytes())
        if inherited['embedding']!=release['index']['embedding']:
            raise RuntimeError('COUNT_PINNED_MODEL_IDENTITY_CHANGED')
        embedding=SentenceTransformer(str(packaged/'embedding_model'),device='cpu',local_files_only=True)
        reranker=CrossEncoder(str(packaged/'reranker_model'),device='cpu',local_files_only=True)
        retriever=GuardedRetriever(index,rerank=True,embedding_model=embedding,cross_encoder=reranker,
                                   source_authority=authority)
        budget=TokenBudget(embedding,retriever.manifest['embedding'],DRAFT_POLICY,hashlib.sha256(DRAFT_POLICY.encode()).hexdigest())
        retriever.install_controls(budget)
        questions=Questions(registry,retriever,composer,authority)
        # These are native token-counter transports only. Any generation/cost
        # method is replaced with a hard prohibition, independent of reservation.
        def no_generation(*unused):
            receipt['generation_calls']+=1
            raise RuntimeError('COUNT_JOB_FORBIDS_GENERATION')
        for provider in providers:
            provider.complete=no_generation;provider.begin_turn=no_reservation
        current_native=[];current_stage=[None]
        def counted(original,provider):
            def call(body):
                receipt['native_counter_calls']+=1
                record={'stage':current_stage[0],'model':provider.contract['model'],'role':provider.contract['role'],
                    'request_bytes':len(wire(body).encode()),'request_body_sha256':content_hash(body),
                    'counter_is_estimate':provider.contract['model']==HAIKU}
                current_native.append(record)
                receipt['_active_counter_record']=record
                try:
                    value=original(body);record['input_tokens_counted']=value;return value
                except Exception as exc:
                    record['failure_code']=safe_code(str(exc),'NATIVE_COUNTER_FAILURE');raise
                finally:receipt.pop('_active_counter_record',None)
            return call
        def contextual(original,provider):
            def call(policy,stable,dynamic,schema,**kwargs):
                logical=expand_model_context(dynamic) if dynamic.get('encoding') else dynamic
                if schema==DRAFT_SCHEMA:
                    stage=('CORRECTION_WORST_STRUCTURAL_SCAFFOLD' if 'correction_feedback' in logical else
                           'GEMMA_ROUTING' if kwargs.get('_sizing') else 'SELECTED_DRAFT')
                else:
                    claims=logical.get('complete_proposed_response',{}).get('claims',[])
                    stage=('VERIFIER_BASE_FULLSOURCE_PREFIX' if not claims else
                        'VERIFIER_SYNTHETIC_STRESS_ENVELOPE' if claims[0].get('text','').startswith('SYNTHETIC') else
                        'VERIFIER_WORST_STRUCTURAL_SCAFFOLD')
                current_stage[0]=stage
                return original(policy,stable,dynamic,schema,**kwargs)
            return call
        for provider in providers:
            if provider.contract['model']==GEMMA:provider.count=counted(provider.count,provider)
            else:provider._count=counted(provider._count,provider)
            provider.context=contextual(provider.context,provider)
        plan=json.loads((WORKSPACE/PLAN).read_bytes())
        for case in plan['cases']:
            started=time.monotonic();session=replace(questions.new_session(),version=1)
            conversation=deepcopy(history['cases'][case['case_id']]['conversation'])
            token=QUERY_CONTEXT.set(conversation)
            try:
                bundle=retriever.search(case['question'],limit=6,scope=questions.scope(),applicability_status='CONFIRMED')
            finally:QUERY_CONTEXT.reset(token)
            admitted=authority.assemble(bundle);authority.validate(admitted)
            stable=model_source_context(config,registry,admitted)
            context={'conversation':conversation,'typed_outcomes':diagnostic_projection(session),
                'required_route':None,'required_safety_evidence_ids':[],
                'source_conflicts':deepcopy(bundle.get('conflicts',[])),
                'operation_id':hashlib.sha256(('count-only:'+case['case_id']).encode()).hexdigest()[:32]}
            row={'case_id':case['case_id'],'question_sha256':content_hash(case['question']),
                'admitted_evidence_count':len(admitted['evidence']),
                'mandatory_display_count':len(admitted['required_display']),'gap_count':len(admitted['gaps']),
                'full_evidence_payload_sha256':admitted['payload_sha256'],
                'stable_json_bytes':len(wire(stable).encode()),
                'stable_component_json_bytes':{k:len(wire(v).encode()) for k,v in stable.items()},
                'actual_prior_history_turn_count':len(conversation),
                'retrieval_policy':retrieval_receipt(bundle)}
            current_native.clear()
            dynamic_input={'question':case['question'],'history':context}
            selected=None;forecast=None
            try:
                selected,stable=router.select(stable,dynamic_input)
                row['stable_json_bytes']=len(wire(stable).encode())
                row['stable_component_json_bytes']={k:len(wire(v).encode()) for k,v in stable.items()}
                row['role_plan']=selected.binding()
                row['selected_models']={'draft':selected.draft.contract['model'],'verifier':selected.verifier.contract['model']}
                row['selected_draft_native_window_eligible']=True
                row['selected_draft_actual_quota_eligible']=(selected.draft.contract['model']!=GEMMA or selected.initial_input_tokens<=GEMMA_INPUT_TPM)
                forecast=router.reservation_plan(selected,stable,dynamic_input,admitted,session)
                row['initial_phase_slots']=deepcopy(forecast['slots'][:3])
                row['conditional_correction_phase_slots']=deepcopy(forecast['slots'][3:])
                row['known_verifier_prefix_native_tokens']=forecast['known_verifier_prefix_native_tokens']
                row['known_verifier_fixed_quota_eligible']=True
                row['forecasts']={k:v for k,v in forecast.items() if k!='slots'}
            except Exception as exc:
                row['forecast_failure_code']=safe_code(str(exc),'NATIVE_COUNTER_FAILURE')
                row.setdefault('selected_draft_native_window_eligible',False)
                row.setdefault('selected_draft_actual_quota_eligible',False)
                row['known_verifier_fixed_quota_eligible']=False
            if selected is None:
                row['native_stages']=deepcopy(current_native);receipt['cases'].append(row)
                print(json.dumps(row),flush=True);continue
            # Deliberately generic, no expected-answer criteria or inferred rider
            # facts. It exercises12 draft claims plus complete admitted displays
            # and citations, not an unknown actual finalized answer or a verdict.
            ids=sorted(admitted['evidence'])
            claims=[{'claim_id':'synthetic:'+str(i),'text':'SYNTHETIC COUNTER-ONLY SIZE BUFFER; no factual answer or semantic acceptance is asserted.',
                'role':'FACT','evidence_ids':[ids[i%len(ids)]] if ids else [],
                'presentation_mode':'VERIFIED_GENERATED_PARAPHRASE','origin':'DRAFT'} for i in range(12)]
            claims += [{'claim_id':'source:'+c['claim_id'],'text':c['text'],'role':c['response_role'],
                'evidence_ids':deepcopy(c['evidence_ids']),'presentation_mode':'VERIFIED_SOURCE_PARAPHRASE',
                'origin':'SOURCE_REQUIRED_DISPLAY'} for c in admitted['required_display']]
            citations=[{'evidence_id':c['evidence_id'],'pdf_page':c['pdf_page'],'pdf_page_index':c['pdf_page']-1,
                'manual_checksum':registry.checksum,'index_id':registry.index_id} for c in admitted['citation_mapping']]
            final={'route':'SUPPORTED','text':' '.join(c['text'] for c in claims),'claims':claims,
                'citations':citations,'clarification_question':None,'escalation_uri':None,
                'trace_id':'synthetic-count-only','session_status':session.status}
            binding={'version':config.controls_version,'runtime_lock':config.lock,
                'draft_model_contract_sha256':selected.draft_contract_sha256,
                'verifier_contract_sha256':selected.verifier_contract_sha256,
                'question_sha256':content_hash(case['question']),'history_sha256':content_hash(context),
                'session_sha256':content_hash(asdict(session)),'response_sha256':content_hash(final),
                'evidence_payload_sha256':admitted['payload_sha256'],'source_authority_lock':authority.lock,
                'manual_checksum':registry.checksum,'index_id':registry.index_id,'operation_id':context['operation_id'],
                'role_plan':selected.binding()}
            dynamic=compact_model_context({'question':case['question'],'history':context,
                'complete_proposed_response':final,'declared_question_coverage':'COMPLETE','unanswered_parts':[],
                'binding':binding,'binding_sha256':content_hash(binding)})
            row.update(synthetic_final_claim_count=len(claims),synthetic_final_text_bytes=len(final['text'].encode()),
                synthetic_final_is_not_an_answer=True,verifier_dynamic_json_bytes=len(wire(dynamic).encode()))
            try:
                kwargs={'_sizing':True} if selected.verifier.contract['model']==GEMMA else {}
                _,n=selected.verifier.context(VERIFY_POLICY,stable,dynamic,VERIFY_SCHEMA,**kwargs)
                row['verifier_synthetic_stress_native_window_eligible']=n<=selected.verifier.contract['input_tokens']
                row['gemma_synthetic_stress_actual_quota_eligible']=(n<=GEMMA_INPUT_TPM) if selected.verifier.contract['model']==GEMMA else None
            except Exception as exc:
                row['verifier_synthetic_stress_native_window_eligible']=False
                row['verifier_failure_code']=safe_code(str(exc),'NATIVE_COUNTER_FAILURE')
            minimum={'binding_sha256':content_hash(binding),'decision':'RELEASE_COMPLETE','question_coverage':'COMPLETE',
                'per_claim_support':[{'claim_id':c['claim_id'],'supported':True,'supported_evidence_ids':c['evidence_ids'],
                    'reason':'x'} for c in claims],'omissions':[],'conflicts':[],'coverage_limitation_clear':True,
                'clarification_is_rider_resolvable':False,'release_eligible':True,'correction_possible':False}
            current_stage[0]='VERIFIER_MINIMUM_OUTPUT_SHAPE'
            try:
                minimum_tokens=selected.verifier.count({'contents':[{'role':'user','parts':[{'text':wire(minimum)}]}]})
                row['verifier_minimum_synthetic_output_tokens']=minimum_tokens
                row['verifier_minimum_synthetic_output_within1800']=minimum_tokens<=OUTPUT_TOKENS
            except Exception as exc:row['verifier_minimum_output_failure_code']=safe_code(str(exc),'NATIVE_COUNTER_FAILURE')
            row['minimum_output_is_structural_diagnostic_not_verdict']=True
            row['native_stages']=deepcopy(current_native)
            row['actual_finalized_verifier_count_demonstrated']=False
            row['future_finalized_verifier_quota_status']='UNKNOWN_MANDATORY_ACTUAL_FINAL_COUNT'
            authority.validate(admitted);row['seconds']=time.monotonic()-started
            receipt['cases'].append(row);print(json.dumps(row),flush=True)
        receipt['ledger_after']=ledger(args.project)
        receipt['provider_allocation_delta_zero']=receipt['ledger_before']==receipt['ledger_after']
        receipt['case_count']=len(receipt['cases'])
        flags=('selected_draft_native_window_eligible','selected_draft_actual_quota_eligible',
               'known_verifier_fixed_quota_eligible','verifier_synthetic_stress_native_window_eligible')
        for key in flags:receipt[key]=len(receipt['cases'])==6 and all(r.get(key) is True for r in receipt['cases'])
        receipt['declared_native_stage_order']=list(NATIVE_STAGES)
        def total(which,key):return sum(slot.get(key,0) for row in receipt['cases'] for slot in row.get(which,[]))
        receipt['measured_initial_phase_capacity']={'attempts':sum(len(r.get('initial_phase_slots',[])) for r in receipt['cases']),
            'tokens':total('initial_phase_slots','input_tokens')+total('initial_phase_slots','output_tokens'),
            'haiku_nanodollars':total('initial_phase_slots','maximum_nanodollars')}
        receipt['conditional_correction_forecast_capacity']={'attempts':sum(len(r.get('conditional_correction_phase_slots',[])) for r in receipt['cases']),
            'tokens':total('conditional_correction_phase_slots','input_tokens')+total('conditional_correction_phase_slots','output_tokens'),
            'haiku_nanodollars':total('conditional_correction_phase_slots','maximum_nanodollars')}
        primary_ledger=receipt['ledger_after'].get('grounded-primary-nonrecurring-v1',{})
        haiku_ledger=receipt['ledger_after'].get('owner-haiku-fallback-20261011-validation-v1',{})
        receipt['remaining_allocation']={'attempts':100-primary_ledger.get('reserved_attempts',0),
            'tokens':999200-primary_ledger.get('reserved_tokens',0),
            'haiku_nanodollars':1000000000-haiku_ledger.get('reserved_nanodollars',0)}
        receipt['initial_six_forecasts_fit_remaining_allocation']=all(
            receipt['measured_initial_phase_capacity'][k]<=receipt['remaining_allocation'][k]
            for k in ('attempts','tokens','haiku_nanodollars'))
        receipt['preflight_passed']=all(([receipt[k] for k in flags]+[receipt['provider_allocation_delta_zero'],
            receipt['native_counter_calls']==42,receipt['generation_calls']==0,receipt['reservation_calls']==0,
            receipt['transport_allowlist_enforced'],receipt['counter_transport_calls']==42,
            receipt['initial_six_forecasts_fit_remaining_allocation'],
            receipt['prohibited_transport_calls']==0]))
    except Exception as exc:
        failure=safe_code(str(exc),'COUNT_PREFLIGHT_FAILURE');receipt['failure_code']=failure
    save(output/'count_receipt.json',receipt)
    print(json.dumps({'preflight_passed':receipt['preflight_passed'],'failure_code':failure,
        'generation_calls':receipt['generation_calls'],'reservation_calls':receipt['reservation_calls'],
        'native_counter_calls':receipt['native_counter_calls'],'receipt_sha256':sha(output/'count_receipt.json')}),flush=True)
    upload_artifacts(args)
    return 0 if receipt['preflight_passed'] else 1


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--runtime-lock',required=True);parser.add_argument('--manifest-sha',required=True)
    parser.add_argument('--allocated-job-id',required=True);parser.add_argument('--project',default='motomedic-ai-20261009')
    parser.add_argument('--output',required=True);parser.add_argument('--artifact-uri',required=True)
    parser.add_argument('--client-input-inventory',required=True)
    parser.add_argument('--model-metadata',action='store_true')
    try:sys.exit(main(parser.parse_args()))
    except Exception:
        print(json.dumps({'failure_code':'COUNT_PREFLIGHT_ARTIFACT_OR_BOOTSTRAP_FAILURE','generation_calls':0}),flush=True)
        sys.exit(1)
