"""Check documented count shapes on a lightweight hosted runner; no generation."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import probe_flash_lite_access_v1 as probe
import json
probe.NAME='flash_lite_access_probe_v2'
probe.CODE='''import json,os,urllib.request,urllib.error
key=os.environ.get('MOTOMEDIC_GEMINI_API_KEY')
result={'schema':'motomedic-hosted-flash-lite-access-v1','model':'gemini-2.5-flash-lite','generation_calls':0,'provider_reservations':0,'credentials_logged':False}
if not key:raise SystemExit('PROVIDER_UNCONFIGURED')
base='https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite'
contents=[{'role':'user','parts':[{'text':'Hosted model-access check.'}]}]
requests={'metadata':(base,None),'count':(base+':countTokens',{'generateContentRequest':{'model':'models/gemini-2.5-flash-lite','contents':contents}}),'contents_count':(base+':countTokens',{'contents':contents})}
for kind,(url,body) in requests.items():
 request=urllib.request.Request(url,data=None if body is None else json.dumps(body).encode(),headers={'x-goog-api-key':key,'Content-Type':'application/json'},method='GET' if body is None else 'POST')
 try:
  with urllib.request.urlopen(request,timeout=25) as response:value=json.load(response)
  result[kind]={'status':'SUCCESS',**({name:value.get(name) for name in ('name','version','inputTokenLimit','outputTokenLimit','supportedGenerationMethods')} if kind=='metadata' else {'totalTokens':value.get('totalTokens')})}
 except urllib.error.HTTPError as error:
  item={'status':'HTTP_'+str(error.code)}
  try:
   payload=json.loads(error.read(65536)).get('error',{});message=payload.get('message','').lower();status=payload.get('status')
   if status in ('NOT_FOUND','PERMISSION_DENIED','FAILED_PRECONDITION','INVALID_ARGUMENT','RESOURCE_EXHAUSTED','UNAUTHENTICATED'):item['google_error_status']=status
   item['mentions_previous_use_requirement']=any(phrase in message for phrase in ('previously','previous use','new users','new projects','actively used'))
   item['mentions_model_not_found']=any(phrase in message for phrase in ('not found','not available','not supported','not allowed'))
  except Exception:pass
  result[kind]=item
 except Exception:result[kind]={'status':'TRANSPORT_OR_SCHEMA_FAILURE'}
print(json.dumps(result,sort_keys=True))
if result['metadata']['status']!='SUCCESS' or result['count']['status']!='SUCCESS':raise SystemExit(1)
'''

def submit():
 path=probe.cloud.OUT/(probe.NAME+'_submission.json')
 if path.exists():raise RuntimeError('PROBE_ALREADY_SUBMITTED_USE_POLL')
 config={'serviceAccount':'projects/'+probe.cloud.PROJECT+'/serviceAccounts/motomedic-arm-a@'+probe.cloud.PROJECT+'.iam.gserviceaccount.com',
  'steps':[{'name':'docker.io/library/python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1','entrypoint':'python','args':['-B','-c',probe.CODE], 'secretEnv':['MOTOMEDIC_GEMINI_API_KEY']}],
  'availableSecrets':{'secretManager':[{'versionName':'projects/'+probe.cloud.PROJECT+'/secrets/motomedic-gemini-serving-v1/versions/1','env':'MOTOMEDIC_GEMINI_API_KEY'}]},
  'options':{'logging':'CLOUD_LOGGING_ONLY'},'timeout':'300s'}
 op=probe.cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+probe.cloud.PROJECT+'/builds',config)
 probe.cloud.dump(path.name,{'config':config,'operation':op,'generation_calls':0,'billing_changes':0})
 print(json.dumps({'id':op['metadata']['build']['id'],'status':op['metadata']['build']['status'],'generation_calls':0}))
if __name__=='__main__':{'submit':submit,'poll':probe.poll,'result':probe.result}[sys.argv[1]]()
