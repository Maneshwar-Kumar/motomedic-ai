"""Synthetic protocol/IAM tests; no credential reads, network or providers."""
import copy
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

BASE = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


console = module('console_v10_11_test', BASE / 'private_acceptance_console_v10_11.py')
client = module('hosted_client_v10_11_test', BASE / 'public_evaluator/hosted_client_v10_11.py')
evaluator = console.evaluator


class RoutingReadinessTests(unittest.TestCase):
    def check(self, mutation=None):
        from cloud.grounded_generation.role_router import ROUTING_CONTRACT
        body = {'ready': True, 'runtime_lock': 'b'*64,
            'answer_provider': 'gemini-2.5-flash-lite', 'verifier_provider': 'claude-haiku-5-5',
            'prompt_cache': 'ANTHROPIC_ROLE_EVIDENCE_PREFIX_5M',
            'model_routing': copy.deepcopy(ROUTING_CONTRACT),
            'manual_checksum': 'cf221a29e2f9cd5af6e80a99774a697c814e8eda661c27d72e519d8a7e80da89',
            'index_id': 'index_a3282c4d98cf54595e4ba168',
            'architecture': 'DRAFT_VERIFY_STREAM_OPEN_MANUAL_QA',
            'streaming': 'DRAFT_VERIFY_STREAM', 'durable_dispatch_configured': True,
            'reranking': 'authenticated-open-hybrid-rank-disagreement-v5'}
        binding = {'serving_manifest_sha256': 'a'*64,
            'images': {'backend': 'synthetic-bound-backend', 'ui': 'synthetic-bound-ui'}}
        saved = {'runtime_lock': 'b'*64, 'versions': {'model_routing_contract': copy.deepcopy(ROUTING_CONTRACT)}}
        if mutation == 'manifest': binding['serving_manifest_sha256'] = 'c'*64
        elif mutation == 'saved_routing': saved['versions']['model_routing_contract']['routing_threshold_tokens'] += 1
        elif mutation == 'health_routing': body['model_routing']['availability_fallback_enabled'] = True
        elif mutation == 'cache': body['prompt_cache'] = 'ANTHROPIC_VERIFIER_EVIDENCE_PREFIX_5M'
        elif mutation == 'manual': body['manual_checksum'] = 'c'*64
        elif mutation == 'dispatch': body['durable_dispatch_configured'] = False
        def read(name):
            return saved if name.startswith('expected_runtime_lock') else binding
        def api(method, path):
            ui = path.endswith('motomedic-rider-ui')
            return {'terminalCondition': {'state': 'CONDITION_SUCCEEDED'},
                'template': {'containers': [{'image': binding['images']['ui' if ui else 'backend']}]},
                'uri': 'https://synthetic.run.app', 'latestReadyRevision': 'synthetic-private-revision'}
        opener = MagicMock()
        response = opener.open.return_value.__enter__.return_value
        response.status = 200
        response.read.return_value = json.dumps(body).encode()
        with patch.object(console, 'release', return_value='a'*64), \
                patch.object(Path, 'exists', return_value=True), \
                patch.object(console, 'read', side_effect=read), \
                patch.object(console, 'sdk_identity', return_value='synthetic-not-a-token') as sdk, \
                patch.object(console.run, 'api', side_effect=api), \
                patch.object(console.cloud, 'build_opener', return_value=opener), \
                patch.object(console.cloud, 'dump') as dump:
            if mutation:
                with self.assertRaises(ValueError): console.readiness()
                dump.assert_not_called()
                if mutation in ('manifest', 'saved_routing'): sdk.assert_not_called()
            else:
                console.readiness()
                receipt = dump.call_args.args[1]
                self.assertEqual(receipt['provider_calls'], 0)
                self.assertFalse(receipt['public_iam_changed'])
                self.assertEqual(len(receipt['services']), 3)
    def test_exact_saved_routing_contract_source_and_all_private_images_pass(self):
        self.check()
    def test_model_source_cache_dispatch_or_manifest_drift_cannot_claim_readiness(self):
        for mutation in ('manifest','saved_routing','health_routing','cache','manual','dispatch'):
            with self.subTest(mutation=mutation): self.check(mutation)


class SourceGrantTests(unittest.TestCase):
    def values(self):
        prior = {'source': {'object': 'serving/engineering-clients/v10_8/' + 'a' * 64 + '.tar.gz'}}
        source = {'object': 'serving/engineering-clients/v10_11/' + 'b' * 64 + '.tar.gz',
            'sha256': 'b' * 64, 'generation': '123', 'service_account': console.run.BACKEND_SA,
            'artifact_prefix': 'engineering-acceptance/public-v10_3/'}
        old = {'role': console.GET_ROLE, 'members': [console.MEMBER], 'condition': {
            'title': 'motomedic-backend-exact-evaluator-client-v10-10-v7',
            'expression': "resource.name == 'projects/_/buckets/" + console.cloud.BUCKET +
                '/objects/' + prior['source']['object'] + "'"}}
        unrelated = {'role': 'synthetic-role', 'members': ['synthetic-member'],
            'condition': {'expression': 'synthetic unchanged create prefix'}}
        return {'version': 3, 'etag': 'synthetic-etag', 'bindings': [old, unrelated]}, prior, source

    def test_exact_replacement_preserves_every_unrelated_row_and_input(self):
        policy, prior, source = self.values()
        original = copy.deepcopy(policy)
        updated, removed, added = console.source_policy_replacement(policy, prior, source)
        self.assertEqual(policy, original)
        self.assertEqual(updated['etag'], original['etag'])
        self.assertEqual(updated['bindings'][0], original['bindings'][1])
        self.assertNotIn(removed, updated['bindings'])
        self.assertEqual(added['members'], [console.MEMBER])
        self.assertIn(source['object'], added['condition']['expression'])

    def test_missing_etag_or_ambiguous_old_binding_fails(self):
        for mutation in ('etag', 'duplicate', 'additional_member', 'missing'):
            policy, prior, source = self.values()
            if mutation == 'etag': policy.pop('etag')
            elif mutation == 'duplicate': policy['bindings'].append(copy.deepcopy(policy['bindings'][0]))
            elif mutation == 'additional_member': policy['bindings'][0]['members'].append('another-member')
            else: policy['bindings'].pop(0)
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                console.source_policy_replacement(policy, prior, source)

    def test_wrong_source_prefix_hash_generation_principal_or_output_prefix_fails(self):
        for key, wrong in [('object', 'serving/engineering-clients/v10_8/' + 'b' * 64 + '.tar.gz'),
                ('sha256', 'c' * 64), ('generation', 'unknown'), ('service_account', 'other'),
                ('artifact_prefix', 'arbitrary-prefix/')]:
            policy, prior, source = self.values(); source[key] = wrong
            with self.subTest(key=key), self.assertRaises(ValueError):
                console.source_policy_replacement(policy, prior, source)


class SDKIsolationTests(unittest.TestCase):
    def test_sdk_clears_only_pythonpath_and_retains_existing_configuration(self):
        result = SimpleNamespace(returncode=0, stdout='synthetic-access-identity', stderr='')
        with patch.dict(console.os.environ, {'PYTHONPATH': 'synthetic-ui-deps',
                'CLOUDSDK_PYTHON': 'synthetic-sdk-python', 'CLOUDSDK_CONFIG': 'synthetic-existing-config'}), \
                patch.object(console.subprocess, 'run', return_value=result) as run:
            self.assertEqual(console.sdk_identity('print-access-token'), 'synthetic-access-identity')
        environment = run.call_args.kwargs['env']
        self.assertNotIn('PYTHONPATH', environment)
        self.assertEqual(environment['CLOUDSDK_PYTHON'], 'synthetic-sdk-python')
        self.assertEqual(environment['CLOUDSDK_CONFIG'], 'synthetic-existing-config')

    def test_sdk_failures_expose_only_static_error_category(self):
        for error, category in [('invalid_grant synthetic-private-detail', 'CredentialRefreshError'),
                ('PERMISSION_DENIED synthetic-private-detail', 'ApiPermissionError'),
                ('ModuleNotFoundError synthetic-private-detail', 'SDKDependencyError')]:
            with patch.object(console.subprocess, 'run', return_value=SimpleNamespace(
                    returncode=1, stdout='', stderr=error)), self.assertRaises(console.SDKCommandFailure) as raised:
                console.sdk_identity('print-access-token')
            self.assertEqual(raised.exception.sdk_error_category, category)
            self.assertNotIn('synthetic-private-detail', str(raised.exception))


class CountRecipeTests(unittest.TestCase):
    def values(self):
        source = {'serving_manifest_sha256': 'a' * 64, 'runtime_lock': 'b' * 64,
            'files': {'tmp/public_evaluator/count_only_context_v10_11.py': 'c' * 64},
            'service_account': console.run.BACKEND_SA,
            'object': 'serving/engineering-clients/v10_11/' + 'd' * 64 + '.tar.gz', 'generation': '123'}
        binding = {'serving_manifest_sha256': 'a' * 64, 'runtime_revision': 'v10_11',
            'images': {'backend': 'us-central1-docker.pkg.dev/' + console.cloud.PROJECT +
                '/motomedic/arm-a@sha256:' + 'e' * 64}}
        source['count_backend_image'] = binding['images']['backend']
        return source, binding

    def test_count_recipe_uses_bound_backend_and_only_hosted_native_counter_keys(self):
        source, binding = self.values(); config = evaluator.count_config(source, binding)
        self.assertEqual(config['timeout'], '1200s')
        self.assertEqual(config['options']['machineType'], 'E2_HIGHCPU_8')
        step = config['steps'][1]
        self.assertEqual(step['name'], binding['images']['backend'])
        self.assertEqual(step['secretEnv'], ['MOTOMEDIC_GEMINI_API_KEY', 'ANTHROPIC_API_KEY'])
        self.assertNotIn('MOTOMEDIC_VISITOR_SECRET', step['secretEnv'])
        self.assertIn('MOTOMEDIC_CLAUDE_FALLBACK_ENABLED=false', step['env'])
        self.assertIn('MOTOMEDIC_HOSTED_COUNT_ONLY=true', step['env'])
        self.assertEqual(config['source']['storageSource']['generation'], '123')
        self.assertIn('tmp/public_evaluator/count_only_context_v10_11.py', step['args'])
        self.assertIn('--model-metadata',step['args'])
        self.assertIn('tmp/public_evaluator/client_inputs_v10_11.json',step['args'])
        self.assertIn('gs://' + console.cloud.BUCKET + '/engineering-acceptance/public-v10_3/$BUILD_ID', step['args'])

    def test_missing_script_or_mismatched_image_release_fails_before_submission(self):
        for mutation in ('script', 'sha', 'revision', 'image'):
            source, binding = self.values()
            if mutation == 'script': source['files'] = {}
            elif mutation == 'sha': binding['serving_manifest_sha256'] = 'f' * 64
            elif mutation == 'revision': binding['runtime_revision'] = 'v10_4'
            else: binding['images']['backend'] = 'synthetic-unbound-image'
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                evaluator.count_config(source, binding)


class CountReceiptGateTests(unittest.TestCase):
    def values(self):
        from cloud.grounded_generation.role_router import ROUTING_CONTRACT
        from phase_budget_v10_11 import digest,OWNER_SCOPE_SHA,NATIVE_STAGES
        source = {'serving_manifest_sha256': 'a' * 64, 'runtime_lock': 'b' * 64,
            'model_routing_contract_sha256': digest(ROUTING_CONTRACT),
            'files': {'tmp/public_evaluator/count_only_context_v10_11.py': 'c' * 64,
                'tmp/public_evaluator/count_history_v1.json': 'd' * 64}}
        cases = []
        for index in range(6):
            route = 'HAIKU_DRAFT_GEMMA_VERIFY' if index % 2 else 'GEMMA_DRAFT_HAIKU_VERIFY'
            pair = ROUTING_CONTRACT['roles'][route]
            chosen_count = 10000 if index % 2 else 4200
            role = {'version': ROUTING_CONTRACT['version'], 'route': route,
                'routing_contract_sha256': digest(ROUTING_CONTRACT),
                'gemma_routing_input_tokens': 12000 if index % 2 else 4200,
                'selected_draft_input_tokens': chosen_count,
                'initial_draft_request_sha256': 'a'*64, 'stable_context_sha256': 'b'*64,
                'draft_model_contract_sha256': digest(pair['draft']),
                'verifier_contract_sha256': digest(pair['verifier'])}
            def slots(stages):
                values=[]
                for stage, provider in ((stages[0],pair['draft']),(stages[1],pair['verifier'])):
                    count = (chosen_count + (512 if provider['provider'] == 'anthropic' else 0) if stage == 'draft' else
                        16000 if provider['provider'] == 'google-generative-language' else
                        70000 if stage == 'correction' else 52000)
                    for attempt in range(1,provider['maximum_attempts_per_call']+1):
                        row={'model':provider['model'],'stage':stage,'input_tokens':count,
                            'output_tokens':1800,'attempt':attempt}
                        if provider['provider'] == 'anthropic':
                            row['maximum_nanodollars'] = count*125 + 900000
                        values.append(row)
                return values
            cases.append({'case_id':'synthetic'+str(index),'question_sha256':digest('synthetic question '+str(index)),
                'role_plan':role,'initial_phase_slots':slots(('draft','verify')),
                'conditional_correction_phase_slots':slots(('correction','reverify')),
                'native_stages':[{'stage':stage,
                    'model':('gemini-2.5-flash-lite' if position==0 else pair['draft']['model'] if position in(1,4) else pair['verifier']['model']),
                    'role':('private_draft' if position in(0,1,4) else 'semantic_verifier'),
                    'input_tokens_counted':role['gemma_routing_input_tokens'] if position==0 else chosen_count if position==1 else 1000,
                    'counter_body_sha256':'f'*64,'counter_request_bytes':1000} for position,stage in enumerate(NATIVE_STAGES)],
                'synthetic_gemma_verifier_stress_actual_quota_eligible':False})
        receipt = {'schema':'motomedic-hosted-native-count-role-preflight-v2',
            'classification': 'HOSTED_NATIVE_COUNTERS_AND_ROLE_FORECAST_ONLY',
            'cloud_build_id':'11111111-2222-4333-8444-555555555555',
            'owner_model_scope_sha256':OWNER_SCOPE_SHA,'model_routing_contract_sha256':digest(ROUTING_CONTRACT),
            'serving_manifest_sha256': 'a' * 64, 'runtime_lock': 'b' * 64,
            'script_sha256': 'c' * 64, 'history_sha256': 'd' * 64,
            'preflight_passed': True,'selected_draft_native_window_eligible':True,
            'selected_draft_actual_quota_eligible':True,'known_verifier_fixed_quota_eligible':True,
            'verifier_synthetic_stress_native_window_eligible':True,
            'actual_finalized_verifier_count_demonstrated':False,
            'future_finalized_verifier_quota_status':'UNKNOWN_MANDATORY_ACTUAL_FINAL_COUNT',
            'generation_calls': 0, 'reservation_calls': 0,'planned_native_counter_calls':42,'native_counter_calls': 42,
            'case_count': 6, 'provider_allocation_delta_zero': True,
            'declared_native_stage_order':list(NATIVE_STAGES),
            'transport_allowlist_enforced': True, 'counter_transport_calls': 42, 'prohibited_transport_calls': 0,
            'model_metadata_transport_calls':1,'gemma_native_metadata':{'name':'models/gemini-2.5-flash-lite',
                'inputTokenLimit':262144,'outputTokenLimit':8192},
            'cases':cases,
            'ledger_before': {'synthetic_attempts': 24}, 'ledger_after': {'synthetic_attempts': 24}}
        return source, receipt

    def test_exact_roles_zero_allocation_and_honest_unknown_final_gate_pass(self):
        source, receipt = self.values()
        console.validate_count_receipt(receipt, source)

    def test_failed_counts_partial_cases_wrong_release_or_paid_reservation_cannot_open_gate(self):
        for key, wrong in [('classification', 'SYNTHETIC'), ('serving_manifest_sha256', 'f' * 64),
                ('runtime_lock', 'f' * 64), ('script_sha256', 'f' * 64), ('history_sha256', 'f' * 64),
                ('owner_model_scope_sha256','f'*64),('model_routing_contract_sha256','f'*64),
                ('preflight_passed', False), ('selected_draft_native_window_eligible', False),
                ('selected_draft_actual_quota_eligible',False),('known_verifier_fixed_quota_eligible',False),
                ('verifier_synthetic_stress_native_window_eligible', False), ('generation_calls', 1),
                ('actual_finalized_verifier_count_demonstrated',True),
                ('future_finalized_verifier_quota_status','ACTUAL_VERIFIER_FITS'),
                ('generation_calls', False), ('reservation_calls', 1), ('native_counter_calls', 29),
                ('case_count', 5), ('provider_allocation_delta_zero', False),
                ('transport_allowlist_enforced', False), ('counter_transport_calls', 29), ('prohibited_transport_calls', 1),
                ('ledger_after', {'synthetic_attempts': 32})]:
            source, receipt = self.values(); receipt[key] = wrong
            with self.subTest(key=key, wrong=wrong), self.assertRaises(ValueError):
                console.validate_count_receipt(receipt, source)


class ClientProtocolTests(unittest.TestCase):
    def test_stop_gate_avoids_later_paid_cases_and_preserves_old_default(self):
        self.assertIsNone(client.stop_reason({'route': 'SYSTEM_ERROR'}, 1, False))
        self.assertEqual(client.stop_reason({'route': 'SYSTEM_ERROR'}, 1, True),
            'SYSTEM_ERROR_OR_OPERATIONAL_FAILURE')
        self.assertEqual(client.stop_reason({'error': 'TRANSPORT_UNCERTAIN'}, 1, True),
            'SYSTEM_ERROR_OR_OPERATIONAL_FAILURE')
        self.assertEqual(client.stop_reason({'route': 'UNSUPPORTED', 'expected_route_matched': False}, 1, True),
            'FIRST_CANDIDATE_PROBE_NOT_ACCEPTED')
        self.assertIsNone(client.stop_reason({'route': 'SUPPORTED', 'expected_route_matched': True}, 1, True))

    def boundary(self, changed=False, wrong_error=None, expose=False):
        backend = MagicMock(); view = {'synthetic_exact_saved_view': True}
        backend.request.return_value = view
        other = MagicMock()
        if not expose:
            other.request.side_effect = client.EvaluationFailure(wrong_error or 'OPERATION_NOT_FOUND_404')
        args = SimpleNamespace(project='synthetic', backend='https://synthetic.run.app')
        amounts = [{'attempts': 8}, {'attempts': 16 if changed else 8}]
        with patch.object(client, 'ledger', side_effect=amounts), patch.object(client, 'Backend', return_value=other), \
                patch('rider_ui.client.validate_view', side_effect=lambda value, **kwargs: value), \
                patch('rider_ui.identity.issue', return_value='synthetic-other-visitor'):
            result = client.completed_boundaries(backend, args, 'synthetic-not-a-key',
                '/v1/sessions', {'synthetic_original_request': True}, 'a' * 32, view)
        backend.request.assert_called_once_with('POST', '/v1/sessions',
            body={'synthetic_original_request': True}, operation='a' * 32)
        other.request.assert_called_once_with('GET', '/v1/operations/' + 'a' * 32)
        return result

    def test_complete_duplicate_and_valid_wrong_visitor_require_unchanged_ledger(self):
        self.assertEqual(self.boundary()['provider_calls'], 0)

    def test_boundary_cannot_claim_zero_paid_calls_if_ledger_changed(self):
        with self.assertRaisesRegex(client.EvaluationFailure, 'CHANGED_PROVIDER_RESERVATIONS'):
            self.boundary(changed=True)

    def test_invalid_visitor_auth_or_disclosed_operation_is_not_ownership_proof(self):
        with self.assertRaisesRegex(client.EvaluationFailure, 'NOT_OWNERSHIP_REJECTED'):
            self.boundary(wrong_error='VISITOR_CAPABILITY_REQUIRED_401')
        with self.assertRaisesRegex(client.EvaluationFailure, 'OPERATION_DISCLOSED'):
            self.boundary(expose=True)


class MeasuredCapacityTests(unittest.TestCase):
    def values(self):
        from cloud.grounded_generation.role_router import ROUTING_CONTRACT
        from phase_budget_v10_11 import make_budget
        source,receipt=CountReceiptGateTests().values()
        budget=make_budget(receipt,source,'e'*64,ROUTING_CONTRACT)
        inventory={'serving_manifest_sha256':source['serving_manifest_sha256'],
            'model_routing_contract_sha256':source['model_routing_contract_sha256'],
            'model_routing_contract':ROUTING_CONTRACT}
        plan={'cases':[{'case_id':'synthetic'+str(i),'question':'synthetic question '+str(i)} for i in range(6)]}
        ledgers={'grounded-primary-nonrecurring-v1':{'version':'whole-turn-capacity-v1',
            'maximum_attempts':100,'maximum_tokens':999200,'reserved_attempts':24,'reserved_tokens':239808},
            'owner-haiku-fallback-20261011-validation-v1':{'version':'claude-fallback-nonrecurring-one-dollar-v1',
                'maximum_nanodollars':1000000000,'reserved_nanodollars':11544000}}
        return budget,inventory,plan,ledgers,receipt,source

    def test_measured_initial_conditional_and_three_turn_floor_use_retained_charges(self):
        from phase_budget_v10_11 import validate_budget,capacity_check
        budget,inventory,plan,ledgers,*_=self.values()
        validate_budget(budget,inventory,'b'*64,plan)
        before=copy.deepcopy(ledgers)
        result=capacity_check(budget,0,ledgers)
        self.assertTrue(result['eligible'])
        self.assertEqual(result['remaining_planned_initial']['attempts'],18)
        self.assertEqual(result['current_conditional_correction']['attempts'],3)
        self.assertEqual(result['public_human_measured_floor']['attempts'],9)
        self.assertEqual(result['required']['attempts'],30)
        self.assertEqual(result['baseline_retained_charges']['tokens'],239808)
        self.assertEqual(ledgers,before)
        self.assertFalse(result['arbitrary_future_question_affordability_guaranteed'])

    def test_any_attempt_token_or_monetary_shortfall_stops_without_mutation(self):
        from phase_budget_v10_11 import capacity_check
        for guard,key,value in [('grounded-primary-nonrecurring-v1','reserved_attempts',90),
                ('grounded-primary-nonrecurring-v1','reserved_tokens',400000),
                ('owner-haiku-fallback-20261011-validation-v1','reserved_nanodollars',990000000)]:
            budget,_,_,ledgers,*_=self.values();ledgers[guard][key]=value
            before=copy.deepcopy(ledgers)
            with self.subTest(guard=guard,key=key):
                self.assertFalse(capacity_check(budget,0,ledgers)['eligible'])
                self.assertEqual(ledgers,before)

    def test_later_case_rechecks_live_charges_and_remaining_initial_phases(self):
        from phase_budget_v10_11 import capacity_check
        budget,_,_,ledgers,*_=self.values()
        first=capacity_check(budget,0,ledgers)
        charged=budget['case_forecasts'][0]['initial_totals']
        ledgers['grounded-primary-nonrecurring-v1']['reserved_attempts']+=charged['attempts']
        ledgers['grounded-primary-nonrecurring-v1']['reserved_tokens']+=charged['tokens']
        ledgers['owner-haiku-fallback-20261011-validation-v1']['reserved_nanodollars']+=charged['haiku_nanodollars']
        next_case=capacity_check(budget,1,ledgers)
        self.assertTrue(next_case['eligible'])
        self.assertEqual(next_case['remaining_planned_initial']['attempts'],15)
        self.assertLess(next_case['available']['tokens'],first['available']['tokens'])
        self.assertEqual(next_case['baseline_retained_charges']['tokens'],239808+charged['tokens'])

    def test_changed_plan_scope_totals_or_public_human_floor_fails_binding(self):
        from phase_budget_v10_11 import validate_budget
        for mutation in ('question','scope','floor','total','role','future_guarantee'):
            budget,inventory,plan,*_=self.values()
            if mutation=='question':plan['cases'][0]['question']='a different synthetic question'
            elif mutation=='scope':budget['owner_model_scope_sha256']='f'*64
            elif mutation=='floor':budget['retained_floor']['turns']=2
            elif mutation=='total':budget['case_forecasts'][0]['initial_totals']['tokens']-=1
            elif mutation=='role':budget['case_forecasts'][0]['role_plan']['route']='HAIKU_DRAFT_GEMMA_VERIFY'
            else:budget['actual_finalized_verifier_count_demonstrated']=True
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):
                validate_budget(budget,inventory,'b'*64,plan)

    def test_inexact_cost_real_gemma_quota_or_conditional_stage_cannot_authorize_forecast(self):
        from cloud.grounded_generation.role_router import ROUTING_CONTRACT
        from phase_budget_v10_11 import make_budget
        for mutation in ('cost','gemma_quota','stage','bool_tokens','extra_slot'):
            _,_,_,_,receipt,source=self.values()
            slots=receipt['cases'][0]['conditional_correction_phase_slots']
            if mutation=='cost':slots[-1]['maximum_nanodollars']-=1
            elif mutation=='gemma_quota':slots[0]['input_tokens']=16001
            elif mutation=='stage':slots[0]['stage']='draft'
            elif mutation=='bool_tokens':slots[0]['input_tokens']=True
            else:slots.append(copy.deepcopy(slots[0]))
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):
                make_budget(receipt,source,'e'*64,ROUTING_CONTRACT)

    def test_native_long_context_cache_write_cost_uses_bound_tier(self):
        from cloud.grounded_generation.role_router import ROUTING_CONTRACT
        from phase_budget_v10_11 import phase_totals
        _,_,_,_,receipt,_=self.values()
        row=receipt['cases'][0];slot=row['initial_phase_slots'][-1]
        slot['input_tokens']=110000;slot['maximum_nanodollars']=73250000
        totals=phase_totals(row['initial_phase_slots'],ROUTING_CONTRACT,row['role_plan'],('draft','verify'))
        self.assertEqual(totals['haiku_nanodollars'],73250000)

    def test_permanent_limits_cannot_be_raised_or_boolean_charges_accepted(self):
        from phase_budget_v10_11 import capacity_check
        for key,value in [('maximum_attempts',101),('maximum_tokens',1000000),('reserved_attempts',False)]:
            budget,_,_,ledgers,*_=self.values()
            ledgers['grounded-primary-nonrecurring-v1'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):capacity_check(budget,0,ledgers)

    def test_native_stage_model_order_body_and_metadata_drift_cannot_authorize_paid_job(self):
        from cloud.grounded_generation.role_router import ROUTING_CONTRACT
        from phase_budget_v10_11 import make_budget
        for mutation in ('order','model','role','body','count','native_window','metadata_bool'):
            _,_,_,_,receipt,source=self.values()
            stage=receipt['cases'][0]['native_stages'][1]
            if mutation=='order':receipt['cases'][0]['native_stages'].reverse()
            elif mutation=='model':stage['model']='another-model'
            elif mutation=='role':stage['role']='semantic_verifier'
            elif mutation=='body':stage['counter_body_sha256']='missing'
            elif mutation=='count':stage['input_tokens_counted']+=1
            elif mutation=='native_window':receipt['gemma_native_metadata']['inputTokenLimit']=255999
            else:receipt['gemma_native_metadata']['outputTokenLimit']=True
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):
                make_budget(receipt,source,'e'*64,ROUTING_CONTRACT)


if __name__ == '__main__':
    unittest.main()
