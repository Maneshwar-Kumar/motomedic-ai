import os,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import submit_hosted_v10 as cloud
bundle=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node'
env=os.environ.copy();env['NODE_PATH']=str(bundle/'node_modules')
args=[str(bundle/'bin/node.exe'),'tmp/public_evaluator/browser_acceptance_v11.cjs','--execute-authorized',
    '--url','https://motomedic-rider-ui-279945185781.us-central1.run.app',
    '--release-sha','CURRENT_V10_11_MANIFEST_SHA']
mode=sys.argv[1]
if mode=='private-shell':
    sdk_env=os.environ.copy();sdk_env.pop('PYTHONPATH',None)
    env['MOTOMEDIC_PRIVATE_TEST_ID_TOKEN']=subprocess.run([str(cloud.CLI),'auth','print-identity-token',
        '--account=maneshwarkumar@gmail.com','--quiet'],capture_output=True,text=True,check=True,env=sdk_env,timeout=45).stdout.strip()
    args+=['--shell-only','--output','tmp/public_evaluator/private-shell-output-v10_11']
elif mode=='public-shell':args+=['--shell-only','--output','tmp/public_evaluator/public-shell-output-v10_11']
elif mode=='public-answer':args+=['--output','tmp/public_evaluator/public-answer-output-v10_11']
else:raise ValueError('EXACT_BROWSER_MODE_REQUIRED')
result=subprocess.run(args,env=env)
sys.exit(result.returncode)
