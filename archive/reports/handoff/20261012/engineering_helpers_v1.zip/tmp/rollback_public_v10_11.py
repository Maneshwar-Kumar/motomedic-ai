"""Exact v10.11 rollback rehearsal and separately gated UI-only public opening.

Importing this module performs no cloud action. Private consoles may import only
the six rollback functions. No provider call, secret read, billing action or
allocation write is available. Every operation uses saved, exact release inputs.
"""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.error import HTTPError

sys.path.insert(0, str(Path(__file__).resolve().parent))
import public_cloud_run_v10_11 as run

cloud = run.cloud
VERSION = 'v10_11'
LABEL_KEY = 'motomedic-rollback-exercise'
LABEL = 'v10-11-compatible-canary'
SCHEMA = 'motomedic-compatible-rollback-v1'
SEMANTIC_SCHEMA = 'motomedic-six-case-semantic-acceptance-v1'
TASK_SA = 'motomedic-answer-tasks@' + cloud.PROJECT + '.iam.gserviceaccount.com'
QDRANT = 'motomedic-qdrant'
PROJECT_NUMBER = '279945185781'
CORE = ('motomedic-arm-a', 'motomedic-answer-worker', QDRANT)
OPS = 'operations/'
HEX64 = re.compile(r'[0-9a-f]{64}')
BUILD_ID = re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')
PLAN = 'original_page_evaluator_plan_v2.json'
PLAN_SHA = 'a7dc784be633c14accdff256e57abb784a486076da07b149c6f2e04096ee5541'
PUBLIC_MEMBERS = {'allUsers', 'allAuthenticatedUsers'}


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=False).encode()).hexdigest()


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((cloud.OUT / name).read_bytes())


def receipt(stage):
    return OPS + 'rollback_' + VERSION + '_' + stage + '.json'


def dump(name, value):
    target = cloud.OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x', encoding='utf-8') as output:
        output.write(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def require_absent(*names):
    if any((cloud.OUT / name).exists() for name in names):
        raise ValueError('NEVER_OVERWRITE_OPERATIONAL_RECEIPT')


def release():
    """Only immutable saved bindings can establish the intended current release."""
    manifest_path = cloud.OUT / ('serving_manifest_' + VERSION + '.json')
    manifest_sha = file_hash(manifest_path)
    if (cloud.OUT / ('serving_manifest_' + VERSION + '.sha256')).read_text().split()[0] != manifest_sha:
        raise ValueError('CURRENT_MANIFEST_SIDECAR_CHANGED')
    manifest = json.loads(manifest_path.read_bytes())
    snapshot = manifest.get('index', {}).get('snapshot', {})
    if (not re.fullmatch(r'[0-9]+', str(snapshot.get('generation') or '')) or
            not HEX64.fullmatch(snapshot.get('sha256', ''))):
        raise ValueError('IMMUTABLE_INDEX_REFERENCE_REQUIRED')
    binding = read('hosted_image_binding_' + VERSION + '.json')
    saved_lock = read('expected_runtime_lock_' + VERSION + '.json')
    lock = saved_lock['runtime_lock']
    from cloud.grounded_generation.role_router import ROUTING_CONTRACT
    if saved_lock['versions'].get('model_routing_contract') != ROUTING_CONTRACT:
        raise ValueError('FROZEN_MODEL_ROUTING_CONTRACT_CHANGED')
    if (binding.get('schema_version') != 'motomedic-serving-v10-build-binding-v1' or
            binding.get('runtime_revision') != VERSION or
            binding.get('serving_manifest_sha256') != manifest_sha or
            not HEX64.fullmatch(lock)):
        raise ValueError('FROZEN_IMAGE_RUNTIME_BINDING_CHANGED')
    for kind, repo in (('backend', 'arm-a'), ('ui', 'rider-ui')):
        if not re.fullmatch('us-central1-docker\\.pkg\\.dev/' + re.escape(cloud.PROJECT) +
                '/motomedic/' + repo + '@sha256:[0-9a-f]{64}', binding['images'][kind]):
            raise ValueError('PINNED_HOSTED_IMAGE_REQUIRED')
    return {'serving_manifest_sha256': manifest_sha, 'runtime_lock': lock,
        'model_routing_contract': ROUTING_CONTRACT,
        'images': binding['images'], 'image_binding_sha256':
        file_hash(cloud.OUT / ('hosted_image_binding_' + VERSION + '.json'))}, manifest


def sdk_token(kind):
    environment = os.environ.copy()
    environment.pop('PYTHONPATH', None)
    try:
        result = subprocess.run([str(cloud.CLI), 'auth', kind,
            '--account=maneshwarkumar@gmail.com', '--quiet'], capture_output=True,
            text=True, env=environment, timeout=45)
    except subprocess.TimeoutExpired:
        raise RuntimeError('SDK_AUTHENTICATION_TIMEOUT') from None
    value = result.stdout.strip()
    if result.returncode or not value or any(character.isspace() for character in value):
        raise RuntimeError('SDK_AUTHENTICATION_UNAVAILABLE')
    return value


def identity_token():
    return sdk_token('print-identity-token')


def template_identity(template):
    value = deepcopy(template)
    value.pop('revision', None)
    return digest(value)


def routed_revision(service):
    statuses = service.get('trafficStatuses', [])
    if (len(statuses) != 1 or type(statuses[0].get('percent')) is not int or
            statuses[0]['percent'] != 100 or not statuses[0].get('revision')):
        raise ValueError('ONE_EXACT_READY_REVISION_REQUIRED')
    return statuses[0]['revision'].split('/')[-1]


def require_service(name, service, binding, identity=None):
    kind = 'ui' if name == 'motomedic-rider-ui' else 'backend'
    template = service['template']
    if (service.get('terminalCondition', {}).get('state') != 'CONDITION_SUCCEEDED' or
            service.get('reconciling') is True or service.get('invokerIamDisabled') is True or
            template['containers'][0]['image'] != binding['images'][kind] or
            template.get('serviceAccount') != (run.UI_SA if kind == 'ui' else run.BACKEND_SA)):
        raise ValueError('EXACT_CURRENT_PRIVATE_SERVICE_REQUIRED')
    if identity is not None and template_identity(template) != identity:
        raise ValueError('ROLLBACK_IMAGE_ENV_OR_CONFIGURATION_CHANGED')
    environment = {row['name']: row for row in template['containers'][0].get('env', [])}
    if len(environment) != len(template['containers'][0].get('env', [])):
        raise ValueError('DUPLICATE_ENVIRONMENT_NAME')
    required = ({'MOTOMEDIC_RIDER_AUTH': 'cloud_run', 'MOTOMEDIC_RIDER_ACCESS': 'public_gateway',
        'MOTOMEDIC_EDGE_POLICY': 'gcp-public-cloud-run-cookie-v2',
        'MOTOMEDIC_RIDER_API_URL': 'https://motomedic-arm-a-' + PROJECT_NUMBER + '.us-central1.run.app',
        'MOTOMEDIC_PUBLIC_HOST': 'motomedic-rider-ui-' + PROJECT_NUMBER + '.us-central1.run.app'} if kind == 'ui' else
        {'MOTOMEDIC_CLAUDE_FALLBACK_ENABLED': 'false', 'MOTOMEDIC_PUBLIC_NETWORK_REQUIRED': 'false',
         'MOTOMEDIC_TASK_SERVICE_ACCOUNT': TASK_SA, 'MOTOMEDIC_EDGE_SERVICE_ACCOUNT': run.UI_SA,
         'MOTOMEDIC_TASK_QUEUE': 'projects/' + cloud.PROJECT + '/locations/us-central1/queues/motomedic-verified-answers',
         'MOTOMEDIC_TASK_WORKER_URL': 'https://motomedic-answer-worker-' + PROJECT_NUMBER + '.us-central1.run.app/internal/operations/run'})
    if any(environment.get(key, {}).get('value') != value for key, value in required.items()):
        raise ValueError('CURRENT_AUTHENTICATION_OR_DISPATCH_CONFIGURATION_CHANGED')
    for key in (('MOTOMEDIC_VISITOR_SECRET',) if kind == 'ui' else
            ('MOTOMEDIC_VISITOR_SECRET', 'MOTOMEDIC_GEMINI_API_KEY', 'ANTHROPIC_API_KEY')):
        row = environment.get(key, {})
        reference = row.get('valueSource', {}).get('secretKeyRef', {})
        if 'value' in row or not reference.get('secret') or reference.get('version') != '1':
            raise ValueError('MANAGED_SECRET_REFERENCE_REQUIRED')


def private_policies(include_ui=False):
    result = {}
    for name in CORE + (('motomedic-rider-ui',) if include_ui else ()):
        service = run.api('GET', run.PREFIX + name)
        policy = run.api('GET', run.PREFIX + name + ':getIamPolicy?options.requestedPolicyVersion=3')
        if service.get('invokerIamDisabled') is True or any(
                PUBLIC_MEMBERS.intersection(row.get('members', [])) for row in policy.get('bindings', [])):
            raise ValueError('PRIVATE_SERVICE_PUBLIC_OR_IAM_CHECK_DISABLED')
        invokers = {member for row in policy.get('bindings', []) if row.get('role') == 'roles/run.invoker'
            for member in row.get('members', [])}
        expected = {'motomedic-arm-a': {'serviceAccount:' + run.UI_SA, 'serviceAccount:' + run.BACKEND_SA},
            'motomedic-answer-worker': {'serviceAccount:' + TASK_SA},
            QDRANT: {'serviceAccount:' + run.BACKEND_SA}}
        if name in expected and invokers != expected[name]:
            raise ValueError('EXACT_PRIVATE_SERVICE_INVOKER_IDENTITIES_REQUIRED')
        result[name] = policy
    return result


def get_health(name, service, binding, token=None, *, url=None):
    path = '/health' if name == 'motomedic-rider-ui' else '/v1/health'
    headers = {} if token is None else {'Authorization': 'Bearer ' + token}
    request = cloud.Request((url or service['uri']) + path, headers=headers)
    with cloud.build_opener(cloud.NoRedirect()).open(request, timeout=60) as response:
        body = json.loads(response.read(65536))
        if response.status != 200 or body.get('ready') is not True:
            raise ValueError('ACTUAL_ROUTED_HEALTH_NOT_READY')
    if name != 'motomedic-rider-ui':
        expected = {'runtime_lock': binding['runtime_lock'], 'answer_provider': 'gemini-2.5-flash-lite',
            'verifier_provider': 'claude-haiku-5-5', 'prompt_cache': 'ANTHROPIC_ROLE_EVIDENCE_PREFIX_5M',
            'model_routing': binding['model_routing_contract'],
            'architecture': 'DRAFT_VERIFY_STREAM_OPEN_MANUAL_QA', 'streaming': 'DRAFT_VERIFY_STREAM',
            'reranking': 'authenticated-open-hybrid-rank-disagreement-v5',
            'durable_dispatch_configured': True,
            'manual_checksum': 'cf221a29e2f9cd5af6e80a99774a697c814e8eda661c27d72e519d8a7e80da89',
            'index_id': 'index_a3282c4d98cf54595e4ba168'}
        if any(body.get(key) != value for key, value in expected.items()):
            raise ValueError('ACTUAL_ROUTED_RUNTIME_LOCK_OR_POLICY_CHANGED')
    return {'http_status': 200, 'health': body, 'provider_calls': 0}


def require_revision_configuration(actual, template):
    """Normalize only a server-assigned name for one originally unnamed container.

    Actual current10 readback showed name as the sole difference. An explicit
    name, another container or any other changed field still fails closed.
    """
    live=deepcopy(actual.get('containers'))
    declared=template.get('containers')
    normalized=False
    if type(live)is list and type(declared)is list and len(live)==len(declared)==1:
        if live[0].get('name')!=declared[0].get('name'):
            generated=live[0].get('name')
            if ('name' not in declared[0] and type(generated)is str and
                    re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',generated) and
                    not live[0].get('dependsOn') and not declared[0].get('dependsOn')):
                live[0].pop('name');normalized=True
    if (live!=declared or any(actual.get(key)!=template.get(key) for key in
            ('serviceAccount','timeout','maxInstanceRequestConcurrency'))):
        raise ValueError('ACTUAL_TRAFFIC_REVISION_CONFIGURATION_DIFFERS')
    return normalized

def candidate_revision(name):
    if name not in run.NAMES:
        raise ValueError('UNKNOWN_CURRENT_SERVICE')
    value=name+'-'+VERSION.replace('_','-')+'-canary'
    if len(value)>63 or not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',value):
        raise ValueError('EXACT_CANDIDATE_REVISION_NAME_REQUIRED')
    return value


def create():
    """Create compatible candidates while traffic stays on the current revision."""
    names = [receipt('initial'), receipt('candidate_operations'), receipt('candidates')]
    names += [receipt('candidate_' + name) for name in run.NAMES]
    require_absent(*names)
    binding, _ = release()
    policies = private_policies(include_ui=True)
    services = {}
    token = identity_token()
    for name in run.NAMES:
        service = run.api('GET', run.PREFIX + name)
        require_service(name, service, binding)
        revision = routed_revision(service)
        # A staged template must never masquerade as the currently served image.
        actual = run.api('GET', run.PREFIX + name + '/revisions/' + revision)
        normalized=require_revision_configuration(actual,service['template'])
        services[name] = {'service': service, 'revision': revision,
            'server_assigned_single_container_name_normalized':normalized,
            'template_sha256': template_identity(service['template']),
            'health': get_health(name, service, binding, token)}
    dump(receipt('initial'), {'schema': SCHEMA, 'recorded_at': now(), 'binding': binding,
        'services': services, 'private_policy_sha256': {name: digest(policy) for name, policy in policies.items()},
        'provider_calls': 0, 'public_iam_changed': False})
    operations = {}
    for name, row in services.items():
        template = deepcopy(row['service']['template'])
        template['revision']=candidate_revision(name)
        request = {'template': template, 'traffic': [{'type': 'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION',
            'revision': row['revision'], 'percent': 100}]}
        if row['service'].get('etag'):
            request['etag'] = row['service']['etag']
        operation = run.api('PATCH', run.PREFIX + name + '?updateMask=template,traffic', request)
        operations[name] = {'operation': operation, 'original_revision': row['revision'],
            'expected_revision':candidate_revision(name),'template_sha256': row['template_sha256']}
        dump(receipt('candidate_' + name), operations[name])
    dump(receipt('candidate_operations'), {'binding': binding, 'operations': operations, 'recorded_at': now()})
    return {'created': list(operations), 'traffic_on_original_revision': True, 'provider_calls': 0}


def poll():
    saved = read(receipt('candidate_operations'))
    binding, _ = release()
    if saved['binding'] != binding:
        raise ValueError('CANDIDATE_RELEASE_BINDING_CHANGED')
    initial = read(receipt('initial'))
    results = {}
    for name, row in saved['operations'].items():
        result = run.api('GET', 'https://run.googleapis.com/v2/' + row['operation']['name'])
        results[name] = result
    if not all(result.get('done') is True for result in results.values()):
        return {'candidates_ready': False, 'done': {name: value.get('done') is True for name, value in results.items()}}
    if any(result.get('error') for result in results.values()):
        raise ValueError('COMPATIBLE_CANDIDATE_CREATION_FAILED')
    candidates = {}
    for name, result in results.items():
        service=run.api('GET',run.PREFIX+name)
        require_service(name,service,binding,initial['services'][name]['template_sha256'])
        revision=saved['operations'][name].get('expected_revision')
        if (revision!=candidate_revision(name) or revision==initial['services'][name]['revision'] or
                service.get('latestCreatedRevision','').split('/')[-1]!=revision or
                service['template'].get('revision','').split('/')[-1]!=revision or
                routed_revision(service)!=initial['services'][name]['revision']):
            raise ValueError('CANDIDATE_NOT_NEW_OR_TRAFFIC_MOVED_EARLY')
        actual=run.api('GET',run.PREFIX+name+'/revisions/'+revision)
        if actual.get('name','').split('/')[-1]!=revision:
            raise ValueError('EXACT_IMMUTABLE_CANDIDATE_REQUIRED')
        ready=[row for row in actual.get('conditions',[]) if row.get('type')=='Ready']
        if len(ready)!=1 or ready[0].get('state')!='CONDITION_SUCCEEDED' or actual.get('reconciling')is True:
            return {'candidates_ready':False,'exact_revision_ready':False,'provider_calls':0}
        normalized=require_revision_configuration(actual,service['template'])
        candidates[name]={'service':service,'revision':revision,
            'template_sha256':initial['services'][name]['template_sha256'],
            'immutable_candidate_configuration_confirmed':True,
            'server_assigned_single_container_name_normalized':normalized}
    target = receipt('candidates')
    if not (cloud.OUT / target).exists():
        dump(target, {'schema': SCHEMA, 'binding': binding, 'services': candidates, 'recorded_at': now()})
    elif read(target)['services'] != candidates:
        raise ValueError('IMMUTABLE_CANDIDATE_RECEIPT_CHANGED')
    return {'candidates_ready': True, 'revisions': {name: row['revision'] for name, row in candidates.items()}, 'provider_calls': 0}


def route(stage):
    if stage not in ('candidate', 'rollback', 'restore'):
        raise ValueError('UNKNOWN_ROLLBACK_STAGE')
    target = receipt(stage + '_traffic')
    require_absent(target, *(receipt(stage + '_traffic_' + name) for name in run.NAMES))
    binding, _ = release()
    initial = read(receipt('initial'))
    candidates = read(receipt('candidates'))
    if binding != initial['binding'] or binding != candidates['binding']:
        raise ValueError('ROUTING_RELEASE_BINDING_CHANGED')
    if stage in ('rollback', 'restore'):
        require_health_receipt('candidate' if stage == 'rollback' else 'rollback', binding)
    policies = private_policies(include_ui=True)
    if any(digest(policy) != initial['private_policy_sha256'][name] for name, policy in policies.items()):
        raise ValueError('PRIVATE_IAM_POLICY_CHANGED_DURING_REHEARSAL')
    rows = (initial if stage == 'rollback' else candidates)['services']
    operations = {}
    for name, row in rows.items():
        service = run.api('GET', run.PREFIX + name)
        require_service(name, service, binding, row['template_sha256'])
        request = {'traffic': [{'type': 'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION',
            'revision': row['revision'], 'percent': 100}]}
        if service.get('etag'):
            request['etag'] = service['etag']
        operation = run.api('PATCH', run.PREFIX + name + '?updateMask=traffic', request)
        operations[name] = {'revision': row['revision'], 'operation': operation}
        dump(receipt(stage + '_traffic_' + name), operations[name])
    dump(target, {'schema': SCHEMA, 'binding': binding, 'operations': operations,
        'recorded_at': now(), 'provider_calls': 0, 'public_iam_changed': False})
    return {'stage': stage, 'revisions': {name: row['revision'] for name, row in rows.items()}, 'provider_calls': 0}


def health(stage):
    if stage not in ('candidate', 'rollback', 'restore'):
        raise ValueError('UNKNOWN_ROLLBACK_STAGE')
    target = receipt(stage + '_health')
    require_absent(target)
    binding, _ = release()
    routed = read(receipt(stage + '_traffic'))
    if routed['binding'] != binding:
        raise ValueError('HEALTH_RELEASE_BINDING_CHANGED')
    rows = read(receipt('initial' if stage == 'rollback' else 'candidates'))['services']
    for row in routed['operations'].values():
        operation = run.api('GET', 'https://run.googleapis.com/v2/' + row['operation']['name'])
        if operation.get('done') is not True or operation.get('error'):
            raise ValueError('TRAFFIC_UPDATE_NOT_READY')
    token = identity_token()
    services = {}
    for name, row in rows.items():
        service = run.api('GET', run.PREFIX + name)
        require_service(name, service, binding, row['template_sha256'])
        if routed_revision(service) != row['revision']:
            raise ValueError('EXPECTED_REVISION_NOT_ACTUALLY_ROUTED')
        services[name] = {**get_health(name, service, binding, token), 'revision': row['revision'],
            'traffic': service['trafficStatuses'], 'image': service['template']['containers'][0]['image'],
            'template_sha256': row['template_sha256']}
    policies = private_policies(include_ui=True)
    initial = read(receipt('initial'))
    if any(digest(policy) != initial['private_policy_sha256'][name] for name, policy in policies.items()):
        raise ValueError('PRIVATE_IAM_POLICY_CHANGED_DURING_REHEARSAL')
    result = {'schema': SCHEMA, 'recorded_at': now(), 'binding': binding, 'stage': stage,
        'actual_routed_health_passed': True, 'services': services, 'provider_calls': 0,
        'public_iam_changed': False, 'private_policy_sha256': initial['private_policy_sha256']}
    dump(target, result)
    return {'stage': stage, 'actual_routed_health_passed': True, 'provider_calls': 0}


def require_health_receipt(stage, binding):
    saved = read(receipt(stage + '_health'))
    rows = read(receipt('initial' if stage == 'rollback' else 'candidates'))['services']
    if (saved.get('schema') != SCHEMA or saved.get('binding') != binding or
            saved.get('stage') != stage or saved.get('actual_routed_health_passed') is not True or
            type(saved.get('provider_calls')) is not int or saved['provider_calls'] != 0 or
            saved.get('public_iam_changed') is not False or
            set(saved.get('services', {})) != set(run.NAMES)):
        raise ValueError('ACTUAL_COMPATIBLE_HEALTH_RECEIPT_REQUIRED')
    for name, expected in rows.items():
        row = saved['services'][name]
        if (row.get('http_status') != 200 or row.get('health', {}).get('ready') is not True or
                row.get('revision') != expected['revision'] or row.get('template_sha256') != expected['template_sha256'] or
                row.get('image') != binding['images']['ui' if name == 'motomedic-rider-ui' else 'backend']):
            raise ValueError('SAVED_HEALTH_REVISION_OR_IMAGE_CHANGED')
    return saved


def acceptance(binding, manifest):
    """Engineering route matches and native counts never substitute for review."""
    semantic_path = cloud.OUT / OPS / ('semantic_acceptance_' + VERSION + '.json')
    semantic = json.loads(semantic_path.read_bytes())
    submission = read('evaluator_client_submission_v7.json')
    build = submission['operation']['metadata']['build']['id']
    if not BUILD_ID.fullmatch(build):
        raise ValueError('EXACT_HOSTED_EVALUATOR_BUILD_REQUIRED')
    if (semantic.get('schema') != SEMANTIC_SCHEMA or semantic.get('decision') != 'ACCEPTED' or
            semantic.get('serving_manifest_sha256') != binding['serving_manifest_sha256'] or
            semantic.get('runtime_lock') != binding['runtime_lock'] or semantic.get('evaluator_build_id') != build or
            semantic.get('independent_original_pdf_agent_review') is not True or
            semantic.get('human_signoff') is not False or
            semantic.get('source_display_authorization_changed') is not False):
        raise ValueError('EXACT_INDEPENDENT_SEMANTIC_ACCEPTANCE_REQUIRED')
    hosted_dir = (cloud.OUT / 'hosted_runs' / build).resolve()
    hosted = json.loads((hosted_dir / 'receipt.json').read_bytes())
    source = read('evaluator_client_source_v8.json')
    if (source.get('serving_manifest_sha256') != binding['serving_manifest_sha256'] or
            source.get('runtime_lock') != binding['runtime_lock'] or
            submission['config']['source']['storageSource'] != {'bucket': cloud.BUCKET,
                'object': source['object'], 'generation': source['generation']} or
            not HEX64.fullmatch(source.get('sha256', '')) or
            source['object'] != 'serving/engineering-clients/' + VERSION + '/' + source['sha256'] + '.tar.gz' or
            not re.fullmatch(r'[0-9]+', source['generation']) or
            hosted.get('client_input_inventory', {}).get('serving_manifest_sha256') != binding['serving_manifest_sha256']):
        raise ValueError('ACTUAL_EVALUATOR_SOURCE_MANIFEST_BINDING_CHANGED')
    inventory_reference = 'tmp/public_evaluator/client_inputs_v10_11.json'
    inventory_path = cloud.ROOT / inventory_reference
    if (file_hash(inventory_path) != source.get('source_inventory_sha256') or
            file_hash(inventory_path) != source.get('files', {}).get(inventory_reference) or
            json.loads(inventory_path.read_bytes()) != hosted.get('client_input_inventory') or
            hosted['client_input_inventory'].get('file_sha256') !=
                {key: value for key, value in source['files'].items() if key != inventory_reference}):
        raise ValueError('EXACT_HOSTED_CLIENT_ARCHIVE_INVENTORY_CHANGED')
    plan_path = cloud.OUT / PLAN
    plan_sha = file_hash(plan_path)
    plan_reference = 'reports/public_evaluator/20261012/' + PLAN
    if (plan_sha != PLAN_SHA or source.get('files', {}).get(plan_reference) != PLAN_SHA or
            hosted.get('client_input_inventory', {}).get('file_sha256', {}).get(plan_reference) != PLAN_SHA):
        raise ValueError('FROZEN_EVALUATOR_PLAN_CHANGED')
    planned = {case['case_id']: case for case in json.loads(plan_path.read_bytes())['cases']}
    if (hosted.get('schema') != 'motomedic-hosted-original-page-evaluator-v1' or
            hosted.get('cloud_build_id') != build or hosted.get('runtime_lock') != binding['runtime_lock'] or
            hosted.get('plan_sha256') != plan_sha or hosted.get('completed_operation_boundary_checks') is not True or
            hosted.get('engineering_transport_and_route_passed') is not True or
            any(type(hosted.get(key)) is not int or hosted[key] != 6 for key in
                ('case_count', 'planned_case_count', 'attempted_case_count', 'engineering_completed_cases')) or
            hosted.get('stopped_early') is not False or 'ledger_after_error' not in hosted or hosted['ledger_after_error'] is not None or
            type(hosted.get('post_retries')) is not int or hosted['post_retries'] != 0 or hosted.get('allocation_reset') is not False or
            hosted.get('allocation_refund') is not False or set(hosted.get('case_files', {})) != set(planned)):
        raise ValueError('EXACT_SIX_CASE_ENGINEERING_AND_BOUNDARY_RECEIPT_REQUIRED')
    for allocation, maxima, counters in (
            ('grounded-primary-nonrecurring-v1', {'maximum_attempts': 100, 'maximum_tokens': 999200},
             {'reserved_attempts': 100, 'reserved_tokens': 999200}),
            ('owner-haiku-fallback-20261011-validation-v1', {'maximum_nanodollars': 1000000000},
             {'reserved_nanodollars': 1000000000})):
        before = hosted.get('ledger_before', {}).get(allocation, {})
        after = hosted.get('ledger_after', {}).get(allocation, {})
        if any(type(row.get(key)) is not int or row[key] != value for row in (before, after)
                for key, value in maxima.items()) or any(
                type(before.get(key)) is not int or type(after.get(key)) is not int or
                not 0 <= before[key] <= after[key] <= maximum for key, maximum in counters.items()):
            raise ValueError('PERMANENT_ALLOCATION_LIMIT_OR_RETAINED_RESERVATION_CHANGED')
    reviews = semantic.get('case_records')
    if not isinstance(reviews, list) or len(reviews) != 6 or len(planned) != 6:
        raise ValueError('SIX_INDEPENDENT_CASE_REVIEWS_REQUIRED')
    seen, boundary = set(), False
    for review in reviews:
        case_id = review.get('case_id')
        if case_id not in planned or case_id in seen:
            raise ValueError('EXACT_UNIQUE_REVIEWED_CASE_REQUIRED')
        seen.add(case_id)
        raw_path = review.get('artifact_file')
        if not isinstance(raw_path, str):
            raise ValueError('EXACT_HOSTED_CASE_ARTIFACT_REQUIRED')
        path = (cloud.ROOT / raw_path).resolve()
        if path != hosted_dir / (case_id + '.json'):
            raise ValueError('REVIEWED_CASE_ARTIFACT_OUTSIDE_EXACT_BUILD')
        artifact_sha = file_hash(path)
        case = json.loads(path.read_bytes())
        if (artifact_sha != review.get('artifact_sha256') or artifact_sha != hosted['case_files'][case_id] or
                case.get('case_id') != case_id or case.get('route') != review.get('actual_route') or
                review.get('expected_route') not in planned[case_id]['expected_outcomes'] or
                review['actual_route'] != review['expected_route'] or
                case.get('expected_route_matched') is not True or case.get('exact_saved_stream') is not True or
                case.get('exact_recovered_view') is not True or case.get('error') or
                case.get('saved_view', {}).get('delivery', {}).get('runtime_lock') != binding['runtime_lock']):
            raise ValueError('REVIEWED_CASE_HASH_ROUTE_OR_DELIVERY_CHANGED')
        for key in ('claim_support', 'warning_condition_unit_context', 'citations', 'history'):
            allowed = {'PASS'}
            if ((key == 'history' and not planned[case_id].get('previous_case_id')) or
                    (key != 'history' and review['actual_route'] in ('UNSUPPORTED', 'AMBIGUOUS'))):
                allowed.add('NOT_APPLICABLE')
            if review.get(key) not in allowed:
                raise ValueError('INDEPENDENT_CLAIM_CONTEXT_CITATION_HISTORY_REVIEW_FAILED')
        checks = case.get('completed_operation_checks', {})
        if (checks.get('duplicate_post_same_operation_and_request') is True and
                checks.get('duplicate_post_same_saved_view') is True and
                type(checks.get('wrong_valid_visitor_get_status')) is int and checks['wrong_valid_visitor_get_status'] == 404 and
                checks.get('provider_reservations_unchanged') is True and
                type(checks.get('provider_calls')) is int and checks['provider_calls'] == 0 and
                checks.get('new_operation_or_question_created') is False):
            boundary = True
    if seen != set(planned) or not boundary:
        raise ValueError('ACTUAL_COMPLETED_OPERATION_OWNERSHIP_BOUNDARY_REQUIRED')
    return {'semantic_receipt_sha256': file_hash(semantic_path),
        'hosted_receipt_sha256': file_hash(hosted_dir / 'receipt.json'), 'evaluator_build_id': build,
        'case_files': hosted['case_files'], 'semantic_decision': 'ACCEPTED',
        'completed_operation_boundary_checks': True}


def ui_public_policy(policy):
    """Add precisely one UI invoker member; preserve every unrelated IAM row."""
    if not policy.get('etag'):
        raise ValueError('UI_IAM_CONCURRENCY_ETAG_REQUIRED')
    if any(PUBLIC_MEMBERS.intersection(row.get('members', [])) for row in policy.get('bindings', [])):
        raise ValueError('UI_ALREADY_PUBLIC_REQUIRE_EXISTING_RECEIPT')
    updated = deepcopy(policy)
    bindings = updated.setdefault('bindings', [])
    unconditioned = [row for row in bindings if row.get('role') == 'roles/run.invoker' and not row.get('condition')]
    if len(unconditioned) > 1:
        raise ValueError('AMBIGUOUS_UI_INVOKER_BINDING')
    if unconditioned:
        unconditioned[0]['members'].append('allUsers')
    else:
        bindings.append({'role': 'roles/run.invoker', 'members': ['allUsers']})
    return updated


def public_open():
    """Root-only separate action: open UI IAM after actual acceptance and restore."""
    target = OPS + 'public_open_' + VERSION + '_v1.json'
    prior_name = OPS + 'public_open_' + VERSION + '_prior_v1.json'
    require_absent(target, prior_name, OPS + 'public_iam_' + VERSION + '_v1.json')
    binding, manifest = release()
    auth = manifest.get('owner_authorization', {})
    if (manifest.get('public_opening_authorized') is not True or
            auth.get('authority') != 'DIRECT_USER_INSTRUCTION' or
            auth.get('scope') != 'PUBLIC_EVALUATOR_DEPLOYMENT_AND_BOUNDED_PROVIDER_VALIDATION' or
            file_hash(cloud.ROOT / auth['path']) != auth.get('sha256')):
        raise ValueError('EXACT_OWNER_PUBLIC_OPENING_SCOPE_REQUIRED')
    approved = acceptance(binding, manifest)
    rollback = require_health_receipt('rollback', binding)
    restored = require_health_receipt('restore', binding)
    policies = private_policies(include_ui=True)
    if any(digest(policy) != restored['private_policy_sha256'][name] for name, policy in policies.items()):
        raise ValueError('PRIVATE_IAM_POLICY_CHANGED_AFTER_RESTORE')
    services = {}
    token = identity_token()
    for name in run.NAMES:
        service = run.api('GET', run.PREFIX + name)
        row = restored['services'][name]
        require_service(name, service, binding, row['template_sha256'])
        if routed_revision(service) != row['revision']:
            raise ValueError('EXACT_RESTORED_REVISION_NO_LONGER_ROUTED')
        get_health(name, service, binding, token)
        services[name] = service
    ui = 'motomedic-rider-ui'
    prior = policies[ui]
    updated = ui_public_policy(prior)
    dump(prior_name, {'schema': 'motomedic-ui-public-opening-prior-v1', 'recorded_at': now(),
        'binding': binding, 'acceptance': approved, 'ui_policy': prior,
        'private_policy_sha256': {name: digest(policies[name]) for name in CORE},
        'rollback_health_sha256': file_hash(cloud.OUT / receipt('rollback_health')),
        'restore_health_sha256': file_hash(cloud.OUT / receipt('restore_health')),
        'provider_calls': 0})
    run.api('POST', run.PREFIX + ui + ':setIamPolicy', {'policy': updated})
    after = run.api('GET', run.PREFIX + ui + ':getIamPolicy?options.requestedPolicyVersion=3')
    if sorted(map(digest, after.get('bindings', []))) != sorted(map(digest, updated['bindings'])):
        raise ValueError('EXACT_UI_PUBLIC_INVOKER_READBACK_FAILED')
    core_after = private_policies()
    if any(digest(core_after[name]) != digest(policies[name]) for name in CORE):
        raise ValueError('PRIVATE_BACKEND_WORKER_OR_QDRANT_IAM_CHANGED')
    dump(OPS + 'public_iam_' + VERSION + '_v1.json', {
        'schema': 'motomedic-ui-public-iam-v1', 'recorded_at': now(), 'binding': binding,
        'acceptance': approved, 'ui_policy': after, 'ui_all_users_invoker_only': True,
        'private_backend_worker_qdrant_unchanged': True, 'provider_calls': 0})
    return public_health()


def public_health():
    """Read-only finalization; delayed IAM propagation never implies success."""
    target = OPS + 'public_open_' + VERSION + '_v1.json'
    require_absent(target)
    binding, manifest = release()
    approved = acceptance(binding, manifest)
    prior = read(OPS + 'public_open_' + VERSION + '_prior_v1.json')
    applied = read(OPS + 'public_iam_' + VERSION + '_v1.json')
    restored = require_health_receipt('restore', binding)
    if (prior.get('binding') != binding or applied.get('binding') != binding or
            prior.get('acceptance') != approved or applied.get('acceptance') != approved or
            applied.get('ui_all_users_invoker_only') is not True):
        raise ValueError('RECORDED_UI_IAM_ACCEPTANCE_BINDING_CHANGED')
    core = private_policies()
    if any(digest(core[name]) != prior['private_policy_sha256'][name] for name in CORE):
        raise ValueError('PRIVATE_BACKEND_WORKER_OR_QDRANT_IAM_CHANGED')
    token = identity_token()
    ui = 'motomedic-rider-ui'
    services = {}
    for name in run.NAMES:
        service = run.api('GET', run.PREFIX + name)
        row = restored['services'][name]
        require_service(name, service, binding, row['template_sha256'])
        if routed_revision(service) != row['revision']:
            raise ValueError('PUBLIC_RESTORED_TRAFFIC_REVISION_CHANGED')
        if name != ui:
            get_health(name, service, binding, token)
        services[name] = service
    policy = run.api('GET', run.PREFIX + ui + ':getIamPolicy?options.requestedPolicyVersion=3')
    expected = ui_public_policy(prior['ui_policy'])
    if sorted(map(digest, policy.get('bindings', []))) != sorted(map(digest, expected['bindings'])):
        raise ValueError('EXACT_UI_PUBLIC_INVOKER_READBACK_FAILED')
    public_url = 'https://motomedic-rider-ui-' + PROJECT_NUMBER + '.us-central1.run.app'
    try:
        anonymous_health = get_health(ui, services[ui], binding, url=public_url)
    except HTTPError as error:
        if error.code not in (403, 503):
            raise
        return {'public_url': public_url, 'public_iam_configured': True,
            'anonymous_ui_health_ready': False, 'verification_pending': True,
            'http_status': error.code, 'public_browser_acceptance': False, 'provider_calls': 0}
    result = {'schema': 'motomedic-ui-public-opening-v1', 'recorded_at': now(), 'binding': binding,
        'acceptance': approved, 'public_url': public_url, 'ui_revision': routed_revision(services[ui]),
        'ui_all_users_invoker_only': True, 'ui_policy_sha256': digest(policy),
        'private_backend_worker_qdrant_unchanged': True, 'anonymous_ui_health': anonymous_health,
        'public_browser_acceptance': False, 'provider_calls': 0, 'secret_payload_read': False,
        'billing_changed': False, 'allocation_changed': False, 'source_display_authorization_changed': False}
    dump(target, result)
    return {'public_url': public_url, 'anonymous_ui_health_ready': True,
        'public_browser_acceptance': False, 'private_core_unchanged': True, 'provider_calls': 0}


def route_rollback():
    return route('rollback')


def route_restore():
    return route('restore')


def health_rollback():
    return health('rollback')


def health_restore():
    return health('restore')


def route_candidate():
    return route('candidate')


def health_candidate():
    return health('candidate')


PRIVATE_ACTIONS = {'create': create, 'poll': poll, 'route_candidate': route_candidate,
    'health_candidate': health_candidate, 'route_rollback': route_rollback,
    'health_rollback': health_rollback, 'route_restore': route_restore, 'health_restore': health_restore}


if __name__ == '__main__':
    if sys.argv[1:] == ['--check-only']:
        print(json.dumps({'private_actions': list(PRIVATE_ACTIONS), 'separate_public_action': 'public_open',
            'separate_public_readback': 'public_health', 'cloud_actions_executed': False, 'provider_calls': 0}))
    else:
        action = sys.argv[1] if len(sys.argv) == 2 else ''
        if action not in {*PRIVATE_ACTIONS, 'public_open', 'public_health'}:
            raise SystemExit('ONE_FIXED_ACTION_REQUIRED')
        # Standalone use gets a bounded SDK login; private console may inject its own.
        cloud.token = lambda: sdk_token('print-access-token')
        print(json.dumps(({'public_open': public_open, 'public_health': public_health}.get(action)
            or PRIVATE_ACTIONS[action])()))
