"""Synthetic finite-normalization checks; no SDK/cloud/provider calls."""
import copy,json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import rollback_public_v10_10 as helper
class NameNormalizationTests(unittest.TestCase):
 def setUp(self):
  self.template=json.loads((helper.cloud.OUT/'deployment_backend_v10_10_result.json').read_bytes())['response']['template']
  self.actual={key:copy.deepcopy(self.template[key]) for key in ('containers','serviceAccount','timeout','maxInstanceRequestConcurrency')}
 def fail(self,actual=None,template=None):
  with self.assertRaisesRegex(ValueError,'ACTUAL_TRAFFIC_REVISION_CONFIGURATION_DIFFERS'):helper.require_revision_configuration(actual or self.actual,template or self.template)
 def test_actual_configuration_synthetic_generated_name_only_preserves_inputs(self):
  self.actual['containers'][0]['name']='synthetic-generated-1';before=copy.deepcopy((self.actual,self.template))
  self.assertTrue(helper.require_revision_configuration(self.actual,self.template));self.assertEqual((self.actual,self.template),before)
 def test_unmodified_or_identical_explicit_name_remains_strict(self):
  self.assertFalse(helper.require_revision_configuration(self.actual,self.template))
  self.template['containers'][0]['name']='explicit-1';self.actual['containers'][0]['name']='explicit-1'
  self.assertFalse(helper.require_revision_configuration(self.actual,self.template))
  self.actual['containers'][0]['name']='other-1';self.fail()
 def test_any_other_container_field_or_unknown_field_change_rejected(self):
  self.actual['containers'][0]['name']='synthetic-generated-1'
  for key in self.template['containers'][0]:
   with self.subTest(field=key):
    changed=copy.deepcopy(self.actual);changed['containers'][0][key]=None;self.fail(changed)
  changed=copy.deepcopy(self.actual);changed['containers'][0]['unrecognizedRuntimeField']=True;self.fail(changed)
 def test_service_identity_timeout_and_concurrency_change_rejected(self):
  self.actual['containers'][0]['name']='synthetic-generated-1'
  for key in ('serviceAccount','timeout','maxInstanceRequestConcurrency'):
   with self.subTest(field=key):
    changed=copy.deepcopy(self.actual);changed[key]=None;self.fail(changed)
 def test_multicontainer_invalid_name_and_dependency_are_rejected(self):
  for name in ('','UPPERCASE','-invalid','invalid-', 'a'*64,123):
   with self.subTest(name_type=type(name).__name__):
    changed=copy.deepcopy(self.actual);changed['containers'][0]['name']=name;self.fail(changed)
  self.actual['containers'][0]['name']='synthetic-generated-1'
  self.actual['containers'].append(copy.deepcopy(self.actual['containers'][0]));t=copy.deepcopy(self.template);t['containers'].append(copy.deepcopy(t['containers'][0]));self.fail(template=t)
  self.actual['containers'].pop();self.actual['containers'][0]['dependsOn']=['another'];self.fail()
if __name__=='__main__':unittest.main()
