"""Synthetic exact maintenance recipe/IAM/source checks; no cloud/model calls."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'))
import token_ceiling_operator_v13_v2 as operator
import token_ceiling_maintenance_job_v13 as job

class OperatorTests(unittest.TestCase):
    def test_pending_transaction_journal_is_preserved_as_private_artifact(self):
        self.assertIn('application_receipt_application_pending.json',job.ARTIFACT_NAMES)
        self.assertEqual(len(job.ARTIFACT_NAMES),4)
        self.assertNotIn('raw_subprocess_logs.json',job.ARTIFACT_NAMES)
        self.assertEqual(operator.ARTIFACT_NAMES,job.ARTIFACT_NAMES)
    def test_read_only_logs_keep_only_protected_artifact_scalar_inventory(self):
        bid='11111111-2222-4333-8444-555555555555'
        reply={'entries':[{'timestamp':'2026-10-12T10:00:00Z','textPayload':'Step #1: '+json.dumps({
            'artifact_file':'application_receipt_application_pending.json','generation':'123','sha256':'a'*64,'private_token':'must-not-save'})},
            {'textPayload':'Bearer secret-must-not-save'},
            {'jsonPayload':{'artifact_file':'unknown.json','generation':'456','sha256':'b'*64}}]}
        with patch.object(operator,'read',return_value={'operation':{'metadata':{'build':{'id':bid}}}}),\
            patch.object(operator.cloud,'api',return_value=reply),patch.object(operator,'write') as write:
            value=operator.logs();self.assertEqual(value['artifact_records'],1)
            saved=write.call_args.args[1];self.assertFalse(saved['raw_logs_saved'])
            self.assertEqual(set(saved['records'][0]),{'timestamp','artifact_file','generation','sha256'})
            self.assertNotIn('must-not-save',json.dumps(saved))
    def values(self):
        source={'serving_manifest_sha256':'a'*64,'sha256':'b'*64,'generation':'123',
            'object':'serving/engineering-maintenance/v10_13/'+'b'*64+'.tar.gz'}
        binding={'runtime_revision':'v10_13','serving_manifest_sha256':'a'*64,
            'images':{'backend':'us-central1-docker.pkg.dev/'+operator.cloud.PROJECT+'/motomedic/arm-a@sha256:'+'c'*64}}
        return source,binding
    def test_pinned_backend_exact_source_and_no_secret_or_generation_recipe(self):
        source,binding=self.values();config=operator.build_recipe(source,binding)
        self.assertEqual(config['source']['storageSource']['generation'],'123')
        self.assertEqual(config['steps'][1]['name'],binding['images']['backend'])
        self.assertNotIn('availableSecrets',config);self.assertNotIn('secretEnv',config['steps'][1])
        self.assertIn('MOTOMEDIC_HOSTED_TOKEN_LIMIT_MAINTENANCE=true',config['steps'][1]['env'])
        self.assertIn('gs://'+operator.cloud.BUCKET+'/engineering-acceptance/public-v10_3/$BUILD_ID',config['steps'][1]['args'])
        self.assertEqual(config['timeout'],'600s')
    def test_wrong_version_manifest_image_object_or_generation_cannot_submit(self):
        for field in ('version','manifest','image','object','generation'):
            source,binding=self.values()
            if field=='version':binding['runtime_revision']='v10_12'
            elif field=='manifest':binding['serving_manifest_sha256']='f'*64
            elif field=='image':binding['images']['backend']='unbound-image'
            elif field=='object':source['object']='unbound-object'
            else:source['generation']='latest'
            with self.subTest(field=field),self.assertRaises(ValueError):operator.build_recipe(source,binding)
    def test_exact_additive_get_keeps_client_and_artifact_creation_grants(self):
        source,_=self.values();policy={'version':3,'etag':'synthetic','bindings':[
            {'role':'client10-role','members':['client10-principal'],'condition':{'title':'client10','expression':'exact-client10-object'}},
            {'role':'artifact-create-role','members':['existing-backend'],'condition':{'expression':'exact-existing-protected-prefix'}}]}
        before=deepcopy(policy);updated,added=operator.source_policy(policy,source)
        self.assertEqual(policy,before);self.assertEqual(updated['bindings'][:-1],before['bindings'])
        self.assertEqual(added['members'],[operator.MEMBER]);self.assertEqual(added['role'],operator.GET_ROLE)
        self.assertEqual(added['condition']['expression'],"resource.name == 'projects/_/buckets/"+operator.cloud.BUCKET+'/objects/'+source['object']+"'")
    def test_public_bucket_missing_etag_or_existing_maintenance_scope_fails_closed(self):
        source,_=self.values()
        for policy in ({'bindings':[]},{'etag':'x','bindings':[{'members':['allUsers']}]},
            {'etag':'x','bindings':[{'condition':{'title':operator.TITLE}}]}):
            with self.assertRaises(ValueError):operator.source_policy(policy,source)
    def test_inventory_detects_changed_bytes_and_path_escape_before_tool(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory:
            root=Path(directory);manifest=root/'reports/public_evaluator/20261012/serving_manifest_v10_13.json'
            manifest.parent.mkdir(parents=True);manifest.write_text('{}',encoding='utf-8')
            inventory={'schema':'motomedic-token-ceiling-maintenance-source-inputs-v1',
                'serving_manifest_sha256':job.digest(manifest),'file_sha256':{manifest.relative_to(root).as_posix():job.digest(manifest)}}
            self.assertTrue(job.validate_inventory(inventory,root));manifest.write_text('{"changed":true}',encoding='utf-8')
            with self.assertRaises(ValueError):job.validate_inventory(inventory,root)
            inventory['file_sha256']={'../outside.json':'a'*64}
            with self.assertRaises(ValueError):job.validate_inventory(inventory,root)

if __name__=='__main__':unittest.main()
