"""Exact hosted maintenance transport; no model credentials or inference calls."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import urlsplit,urlencode

ROOT=Path(__file__).resolve().parents[1]
PROJECT='motomedic-ai-20261009'
BUCKET=PROJECT+'-indices'
ARTIFACT_NAMES=frozenset(('application_receipt.json','application_receipt_application_pending.json',
    'maintenance_receipt.json','exit_status.json'))

def digest(path):return sha256(Path(path).read_bytes()).hexdigest()

def validate_inventory(inventory,root):
    if inventory.get('schema')!='motomedic-token-ceiling-maintenance-source-inputs-v1':raise ValueError('MAINTENANCE_INVENTORY_SCHEMA')
    for name,expected in inventory['file_sha256'].items():
        path=(root/name).resolve()
        if not path.is_relative_to(root) or digest(path)!=expected:raise ValueError('MAINTENANCE_SOURCE_INPUT_CHANGED')
    manifest=root/'reports/public_evaluator/20261012/serving_manifest_v10_13.json'
    if digest(manifest)!=inventory['serving_manifest_sha256']:raise ValueError('MAINTENANCE_FROZEN_MANIFEST_CHANGED')
    return True

def upload(output,uri,job):
    target=urlsplit(uri)
    if target.scheme!='gs' or target.netloc!=BUCKET or target.path!='/engineering-acceptance/public-v10_3/'+job or target.query or target.fragment:
        raise ValueError('MAINTENANCE_PROTECTED_ARTIFACT_PREFIX_CHANGED')
    import google.auth
    from google.auth.transport.requests import AuthorizedSession
    credentials,_=google.auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'])
    client=AuthorizedSession(credentials)
    for path in sorted(output.glob('*.json')):
        if path.name not in ARTIFACT_NAMES:raise ValueError('MAINTENANCE_ARTIFACT_NAME_CHANGED')
        raw=path.read_bytes()
        if len(raw)>2*1024*1024:raise ValueError('MAINTENANCE_ARTIFACT_BYTE_BOUND')
        name=target.path.strip('/')+'/'+path.name
        url='https://storage.googleapis.com/upload/storage/v1/b/'+BUCKET+'/o?'+urlencode({'uploadType':'media','name':name,'ifGenerationMatch':'0'})
        reply=client.post(url,data=raw,headers={'Content-Type':'application/json'},timeout=60,allow_redirects=False)
        try:
            if reply.status_code!=200:raise RuntimeError('MAINTENANCE_ARTIFACT_CREATE_FAILED')
            metadata=reply.json()
        finally:reply.close()
        print(json.dumps({'artifact_file':path.name,'generation':metadata['generation'],'sha256':sha256(raw).hexdigest(),'credentials_logged':False}),flush=True)

def main(args):
    job=os.environ.get('MOTOMEDIC_CLOUD_BUILD_ID')
    if (ROOT!=Path('/workspace') or not re.fullmatch(r'[0-9a-f-]{36}',job or '') or job!=args.allocated_job_id or
        os.environ.get('MOTOMEDIC_HOSTED_TOKEN_LIMIT_MAINTENANCE')!='true' or any(os.environ.get(name) for name in
        ('ANTHROPIC_API_KEY','MOTOMEDIC_GEMINI_API_KEY','MOTOMEDIC_VISITOR_SECRET'))):raise RuntimeError('EXACT_NO_SECRET_HOSTED_MAINTENANCE_CONTEXT_REQUIRED')
    output=Path(args.output).resolve()
    if not output.is_relative_to(ROOT/'tmp') or any(output.iterdir()):raise ValueError('NEW_PRIVATE_MAINTENANCE_OUTPUT_REQUIRED')
    inventory_path=(ROOT/args.inventory).resolve()
    if not inventory_path.is_relative_to(ROOT):raise ValueError('MAINTENANCE_INVENTORY_LOCATION_CHANGED')
    inventory=json.loads(inventory_path.read_bytes());validate_inventory(inventory,ROOT)
    success=False
    try:
        result=subprocess.run([sys.executable,'-B',str(ROOT/'tools/manage_primary_token_ceiling.py'),
            'apply-owner-approved','--proposal',str(ROOT/inventory['proposal_path']),
            '--owner-evidence',str(ROOT/inventory['owner_evidence_path']),
            '--output',str(output/'application_receipt.json')],capture_output=True,text=True,timeout=180)
        if result.returncode:raise RuntimeError('MAINTENANCE_TOOL_FAILED_OUTCOME_MAY_BE_UNCERTAIN')
        receipt=json.loads((output/'application_receipt.json').read_bytes())
        if receipt.get('schema')!='motomedic-owner-token-ceiling-application-receipt-v1' or receipt.get('provider_calls')!=0:
            raise RuntimeError('MAINTENANCE_APPLICATION_RECEIPT_INVALID')
        success=True
    finally:
        receipt={'schema':'motomedic-hosted-token-ceiling-maintenance-v1','cloud_build_id':job,
            'serving_manifest_sha256':inventory['serving_manifest_sha256'],'runtime_lock':inventory['runtime_lock'],
            'source_inventory_sha256':digest(inventory_path),'maintenance_tool_sha256':inventory['file_sha256']['tools/manage_primary_token_ceiling.py'],
            'owner_evidence_sha256':inventory['file_sha256'][inventory['owner_evidence_path']],
            'proposal_sha256':inventory['file_sha256'][inventory['proposal_path']],
            'application_receipt_sha256':digest(output/'application_receipt.json') if (output/'application_receipt.json').exists() else None,
            'application_pending_receipt_sha256':digest(output/'application_receipt_application_pending.json') if (output/'application_receipt_application_pending.json').exists() else None,
            'application_success':success,'failure_outcome_may_be_uncertain':not success,
            'provider_calls':0,'provider_credentials_supplied':False,'credentials_logged':False,
            'raw_subprocess_logs_saved':False,'billing_changed':False,'counter_reset_or_refund':False}
        for name,value in (('maintenance_receipt.json',receipt),('exit_status.json',{'cloud_build_id':job,'exit_code':0 if success else 1,'provider_calls':0})):
            with (output/name).open('x',encoding='utf-8') as target:target.write(json.dumps(value,indent=2,sort_keys=True)+'\n')
        upload(output,args.artifact_uri,job)
    return 0 if success else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--inventory',required=True);parser.add_argument('--output',required=True)
    parser.add_argument('--artifact-uri',required=True);parser.add_argument('--allocated-job-id',required=True)
    try:sys.exit(main(parser.parse_args()))
    except Exception:print(json.dumps({'failure_code':'MAINTENANCE_FAILED_READ_GRANT_BEFORE_ANY_RETRY','provider_calls':0}),flush=True);sys.exit(1)
