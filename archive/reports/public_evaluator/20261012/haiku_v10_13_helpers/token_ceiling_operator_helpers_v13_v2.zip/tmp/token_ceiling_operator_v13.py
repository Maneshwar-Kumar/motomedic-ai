"""Separately scoped owner-approved cap maintenance; import performs no cloud action."""
from copy import deepcopy
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile
from datetime import datetime,timezone
from urllib.parse import urlencode

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'));sys.path.insert(0,str(ROOT))
import submit_hosted_v10 as cloud
import public_cloud_run_v10_13 as run
from cloud.grounded_generation.token_ceiling import grant_from_owner_evidence
OUT=cloud.OUT/'haiku_v10_13_helpers/operator_v1'
MEMBER='serviceAccount:'+run.BACKEND_SA
GET_ROLE='projects/'+cloud.PROJECT+'/roles/motomedicSnapshotObjectGet'
TITLE='motomedic-backend-exact-token-ceiling-maintenance-v10-13-v1'
ARTIFACT_NAMES=frozenset(('application_receipt.json','application_receipt_application_pending.json','maintenance_receipt.json','exit_status.json'))
INVENTORY='tmp/token-ceiling-maintenance-v13/source_inventory.json'
DEPENDENCIES=('tools/manage_primary_token_ceiling.py','cloud/grounded_generation/token_ceiling.py',
    'cloud/grounded_generation/claude_budget.py','cloud/grounded_generation/__init__.py',
    'evidence_registry.py','generation_providers.py','generation_contracts.py','controller_contracts.py',
    'tmp/token_ceiling_maintenance_job_v13.py','reports/public_evaluator/20261012/serving_manifest_v10_13.json',
    'reports/public_evaluator/20261012/expected_runtime_lock_v10_13.json')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def write(name,value):
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/name).open('x',encoding='utf-8') as target:target.write(json.dumps(value,indent=2,sort_keys=True)+'\n')

def prepare_source(proposal_name,owner_name):
    if any((OUT/name).exists() for name in ('source_preparation.json','source_reference.json','source_grant.json','submission.json')):
        raise ValueError('NEVER_OVERWRITE_MAINTENANCE_SOURCE')
    paths=[]
    for name in (proposal_name,owner_name):
        path=(ROOT/name).resolve()
        if not path.is_relative_to(ROOT/'reports/public_evaluator/20261012') or path.suffix!='.json':raise ValueError('EXACT_PRIVATE_OWNER_AND_PROPOSAL_PATH_REQUIRED')
        paths.append(path.relative_to(ROOT).as_posix())
    proposal_path,owner_path=paths
    grant=grant_from_owner_evidence(json.loads((ROOT/proposal_path).read_bytes()),owner_evidence_raw=(ROOT/owner_path).read_bytes(),evidence_path=owner_path)
    manifest_path=ROOT/DEPENDENCIES[-2];manifest=json.loads(manifest_path.read_bytes())
    lock=json.loads((ROOT/DEPENDENCIES[-1]).read_bytes())['runtime_lock']
    if grant['measured']['serving_manifest_sha256']!=sha(manifest_path) or grant['measured']['runtime_lock']!=lock:
        raise ValueError('OWNER_GRANT_FROZEN_CANDIDATE_CHANGED')
    names=list(DEPENDENCIES)+paths;hashes={name:sha(ROOT/name) for name in names}
    for name,expected in hashes.items():
        if name in manifest['file_sha256'] and manifest['file_sha256'][name]!=expected:raise ValueError('FROZEN_MAINTENANCE_TOOL_CHANGED')
    inventory={'schema':'motomedic-token-ceiling-maintenance-source-inputs-v1','file_sha256':hashes,
        'serving_manifest_sha256':sha(manifest_path),'runtime_lock':lock,'proposal_path':proposal_path,
        'owner_evidence_path':owner_path,'owner_grant_scope_sha256':grant['scope_sha256'],'provider_calls':0}
    local=ROOT/INVENTORY;local.parent.mkdir(parents=True,exist_ok=True)
    with local.open('x',encoding='utf-8') as target:target.write(json.dumps(inventory,indent=2,sort_keys=True)+'\n')
    names.append(INVENTORY);hashes[INVENTORY]=sha(local)
    compressed=io.BytesIO()
    with gzip.GzipFile(fileobj=compressed,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as archive:
            for name in sorted(names):
                raw=(ROOT/name).read_bytes();row=tarfile.TarInfo(name);row.size=len(raw);row.mode=0o644;row.mtime=0;archive.addfile(row,io.BytesIO(raw))
    raw=compressed.getvalue();archive_sha=hashlib.sha256(raw).hexdigest();archive=ROOT/'tmp/token-ceiling-maintenance-v13/source.tar.gz'
    with archive.open('xb') as target:target.write(raw)
    result={'schema':'motomedic-token-ceiling-maintenance-preparation-v1','archive':archive.relative_to(ROOT).as_posix(),
        'sha256':archive_sha,'bytes':len(raw),'files':hashes,'inventory_sha256':hashes[INVENTORY],
        'serving_manifest_sha256':inventory['serving_manifest_sha256'],'runtime_lock':lock,
        'owner_grant_scope_sha256':grant['scope_sha256'],'object':'serving/engineering-maintenance/v10_13/'+archive_sha+'.tar.gz',
        'owner_approved':True,'cloud_actions':0,'provider_calls':0}
    write('source_preparation.json',result);return {'source_prepared':True,'sha256':archive_sha,'cloud_actions':0,'provider_calls':0}

def prepared():
    value=read('source_preparation.json')
    if sha(ROOT/value['archive'])!=value['sha256'] or any(sha(ROOT/name)!=expected for name,expected in value['files'].items()):
        raise ValueError('EXACT_MAINTENANCE_PREPARATION_CHANGED')
    return value

def upload_source():
    value=prepared();raw=(ROOT/value['archive']).read_bytes()
    url='https://storage.googleapis.com/upload/storage/v1/b/'+cloud.BUCKET+'/o?'+urlencode({'uploadType':'media','name':value['object'],'ifGenerationMatch':'0'})
    request=cloud.Request(url,data=raw,method='POST',headers={'Authorization':'Bearer '+cloud.token(),'Content-Type':'application/gzip'})
    with cloud.build_opener(cloud.NoRedirect()).open(request,timeout=60) as response:metadata=json.load(response)
    reference={**value,'generation':str(metadata['generation']),'uri':'gs://'+cloud.BUCKET+'/'+value['object']}
    from cloud.serving_artifacts import GCSReader,ObjectReference
    GCSReader(token=cloud.token).fetch(ObjectReference(uri=reference['uri'],generation=reference['generation'],
        sha256=reference['sha256'],maximum_bytes=reference['bytes']),ROOT/'tmp/token-ceiling-maintenance-v13/upload_readback.tar.gz')
    write('source_reference.json',reference);return {'source_uploaded':True,'generation':reference['generation'],'provider_calls':0}

def source_reference():
    preparation=prepared();source=read('source_reference.json')
    if any(source.get(key)!=value for key,value in preparation.items()):raise ValueError('MAINTENANCE_SOURCE_REFERENCE_CHANGED')
    return source

def source_policy(policy,source):
    if not policy.get('etag') or not re.fullmatch(r'serving/engineering-maintenance/v10_13/[0-9a-f]{64}\.tar\.gz',source['object']):
        raise ValueError('EXACT_MAINTENANCE_SOURCE_OR_ETAG_REQUIRED')
    if source['object'].split('/')[-1]!=source['sha256']+'.tar.gz' or any(row.get('condition',{}).get('title')==TITLE for row in policy.get('bindings',[])):
        raise ValueError('EXACT_NEW_MAINTENANCE_SOURCE_GRANT_REQUIRED')
    if any(set(row.get('members',[])).intersection({'allUsers','allAuthenticatedUsers'}) for row in policy.get('bindings',[])):
        raise ValueError('PRIVATE_MAINTENANCE_SOURCE_BUCKET_REQUIRED')
    updated=deepcopy(policy);updated['version']=3
    added={'role':GET_ROLE,'members':[MEMBER],'condition':{'title':TITLE,
        'expression':"resource.name == 'projects/_/buckets/"+cloud.BUCKET+'/objects/'+source['object']+"'",
        'description':'Read only exact owner-approved primary token-ceiling maintenance archive'}}
    updated.setdefault('bindings',[]).append(added);return updated,added

def grant_source():
    source=source_reference();endpoint='https://storage.googleapis.com/storage/v1/b/'+cloud.BUCKET+'/iam'
    policy=run.api('GET',endpoint+'?optionsRequestedPolicyVersion=3');updated,added=source_policy(policy,source)
    client_grant=json.loads((cloud.OUT/'operations/client_source_grant_v9.json').read_bytes())
    if client_grant['added_binding'] not in policy.get('bindings',[]):raise ValueError('EXACT_CLIENT9_GET_GRANT_MISSING')
    run.api('PUT',endpoint,updated);after=run.api('GET',endpoint+'?optionsRequestedPolicyVersion=3')
    if added not in after.get('bindings',[]) or sorted(digest(row) for row in after['bindings'] if row!=added)!=sorted(digest(row) for row in policy['bindings']):
        raise ValueError('MAINTENANCE_EXACT_GET_GRANT_READBACK_FAILED')
    write('source_grant.json',{'source':source,'added_binding':added,'all_previous_bindings_including_client9_and_artifact_creator_unchanged':True,
        'prior_policy_sha256':digest(policy),'readback_policy_sha256':digest(after),'provider_calls':0,'public_iam_changed':False})
    return {'exact_maintenance_source_get_granted':True,'client9_unchanged':True,'provider_calls':0}

def build_recipe(source,binding):
    if (binding.get('runtime_revision')!='v10_13' or binding.get('serving_manifest_sha256')!=source['serving_manifest_sha256'] or
        not re.fullmatch(r'[0-9]+',source.get('generation','')) or not re.fullmatch(r'[0-9a-f]{64}',source['sha256']) or
        source['object']!='serving/engineering-maintenance/v10_13/'+source['sha256']+'.tar.gz' or
        not re.fullmatch('us-central1-docker.pkg.dev/'+re.escape(cloud.PROJECT)+'/motomedic/arm-a@sha256:[0-9a-f]{64}',binding['images']['backend'])):
        raise ValueError('MAINTENANCE_EXACT_FROZEN_SOURCE_IMAGE_REQUIRED')
    output='tmp/token-ceiling-maintenance-v13-run/$BUILD_ID'
    return {'serviceAccount':'projects/'+cloud.PROJECT+'/serviceAccounts/'+run.BACKEND_SA,
        'source':{'storageSource':{'bucket':cloud.BUCKET,'object':source['object'],'generation':source['generation']}},
        'steps':[{'name':'docker.io/library/python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1',
            'entrypoint':'python','args':['-c','from pathlib import Path; p=Path("/workspace/'+output+'"); p.mkdir(parents=True,exist_ok=True); p.chmod(0o777)']},
            {'name':binding['images']['backend'],'entrypoint':'python','args':['-B','tmp/token_ceiling_maintenance_job_v13.py',
                '--inventory',INVENTORY,'--output','/workspace/'+output,'--allocated-job-id','$BUILD_ID',
                '--artifact-uri','gs://'+cloud.BUCKET+'/engineering-acceptance/public-v10_3/$BUILD_ID'],
                'env':['PYTHONPATH=/workspace:/app','MOTOMEDIC_HOSTED_TOKEN_LIMIT_MAINTENANCE=true','MOTOMEDIC_CLOUD_BUILD_ID=$BUILD_ID']}],
        'options':{'logging':'CLOUD_LOGGING_ONLY'},'timeout':'600s'}

def submit():
    source=source_reference();grant=read('source_grant.json')
    if (OUT/'submission.json').exists():raise ValueError('MAINTENANCE_SUBMISSION_EXISTS_USE_POLL')
    if grant['source']!=source:raise ValueError('MAINTENANCE_SOURCE_GET_BINDING_CHANGED')
    binding=json.loads((cloud.OUT/'hosted_image_binding_v10_13.json').read_bytes());config=build_recipe(source,binding)
    operation=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds',config)
    write('submission.json',{'config':config,'operation':operation,'provider_calls':0})
    return {'id':operation['metadata']['build']['id'],'provider_calls':0}

def poll():
    job=read('submission.json')['operation']['metadata']['build']['id'];result=cloud.api('https://cloudbuild.googleapis.com/v1/projects/'+cloud.PROJECT+'/builds/'+job)
    name='build_readback_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json'
    write(name,result);return {'id':job,'status':result['status'],'readback':name,'provider_calls':0}

def logs():
    job=read('submission.json')['operation']['metadata']['build']['id']
    if not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',job):raise ValueError('EXACT_MAINTENANCE_BUILD_ID_REQUIRED')
    result=cloud.api('https://logging.googleapis.com/v2/entries:list',{'resourceNames':['projects/'+cloud.PROJECT],
        'filter':'resource.type="build" AND resource.labels.build_id="'+job+'"','orderBy':'timestamp desc','pageSize':500})
    records=[]
    for row in result.get('entries',[]):
        value=row.get('jsonPayload')
        if not isinstance(value,dict):
            text=row.get('textPayload','')
            try:value=json.loads(text[text.find('{'):])
            except (ValueError,TypeError):continue
        if not isinstance(value,dict) or value.get('artifact_file') not in ARTIFACT_NAMES:continue
        if not re.fullmatch(r'[0-9]+',str(value.get('generation',''))) or not re.fullmatch(r'[0-9a-f]{64}',value.get('sha256','')):
            raise ValueError('MAINTENANCE_ARTIFACT_LOG_BINDING_INVALID')
        records.append({'timestamp':row.get('timestamp'),'artifact_file':value['artifact_file'],
            'generation':str(value['generation']),'sha256':value['sha256']})
    name='artifact_logs_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json'
    write(name,{'schema':'motomedic-maintenance-artifact-log-inventory-v1','cloud_build_id':job,'records':records,
        'raw_logs_saved':False,'provider_calls':0})
    return {'id':job,'artifact_records':len(records),'log_inventory':name,'provider_calls':0}

def download():
    job=read('submission.json')['operation']['metadata']['build']['id']
    if not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',job):raise ValueError('EXACT_MAINTENANCE_BUILD_ID_REQUIRED')
    inventories=sorted(OUT.glob('artifact_logs_*.json'))
    if not inventories:raise ValueError('READ_MAINTENANCE_ARTIFACT_LOGS_FIRST')
    inventory_path=inventories[-1];inventory=json.loads(inventory_path.read_bytes())
    if inventory.get('schema')!='motomedic-maintenance-artifact-log-inventory-v1' or inventory.get('cloud_build_id')!=job:raise ValueError('EXACT_MAINTENANCE_ARTIFACT_JOB_REQUIRED')
    records={}
    for row in inventory['records']:
        name=row['artifact_file']
        if name not in ARTIFACT_NAMES or not re.fullmatch(r'[0-9]+',row.get('generation','')) or not re.fullmatch(r'[0-9a-f]{64}',row.get('sha256','')):
            raise ValueError('EXACT_MAINTENANCE_ARTIFACT_REFERENCE_REQUIRED')
        if name in records and any(records[name][key]!=row[key] for key in ('generation','sha256')):
            raise ValueError('CONFLICTING_MAINTENANCE_ARTIFACT_GENERATION')
        records[name]=row
    if not {'maintenance_receipt.json','exit_status.json'}.issubset(records):raise ValueError('MAINTENANCE_EXIT_AND_RECEIPT_ARTIFACTS_REQUIRED')
    output=OUT/'hosted_runs'/job
    if output.exists():raise ValueError('NEVER_OVERWRITE_MAINTENANCE_DOWNLOADED_ARTIFACTS')
    output.mkdir(parents=True)
    from cloud.serving_artifacts import GCSReader,ObjectReference
    files={}
    for name,row in sorted(records.items()):
        reference=ObjectReference(uri='gs://'+cloud.BUCKET+'/engineering-acceptance/public-v10_3/'+job+'/'+name,
            generation=row['generation'],sha256=row['sha256'],maximum_bytes=2*1024*1024)
        GCSReader(token=cloud.token).fetch(reference,output/name)
        files[name]={'generation':row['generation'],'sha256':row['sha256'],'bytes':(output/name).stat().st_size}
    with (output/'download_inventory.json').open('x',encoding='utf-8') as target:
        json.dump({'schema':'motomedic-maintenance-download-inventory-v1','cloud_build_id':job,'files':files,
            'log_inventory_sha256':sha(inventory_path),'artifact_prefix':'engineering-acceptance/public-v10_3/'+job+'/',
            'provider_calls':0},target,indent=2,sort_keys=True);target.write('\n')
    return {'id':job,'files':files,'provider_calls':0}

if __name__=='__main__':
    if sys.argv[1:]==['--check-only']:print(json.dumps({'actions':['prepare_source','upload_source','grant_source','submit','poll','logs','download'],
        'no_secret_or_model_requests':True,'no_automatic_execution':True,'exact_owner_grant_evidence_required':True,'provider_calls':0}))
    elif len(sys.argv)==4 and sys.argv[1]=='prepare_source':print(json.dumps(prepare_source(sys.argv[2],sys.argv[3])))
    elif len(sys.argv)==2 and sys.argv[1] in ('upload_source','grant_source','submit','poll','logs','download'):print(json.dumps(globals()[sys.argv[1]]()))
    else:raise SystemExit('ONE_FIXED_OWNER_APPROVED_MAINTENANCE_ACTION_REQUIRED')
