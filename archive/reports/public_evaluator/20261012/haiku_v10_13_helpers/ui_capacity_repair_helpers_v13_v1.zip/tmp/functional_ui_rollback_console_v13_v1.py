"""Fixed UI-only rollback/restore with the latest browser charges as a floor."""
import hashlib,json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tmp'))
import functional_ui_promotion_v13_v2 as promote
OUT=promote.OUT/'rollback_cycle_v1'
MANIFEST=promote.cloud.OUT/'haiku_v10_13_helpers/functional_ui_promotion_helpers_v13_v2_manifest.json'
BASE=promote.OUT/'enabled_browser.json'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
ENTRY_SHA='cd73163fdc1cf0e0216ef0a781c4cc25204d7cc25a1c5a8a5ef5fe47155e4627'
# The initial browser receipt is immutable and binds both baseline charge ledgers.
BASE_SHA='8187e2ff4dc0689e2f169adb442a150af05fb32fa079138c117d99c1920a0374'
ACTIONS={'route_paused':('route','paused_rollback'),'health_paused':('health','paused_rollback'),
    'browser_paused':('browser','paused'),'route_enabled_restore':('route','enabled_restore'),
    'health_enabled_restore':('health','enabled_restore')}

def bound_baseline():
    if sha(ROOT/'tmp/functional_ui_promotion_v13_v2.py')!=ENTRY_SHA or sha(BASE)!=BASE_SHA:
        raise ValueError('EXACT_REVIEWED_OPERATOR_OR_COMPLETED_PUBLIC_BROWSER_BINDING_CHANGED')
    value=json.loads(BASE.read_bytes());ledger=value['provider_ledger_after']
    if (value.get('public_browser_passed')is not True or value.get('core_and_public_iam_unchanged_after_browser')is not True or
        value.get('routed_ui_after_browser',{}).get('revision')!=promote.ENABLED or
        ledger.get('reserved_attempts')!=34 or ledger.get('reserved_tokens')!=549094 or ledger.get('reserved_nanodollars')!=56954750):
        raise ValueError('EXACT_COMPLETED_PUBLIC_BROWSER_CHARGE_MINIMUM_REQUIRED')
    promote.require_retained_ledger(ledger,ledger)
    for action in ACTIONS:
        path=OUT/(action+'.json')
        if path.exists():
            recorded=json.loads(path.read_bytes())
            if (recorded.get('action')!=action or recorded.get('operator_entry_sha256')!=ENTRY_SHA or
                recorded.get('public_browser_baseline')!={'path':BASE.relative_to(ROOT).as_posix(),'sha256':BASE_SHA}):
                raise ValueError('IMMUTABLE_PRIOR_ROLLBACK_ACTION_BINDING_CHANGED')
            promote.require_retained_ledger(ledger,recorded['provider_ledger_after']);ledger=recorded['provider_ledger_after']
    return ledger

def execute(action):
    if action not in ACTIONS:raise ValueError('FIXED_UI_ONLY_ROLLBACK_RESTORE_ACTION_REQUIRED')
    destination=OUT/(action+'.json')
    if destination.exists():raise ValueError('NEVER_REPEAT_OR_OVERWRITE_COMPLETED_ROLLBACK_ACTION')
    baseline=bound_baseline();before=promote.ledger_state();promote.require_retained_ledger(baseline,before)
    kind,stage=ACTIONS[action]
    result=getattr(promote,kind)(stage)
    after=promote.ledger_state();promote.require_retained_ledger(before,after)
    promote.require_retained_ledger(baseline,after)
    if kind=='health' and result.get('health_ready')is not True:return result
    OUT.mkdir(parents=True,exist_ok=True)
    with destination.open('x',encoding='utf-8') as target:
        json.dump({'schema':'motomedic-ui-paused-rollback-restore-action-v1','action':action,'result':result,
            'public_browser_baseline':{'path':BASE.relative_to(ROOT).as_posix(),'sha256':BASE_SHA},
            'operator_entry_sha256':ENTRY_SHA,'provider_ledger_before':before,'provider_ledger_after':after,
            'latest_completed_public_browser_charges_retained':True,'provider_calls_by_this_action':0,
            'only_ui_traffic_rollback_or_restore_or_read_only_observation':True,'independent_factual_quality_acceptance':False},
            target,indent=2,sort_keys=True);target.write('\n')
    return result

if __name__=='__main__':
    promote.cloud.token=promote.console.token
    if sys.argv[1:]==['--check-only']:
        baseline=bound_baseline();print(json.dumps({'actions':list(ACTIONS),'cloud_calls':0,'provider_calls':0,
            'baseline':{key:baseline[key] for key in ('reserved_attempts','reserved_tokens','reserved_nanodollars','reservation_count')},
            'enabled_browser_sha256':BASE_SHA,'operator_entry_sha256':ENTRY_SHA}))
    elif len(sys.argv)==2:print(json.dumps(execute(sys.argv[1])))
    else:raise SystemExit('ONE_FIXED_UI_ONLY_ROLLBACK_ACTION_REQUIRED')
