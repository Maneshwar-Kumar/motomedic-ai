"""Necessary public availability repair: UI Service max1->2; no other scope."""
from copy import deepcopy
from datetime import datetime,timedelta,timezone
import hashlib,json
from pathlib import Path
import sys
from urllib.parse import urlencode

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tmp'))
import functional_ui_guard_bridge_v13_v1 as bridge
promote=bridge.promote;run=promote.run
OUT=promote.cloud.OUT/'haiku_v10_13_helpers/ui_capacity_repair_v1'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def write(name,value):
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/name).open('x',encoding='utf-8') as target:json.dump(value,target,indent=2,sort_keys=True);target.write('\n')
def absent(name):
    if (OUT/name).exists():raise ValueError('NEVER_OVERWRITE_OR_REPEAT_UI_CAPACITY_REPAIR')
def target_configuration(before):
    if before.get('scaling')!={'maxInstanceCount':1}:raise ValueError('EXACT_PREEXISTING_UI_SERVICE_MAX_ONE_REQUIRED')
    after=deepcopy(before);after['scaling']['maxInstanceCount']=2;return after
def require_only_service_max_delta(before,after):
    if target_configuration(before)!=after:raise ValueError('ONLY_UI_SERVICE_MAX_ONE_TO_TWO_CONFIGURATION_DELTA_ALLOWED')
    return True

def current(expected_service_configuration=None,minimum_ledger=None):
    initial=promote.read('initial.json');binding,_=promote.rollback.release()
    if binding!=initial['binding'] or promote.functional_evidence(binding)!=initial['functional_evidence']:
        raise ValueError('FROZEN_RUNTIME_OR_EXACT_DIRECT_ENABLEMENT_SCOPE_CHANGED')
    guard=bridge.guard_bridge(initial)
    core=promote.core_rows(binding);iam=promote.policies()
    if core!=initial['core'] or iam!=initial['public_iam']:raise ValueError('CORE_OR_PUBLIC_IAM_CHANGED')
    service=run.api('GET',run.PREFIX+promote.UI);promote.rollback.require_service(promote.UI,service,binding)
    config=promote.ui_service_configuration(service)
    expected=expected_service_configuration or initial['ui']['service_configuration']
    if config!=expected:raise ValueError('EXACT_UI_SERVICE_CONFIGURATION_NOT_EXPECTED_CAPACITY_STATE')
    routed=promote.require_routed_ui('enabled_restore',initial,binding)
    candidate=promote.read('candidate_ready.json')['ui'];material=candidate['revision_configuration']
    if material.get('scaling')!={'maxInstanceCount':1}:raise ValueError('UI_REVISION_MAX_ONE_UNCHANGED_REQUIRED')
    ledger=promote.ledger_state();promote.require_retained_ledger(bridge.console.bound_baseline(),ledger)
    if minimum_ledger is not None:promote.require_retained_ledger(minimum_ledger,ledger)
    return service,{'binding':binding,'source_evidence':initial['functional_evidence'],'fresh_guard_bridge':guard,
        'ui_service_configuration':config,'ui_template_sha256':promote.rollback.digest(service['template']),
        'latestCreatedRevision':service.get('latestCreatedRevision'),'latestReadyRevision':service.get('latestReadyRevision'),
        'routed_ui':routed,'core':core,'public_iam':iam,'provider_ledger':ledger}

def prepare():
    absent('initial.json');service,value=current()
    if not service.get('etag'):raise ValueError('CURRENT_UI_SERVICE_ETAG_REQUIRED')
    value.update(schema='motomedic-ui-service-capacity-repair-initial-v1',etag=service['etag'],
        required_target_service_configuration=target_configuration(value['ui_service_configuration']),
        authorization_basis='COORDINATOR_NECESSARY_REVERSIBLE_IMPLEMENTATION_FOR_OWNER_AUTHORIZED_WORKING_PUBLIC_UI',
        explicit_owner_max_two_instruction_claimed=False,cloud_mutations_by_prepare=0,provider_calls=0)
    write('initial.json',value);return {'prepared':True,'service_max_delta':'1->2','revision_max_unchanged':1,'provider_calls':0}

def apply():
    absent('submission.json');absent('intent.json');initial=read('initial.json')
    service,value=current(initial['ui_service_configuration'],initial['provider_ledger'])
    if service.get('etag')!=initial['etag']:raise ValueError('UI_CONCURRENT_SERVICE_MUTATION_DETECTED')
    request={'etag':service['etag'],'scaling':deepcopy(initial['required_target_service_configuration']['scaling'])}
    write('intent.json',{'schema':'motomedic-ui-capacity-repair-intent-v1','request':request,'updateMask':'scaling',
        'initial_sha256':sha(OUT/'initial.json'),'only_service_max_one_to_two':True,'revision_traffic_env_image_iam_core_provider_billing_changes':False})
    operation=run.api('PATCH',run.PREFIX+promote.UI+'?updateMask=scaling',request)
    write('submission.json',{'request':request,'operation':operation,'provider_calls':0});return {'submitted':True,'only_service_max_changed':True}

def status():
    initial=read('initial.json');saved=read('submission.json')
    operation=run.api('GET','https://run.googleapis.com/v2/'+saved['operation']['name'])
    if operation.get('done')is not True:return {'ready':False,'provider_calls':0}
    if operation.get('error'):raise ValueError('UI_SERVICE_MAX_CAPACITY_REPAIR_FAILED')
    service,value=current(initial['required_target_service_configuration'],initial['provider_ledger'])
    require_only_service_max_delta(initial['ui_service_configuration'],value['ui_service_configuration'])
    for key in ('binding','source_evidence','fresh_guard_bridge','ui_template_sha256','latestCreatedRevision','latestReadyRevision','routed_ui','core','public_iam'):
        if value[key]!=initial[key]:raise ValueError('NONSCALING_CONFIGURATION_OR_REVISION_CHANGED_DURING_REPAIR')
    value.update(schema='motomedic-ui-capacity-repair-actual-readback-v1',only_service_max_changed=True,provider_calls=0,
        independent_factual_quality_acceptance=False,actual_public_health_acceptance=False)
    if not (OUT/'readback.json').exists():write('readback.json',value)
    return {'ready':True,'service_max':2,'revision_max':1,'routed_revision':value['routed_ui']['revision'],'provider_calls':0}

def health():
    absent('health_passed.json');initial=read('initial.json');read('readback.json')
    service,value=current(initial['required_target_service_configuration'],initial['provider_ledger'])
    result=promote.rollback.get_health(promote.UI,service,initial['binding'],url=promote.preview.URL)
    _,after=current(initial['required_target_service_configuration'],value['provider_ledger'])
    write('health_passed.json',{'schema':'motomedic-ui-capacity-repair-anonymous-health-v1','http_health':result,
        'routed_ui':after['routed_ui'],'service_scaling':after['ui_service_configuration']['scaling'],
        'revision_max_unchanged':1,'core_and_public_iam_preserved':True,'provider_ledger_before':value['provider_ledger'],
        'provider_ledger_after':after['provider_ledger'],'provider_calls_by_health_check':0,
        'explicit_owner_max_two_instruction_claimed':False,'independent_factual_quality_acceptance':False})
    return {'anonymous_public_health_passed':True,'provider_calls':0,'routed_revision':after['routed_ui']['revision']}

def metric():
    now=datetime.now(timezone.utc);query=urlencode({'filter':'metric.type="run.googleapis.com/container/instance_count" AND resource.type="cloud_run_revision" AND resource.labels.service_name="motomedic-rider-ui"',
        'interval.startTime':(now-timedelta(minutes=20)).isoformat(),'interval.endTime':now.isoformat(),'pageSize':1000})
    body=run.api('GET','https://monitoring.googleapis.com/v3/projects/'+promote.cloud.PROJECT+'/timeSeries?'+query)
    records=[]
    for series in body.get('timeSeries',[]):
        for point in series.get('points',[])[:3]:
            records.append({'revision':series.get('resource',{}).get('labels',{}).get('revision_name'),
                'state':series.get('metric',{}).get('labels',{}).get('state'),
                'endTime':point.get('interval',{}).get('endTime'),'value':point.get('value',{})})
    result={'schema':'motomedic-ui-capacity-instance-metric-readonly-v1','records':records,'provider_calls':0,'cloud_writes':0,
        'delayed_metrics_do_not_prove_current_concurrency':True}
    if not (OUT/'instance_metric.json').exists():write('instance_metric.json',result)
    return result

if __name__=='__main__':
    promote.cloud.token=promote.console.token
    if sys.argv[1:]==['--check-only']:print(json.dumps({'actions':['metric','prepare','apply','status','health'],
        'cloud_calls':0,'provider_calls':0,'explicit_owner_max_two_instruction_claimed':False,'only_ui_service_max_delta':'1->2'}))
    elif len(sys.argv)==2 and sys.argv[1]in ('metric','prepare','apply','status','health'):print(json.dumps(globals()[sys.argv[1]]()))
    else:raise SystemExit('ONE_FIXED_UI_SERVICE_CAPACITY_REPAIR_ACTION_REQUIRED')
