"""Synthetic functional promotion boundaries; no cloud or provider calls."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tmp'))
import functional_ui_promotion_v13_v2 as promote

class FunctionalPromotionTests(unittest.TestCase):
    def configuration(self):
        # Actual reviewed v13 UI material; Service-derived launchStage stays bound.
        ready=json.loads((promote.cloud.OUT/'private_readiness_v10_13_v2.json').read_bytes())
        return deepcopy(ready['services'][promote.UI]['revision_configuration'])
    def template(self,configuration):
        result=deepcopy(configuration);result.pop('launchStage',None)
        result['revision']='paused-exact';result['annotations']={'preserved':'exact'}
        return result
    def ledger(self):
        return {'maximum_tokens':2000000,'token_ceiling_authorization':{'scope_sha256':'a'*64},
            'immutable_non_charge_field_sha256':{'primary':'a'*64,'shared':'b'*64,'grant':'c'*64,'global':'d'*64},
            'reserved_attempts':10,'reserved_tokens':500000,'reserved_nanodollars':200000000,'reservation_count':4}
    def binding(self):
        return {'serving_manifest_sha256':'a'*64,'runtime_lock':'b'*64,'images':{'backend':'backend@sha256:'+'c'*64,'ui':'ui@sha256:'+'d'*64}}
    def test_candidate_changes_only_answer_flag_and_never_writes_launchstage_inside_template(self):
        paused=self.configuration();before=deepcopy(paused);template=self.template(paused)
        declared,actual=promote.candidate_template(template,paused)
        self.assertEqual(paused,before);self.assertNotIn('launchStage',declared)
        self.assertEqual(actual['launchStage'],before['launchStage']);self.assertEqual(declared['revision'],promote.ENABLED)
        self.assertEqual(declared['annotations'],template['annotations'])
        self.assertTrue(promote.require_only_flag_delta(before,actual))
        # Complete material hashes still bind fields that aren't writable input.
        actual['launchStage']='BETA'
        with self.assertRaises(ValueError):promote.require_only_flag_delta(before,actual)
    def test_secret_identity_scaling_network_resources_and_extra_material_delta_reject(self):
        paused=self.configuration();enabled=promote.enabled_configuration(paused)
        for changed in ('image','secret','serviceAccount','scaling','cpu','network','timeout','env','unknown'):
            value=deepcopy(enabled)
            if changed=='image':value['containers'][0]['image']='unbound'
            elif changed=='secret':next(row for row in value['containers'][0]['env'] if 'valueSource'in row)['valueSource']['secretKeyRef']['version']='latest'
            elif changed=='cpu':value['containers'][0]['resources']['limits']['cpu']='2'
            elif changed=='env':value['containers'][0]['env'].append({'name':'NEW_ENV','value':'new'})
            elif changed=='network':value['vpcAccess']={'connector':'changed'}
            elif changed=='scaling':value['scaling']['maxInstanceCount']=2
            else:value[changed]='changed'
            with self.subTest(changed=changed),self.assertRaises(ValueError):promote.require_only_flag_delta(paused,value)
        bad=deepcopy(paused);bad['unreviewedRevisionField']=True
        with self.assertRaises(ValueError):promote.candidate_template(self.template(paused),bad)
    def test_duplicate_secret_derived_missing_or_nonboolean_flag_reject(self):
        for mutation in ('duplicate','secret','missing','case'):
            paused=self.configuration();rows=paused['containers'][0]['env'];row=next(row for row in rows if row['name']==promote.FLAG)
            if mutation=='duplicate':rows.append(deepcopy(row))
            elif mutation=='secret':row.pop('value');row['valueSource']={'secretKeyRef':{'secret':'arbitrary','version':'1'}}
            elif mutation=='missing':rows.remove(row)
            else:row['value']='FALSE'
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):promote.enabled_configuration(paused)
    def test_monotonic_bounded_public_usage_retains_rollback_but_exact_creation_rejects_growth(self):
        before=self.ledger();after=deepcopy(before)
        for key in ('reserved_attempts','reserved_tokens','reserved_nanodollars','reservation_count'):after[key]+=1
        self.assertTrue(promote.require_retained_ledger(before,after))
        with self.assertRaises(ValueError):promote.require_retained_ledger(before,after,exact_charges=True)
    def test_charge_refund_caps_authorization_static_bindings_and_malformed_counters_reject(self):
        for mutation in ('refund','cap','grant','static','attempt_exceeded','token_exceeded','dollar_exceeded','boolean'):
            before=self.ledger();after=deepcopy(before)
            if mutation=='refund':after['reserved_nanodollars']-=1
            elif mutation=='cap':after['maximum_tokens']=3000000
            elif mutation=='grant':after['token_ceiling_authorization']['scope_sha256']='f'*64
            elif mutation=='static':after['immutable_non_charge_field_sha256']['global']='f'*64
            elif mutation=='attempt_exceeded':after['reserved_attempts']=101
            elif mutation=='token_exceeded':after['reserved_tokens']=2000001
            elif mutation=='dollar_exceeded':after['reserved_nanodollars']=1000000001
            else:after['reserved_attempts']=True
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):promote.require_retained_ledger(before,after)
    def test_owner_waiver_is_exact_and_does_not_waive_source_or_runtime_verifier(self):
        binding,_=promote.rollback.release()
        with patch.object(promote.run,'api') as api:
            waiver=promote.owner_waiver(binding);self.assertEqual(waiver['sha256'],promote.WAIVER_SHA);api.assert_not_called()
        value=json.loads(promote.WAIVER.read_bytes());value['runtime_semantic_verifier_bypass_authorized']=True
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory:
            path=Path(directory)/'changed.json';path.write_text(json.dumps(value),encoding='utf-8')
            with patch.object(promote,'WAIVER',path),patch.object(promote,'WAIVER_SHA',promote.sha(path)),self.assertRaises(ValueError):
                promote.owner_waiver(binding)
    def test_preflight_unknown_route_browser_modes_and_overwrite_reject_without_requests(self):
        with patch.object(promote.run,'api') as api:
            for action in (promote.route,promote.health,promote.browser,promote.browser_paths):
                with self.assertRaises(ValueError):action('other')
            api.assert_not_called()
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(promote,'OUT',Path(directory)):
            promote.write('existing.json',{'immutable':True})
            with self.assertRaises(FileExistsError):promote.write('existing.json',{'changed':True})
            with self.assertRaises(ValueError):promote.absent('existing.json')
    def test_ui_service_auth_ingress_scaling_and_audiences_are_separate_exact_bindings(self):
        service={'ingress':'INGRESS_TRAFFIC_ALL','launchStage':'GA','scaling':{'maxInstanceCount':1},
            'invokerIamDisabled':False,'customAudiences':['exact'],'annotations':{'exact':'a'},
            'etag':'mutable-output','traffic':[],'latestReadyRevision':'mutable-output'}
        baseline=promote.ui_service_configuration(service)
        self.assertNotIn('etag',baseline);self.assertNotIn('traffic',baseline)
        for key in ('ingress','launchStage','scaling','invokerIamDisabled','customAudiences','annotations'):
            changed=deepcopy(service);changed[key]='changed'
            self.assertNotEqual(promote.ui_service_configuration(changed),baseline)
    def test_create_journals_exact_ui_only_patch_and_retains_paused_traffic(self):
        binding=self.binding();paused=self.configuration();template=self.template(paused)
        row={'revision':'paused-exact','template':template,'revision_configuration':paused,
            'revision_configuration_sha256':promote.rollback.digest(paused),'service_scaling':{'maxInstanceCount':1},
            'service_configuration':{'launchStage':'GA'}}
        initial={'ui':row};service={'etag':'exact-ui-etag'}
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(promote,'OUT',Path(directory)),\
            patch.object(promote,'read',return_value=initial),patch.object(promote,'check_unchanged',return_value=binding),\
            patch.object(promote,'current_ui',return_value=(service,row)),\
            patch.object(promote,'sha',return_value='a'*64),patch.object(promote.run,'api',return_value={'name':'operation'}) as api:
            self.assertTrue(promote.create()['traffic_remains_paused'])
            api.assert_called_once();method,url,request=api.call_args.args
            self.assertEqual(method,'PATCH');self.assertEqual(url,promote.run.PREFIX+promote.UI+'?updateMask=template,traffic')
            self.assertEqual(request['etag'],'exact-ui-etag');self.assertNotIn('launchStage',request['template'])
            self.assertEqual(request['traffic'],[{'type':'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION','revision':'paused-exact','percent':100}])
            self.assertTrue((Path(directory)/'candidate_intent.json').exists())
            self.assertTrue((Path(directory)/'candidate_submission.json').exists())
    def test_staged_candidate_binds_exact_ready_actual_revision_not_latest_ready_output(self):
        binding=self.binding();paused=self.configuration();template=self.template(paused)
        declared,enabled=promote.candidate_template(template,paused)
        initial={'binding':binding,'ui':{'revision':'paused-exact','revision_configuration':paused,'service_scaling':{'maxInstanceCount':1}}}
        saved={'operation':{'name':'operation'},'request':{'template':declared}}
        service={'trafficStatuses':[{'revision':'paused-exact','percent':100}],'latestCreatedRevision':promote.ENABLED,
            'latestReadyRevision':'unrelated-misleading-output','template':declared,'scaling':{'maxInstanceCount':1}}
        actual=deepcopy(enabled);actual.update(name=promote.ENABLED,conditions=[{'type':'Ready','state':'CONDITION_SUCCEEDED'}])
        records={'initial.json':initial,'candidate_submission.json':saved}
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(promote,'OUT',Path(directory)),\
            patch.object(promote,'read',side_effect=lambda name:records[name]),patch.object(promote,'check_unchanged',return_value=binding),\
            patch.object(promote.rollback,'require_service'),\
            patch.object(promote.run,'api',side_effect=[{'done':True},service,actual]):
            self.assertTrue(promote.candidate_status()['candidate_ready'])
            self.assertTrue((Path(directory)/'candidate_ready.json').exists())
        actual['scaling']['maxInstanceCount']=5
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(promote,'OUT',Path(directory)),\
            patch.object(promote,'read',side_effect=lambda name:records[name]),patch.object(promote,'check_unchanged',return_value=binding),\
            patch.object(promote.rollback,'require_service'),\
            patch.object(promote.run,'api',side_effect=[{'done':True},service,actual]),self.assertRaises(ValueError):
            promote.candidate_status()
    def test_paused_rollback_uses_original_material_flag_and_traffic_only_patch(self):
        paused=self.configuration();template=self.template(paused)
        row={'revision':'paused-exact','template':template,'revision_configuration':paused,
            'revision_configuration_sha256':promote.rollback.digest(paused)}
        records={'initial.json':{'ui':row},'enabled_health.json':{},'candidate_ready.json':{}}
        service={'etag':'exact-current','trafficStatuses':[{'revision':promote.ENABLED,'percent':100}]}
        actual=deepcopy(paused);actual.update(name='paused-exact',conditions=[{'type':'Ready','state':'CONDITION_SUCCEEDED'}])
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(promote,'OUT',Path(directory)),\
            patch.object(promote,'read',side_effect=lambda name:records[name]),patch.object(promote,'check_unchanged',return_value=self.binding()),\
            patch.object(promote.rollback,'require_service'),\
            patch.object(promote.run,'api',side_effect=[service,actual,{'name':'operation'}]) as api:
            self.assertEqual(promote.route('paused_rollback')['target_revision'],'paused-exact')
            method,url,request=api.call_args.args
            self.assertEqual(method,'PATCH');self.assertEqual(url,promote.run.PREFIX+promote.UI+'?updateMask=traffic')
            self.assertEqual(set(request),{'etag','traffic'});self.assertEqual(request['traffic'][0]['revision'],'paused-exact')
            self.assertEqual(sum(call.args[0]!='GET' for call in api.call_args_list),1)

    def actual_direct(self):
        import importlib.util
        directory=promote.cloud.OUT/'hosted_runs/a77d5e33-4419-4d5c-855b-cb8bc2c98690'
        row=json.loads((directory/'EVAL_DIRECT_01.json').read_bytes());receipt=json.loads((directory/'receipt.json').read_bytes())
        path=promote.cloud.OUT/'haiku_v10_13_runtime/audit_hosted_delivery_cache_v3.py'
        spec=importlib.util.spec_from_file_location('v2_direct_test_auditor',path)
        auditor=importlib.util.module_from_spec(spec);spec.loader.exec_module(auditor)
        release,_=auditor.read(promote.cloud.OUT/'serving_manifest_v10_13.json')
        return row,release,receipt,auditor
    def test_actual_supported_direct_proof_and_partial_run_are_honestly_bound_without_network(self):
        binding,_=promote.rollback.release()
        with patch.object(promote.run,'api') as api:
            evidence=promote.functional_evidence(binding);api.assert_not_called()
        self.assertTrue(evidence['direct_proof']['separate_exact_finalized_response_verifier_passed'])
        self.assertTrue(evidence['direct_proof']['saved_stream_and_recovery_identical'])
        self.assertFalse(evidence['six_case_acceptance_claimed']);self.assertEqual(evidence['known_usb_case_outcome'],'SYSTEM_ERROR')
        self.assertFalse(evidence['direct_proof']['cache_creation_then_read_proof_required_before_enablement'])
        self.assertFalse(evidence['independent_factual_quality_acceptance'])
    def test_wrong_route_finalized_text_binding_or_native_schema_cannot_authorize_enablement(self):
        for mutation in ('route','text','binding','schema'):
            row,release,receipt,auditor=self.actual_direct();value=deepcopy(row)
            if mutation=='route':value['route']='SYSTEM_ERROR'
            elif mutation=='text':value['saved_view']['response']['natural_language']+=' CHANGED'
            elif mutation=='binding':value['saved_view']['verified_delivery']['binding_sha256']='0'*64
            else:value['saved_view']['runtime_controls']['composition']['attempts'][0]['verification_provider']['native_role_schema_sha256']='0'*64
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):
                promote.direct_case_proof(value,release,receipt,auditor)

if __name__=='__main__':unittest.main()
