"""Separate owner-waived functional promotion; legacy factual gates stay intact."""
from copy import deepcopy
from datetime import datetime,timezone
import importlib.util
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'));sys.path.insert(0,str(ROOT/'tmp/public_evaluator'))
import public_cloud_run_v10_13_v2 as run
import private_acceptance_console_v10_13_v2 as console
import rollback_public_v10_13 as rollback
import public_core_inspection_v13_v3 as core
import public_ui_preview_v13_v2 as preview
from hosted_client_v10_13_v2 import firestore_value
from cloud.grounded_generation.token_ceiling import GRANT_DOCUMENT,resolve_token_ceiling
cloud=run.cloud
OUT=cloud.OUT/'haiku_v10_13_helpers/functional_ui_promotion_v2'
UI='motomedic-rider-ui'
ENABLED=UI+'-v10-13-functional-enabled'
FLAG='MOTOMEDIC_RIDER_ANSWERS_ENABLED'
WAIVER=cloud.OUT/'public_review/owner_public_answer_enablement_scope_v1.json'
WAIVER_SHA='e9911c739d0609d45b9956c8e118459f63513a914f141a1a4756305a0375de54'
ACCEPTANCE=cloud.OUT/'haiku_v10_13_runtime/functional_operational_acceptance_v1.json'
CASE_IDS=('EVAL_DIRECT_01','EVAL_USB_02','EVAL_FOLLOWUP_03','EVAL_TOPIC_TABLE_04','EVAL_PARTIAL_05','EVAL_UNSUPPORTED_06')
PRIMARY='grounded-primary-nonrecurring-v1'
MONEY='owner-haiku-fallback-20261011-validation-v1'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def write(name,value):
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/name).open('x',encoding='utf-8') as target:json.dump(value,target,indent=2,sort_keys=True);target.write('\n')
def absent(*names):
    if any((OUT/name).exists() for name in names):raise ValueError('NEVER_OVERWRITE_FUNCTIONAL_PROMOTION_RECEIPT')

def file_reference(path):return {'path':path.relative_to(ROOT).as_posix(),'sha256':sha(path)}
def bound_file(reference):
    if type(reference)is not dict or type(reference.get('path'))is not str or not re.fullmatch(r'[0-9a-f]{64}',reference.get('sha256','')):
        raise ValueError('EXACT_BOUND_FUNCTIONAL_RECEIPT_REFERENCE_REQUIRED')
    path=(ROOT/reference['path']).resolve()
    if not path.is_relative_to(cloud.OUT) or sha(path)!=reference['sha256']:
        raise ValueError('FUNCTIONAL_RECEIPT_PATH_OR_HASH_CHANGED')
    return path,json.loads(path.read_bytes())

def owner_waiver(binding):
    if sha(WAIVER)!=WAIVER_SHA:raise ValueError('EXACT_DIRECT_OWNER_PUBLIC_ENABLEMENT_CHANGED')
    value=json.loads(WAIVER.read_bytes());candidate=value.get('frozen_candidate',{})
    true=('owner_authorized','public_ui_answers_enabled_authorized','enablement_before_complete_six_case_run_authorized',
        'immutable_source_bindings_required','runtime_semantic_verifier_required','remaining_functional_checks_pending')
    false=('independent_factual_quality_acceptance','human_factual_signoff','runtime_semantic_verifier_bypass_authorized',
        'six_case_functional_acceptance_claimed')
    if (value.get('schema')!='motomedic-direct-owner-public-answer-enablement-scope-v1' or value.get('authority')!='DIRECT_OWNER_INSTRUCTION' or
        any(value.get(key)is not True for key in true) or any(value.get(key)is not False for key in false) or
        candidate.get('serving_manifest_sha256')!=binding['serving_manifest_sha256'] or candidate.get('runtime_lock')!=binding['runtime_lock'] or
        value.get('basis')!='ACTUAL_SUPPORTED_DIRECT_ANSWER_SAVED_STREAMED_RECOVERED' or
        value.get('known_current_usb_case_outcome')!='SYSTEM_ERROR' or value.get('successful_case_id')!='EVAL_DIRECT_01' or
        value.get('successful_hosted_job_id')!='a77d5e33-4419-4d5c-855b-cb8bc2c98690' or
        value.get('authorized_ui_configuration_delta')!={FLAG:{'from':'false','to':'true'}}):
        raise ValueError('EXACT_SINGLE_DIRECT_OWNER_SCOPE_AND_RUNTIME_VERIFIER_REQUIRED')
    return file_reference(WAIVER)

def direct_case_proof(row,release,hosted,auditor):
    if (row.get('case_id')!='EVAL_DIRECT_01' or row.get('route')!='SUPPORTED' or row.get('expected_route_matched')is not True or
        row.get('saved_view',{}).get('response',{}).get('release_gate_passed')is not True):
        raise ValueError('ACTUAL_SUPPORTED_SINGLE_DIRECT_CASE_REQUIRED')
    proof=auditor.audit_case(row,release,hosted)
    if proof.get('passed')is not True or proof.get('accepted')is not True:
        raise ValueError('ACTUAL_DIRECT_SEPARATE_FINALIZED_VERIFIER_AND_EXACT_DELIVERY_REQUIRED')
    policies=auditor.frozen_role_policies(release,hosted['runtime_lock'])
    if auditor.audit_native_role_schema(row,policies):raise ValueError('ACTUAL_DIRECT_NATIVE_ROLE_SCHEMA_CHANGED')
    ledger_proof=auditor.audit_ledgers(hosted['ledger_before'],hosted['ledger_after'],release,
        manifest_sha=hashlib.sha256((cloud.OUT/'serving_manifest_v10_13.json').read_bytes()).hexdigest(),runtime_lock=hosted['runtime_lock'])
    if ledger_proof.get('passed')is not True or auditor.audit_reservation_scope(row,ledger_proof):
        raise ValueError('ACTUAL_DIRECT_DURABLE_GRANT_AND_CHARGES_NOT_BOUND')
    return {'case_id':proof['case_id'],'operation_id':proof['operation_id'],'text_sha256':proof['text_sha256'],
        'finalized_response_sha256':proof['finalized_response_sha256'],'presentation_response_sha256':proof['presentation_response_sha256'],
        'separate_exact_finalized_response_verifier_passed':True,'saved_stream_and_recovery_identical':True,
        'permanent_ledger_proof_passed':True,'current_role_policies_and_native_schemas_bound':True,
        'cache_creation_then_read_proof_required_before_enablement':False,
        'six_case_functional_acceptance':False,'independent_factual_quality_acceptance':False}

def functional_evidence(binding):
    owner=owner_waiver(binding);job='a77d5e33-4419-4d5c-855b-cb8bc2c98690'
    directory=cloud.OUT/'hosted_runs'/job;path=directory/'receipt.json';case_path=directory/'EVAL_DIRECT_01.json'
    if sha(path)!='450196dfccfa5b7192e1db8b5687c482131d463244df6dbde87f66a415b2adc4' or sha(case_path)!='bc9075a8daef6c3152b8fee70f471ffe780d9fd9a66f597bf282b4f56e9421a0':
        raise ValueError('EXACT_OWNER_SEEN_DIRECT_AND_HOSTED_ARTIFACT_BYTES_CHANGED')
    hosted=json.loads(path.read_bytes());row=json.loads(case_path.read_bytes())
    source_path=cloud.OUT/'evaluator_client_source_v11.json';submission_path=cloud.OUT/'evaluator_client_submission_v9.json'
    source=json.loads(source_path.read_bytes());submission=json.loads(submission_path.read_bytes())
    if (submission['operation']['metadata']['build']['id']!=job or submission['config']['source']['storageSource']!={
        'bucket':cloud.BUCKET,'object':source['object'],'generation':source['generation']} or
        source['serving_manifest_sha256']!=binding['serving_manifest_sha256'] or source['runtime_lock']!=binding['runtime_lock'] or
        hosted.get('cloud_build_id')!=job or hosted.get('runtime_lock')!=binding['runtime_lock'] or
        hosted.get('allocation_reset')is not False or hosted.get('allocation_refund')is not False or
        hosted['case_files'].get('EVAL_DIRECT_01')!=sha(case_path)):
        raise ValueError('ACTUAL_SINGLE_DIRECT_SOURCE_JOB_RUNTIME_OR_CHARGES_CHANGED')
    inventory_path=directory/'download_inventory.json';inventory=json.loads(inventory_path.read_bytes())
    if (inventory.get('cloud_build_id')!=job or inventory['files']['receipt.json']['sha256']!=sha(path) or
        inventory['files']['EVAL_DIRECT_01.json']['sha256']!=sha(case_path)):
        raise ValueError('EXACT_SINGLE_DIRECT_DOWNLOAD_INVENTORY_REQUIRED')
    auditor_path=cloud.OUT/'haiku_v10_13_runtime/audit_hosted_delivery_cache_v3.py'
    spec=importlib.util.spec_from_file_location('single_direct_readonly_auditor',auditor_path)
    auditor=importlib.util.module_from_spec(spec);spec.loader.exec_module(auditor)
    release,manifest_sha=auditor.read(cloud.OUT/'serving_manifest_v10_13.json')
    if manifest_sha!=binding['serving_manifest_sha256']:raise ValueError('EXACT_DIRECT_FROZEN_MANIFEST_CHANGED')
    proof=direct_case_proof(row,release,hosted,auditor)
    return {'schema':'motomedic-owner-directed-single-direct-ui-enablement-evidence-v1','owner_enablement':owner,
        'hosted_receipt':file_reference(path),'direct_case':file_reference(case_path),'direct_proof':proof,
        'evaluator_source':file_reference(source_path),'evaluator_submission':file_reference(submission_path),
        'download_inventory':file_reference(inventory_path),'read_only_auditor':file_reference(auditor_path),
        'known_usb_case_outcome':'SYSTEM_ERROR','six_case_acceptance_claimed':False,
        'independent_factual_quality_acceptance':False,'public_browser_acceptance':False}

def ledger_state():
    values={};hashes={};immutable={}
    for name in (PRIMARY,MONEY,GRANT_DOCUMENT,'grounded-provider-global-v1'):
        body=run.api('GET','https://firestore.googleapis.com/v1/projects/'+cloud.PROJECT+'/databases/(default)/documents/arm_a_usage/'+name)
        fields=body['fields'];hashes[name]=rollback.digest(fields)
        if name!='grounded-provider-global-v1':values[name]={key:firestore_value(value) for key,value in fields.items()}
        mutable={PRIMARY:{'reserved_attempts','reserved_tokens'},MONEY:{'reserved_nanodollars','reservation_count'},
            GRANT_DOCUMENT:set(),'grounded-provider-global-v1':{'events','expires_at'}}[name]
        immutable[name]=rollback.digest({key:value for key,value in fields.items() if key not in mutable})
    ceiling,authorization=resolve_token_ceiling(values[PRIMARY],values[GRANT_DOCUMENT])
    if ceiling!=2000000 or values[PRIMARY].get('maximum_attempts')!=100 or values[MONEY].get('maximum_nanodollars')!=1000000000:
        raise ValueError('EXACT_APPROVED_TOKEN_ATTEMPT_SHARED_DOLLAR_GUARDS_REQUIRED')
    return {'maximum_tokens':ceiling,'token_ceiling_authorization':authorization,'full_document_field_sha256':hashes,
        'immutable_non_charge_field_sha256':immutable,
        'reserved_attempts':values[PRIMARY]['reserved_attempts'],'reserved_tokens':values[PRIMARY]['reserved_tokens'],
        'reserved_nanodollars':values[MONEY]['reserved_nanodollars'],'reservation_count':values[MONEY]['reservation_count']}

def require_retained_ledger(before,after,*,exact_charges=False):
    if (before.get('maximum_tokens')!=after.get('maximum_tokens') or before.get('token_ceiling_authorization')!=after.get('token_ceiling_authorization') or
        before.get('immutable_non_charge_field_sha256')!=after.get('immutable_non_charge_field_sha256')):
        raise ValueError('PRIMARY_GRANT_CAPS_OR_OTHER_LEDGER_BINDINGS_CHANGED')
    for key,limit in (('reserved_attempts',100),('reserved_tokens',2000000),('reserved_nanodollars',1000000000),('reservation_count',None)):
        left,right=before.get(key),after.get(key)
        if type(left)is not int or type(right)is not int or not 0<=left<=right or (limit is not None and right>limit) or (exact_charges and left!=right):
            raise ValueError('HISTORICAL_CHARGES_RESET_REFUNDED_OR_EXCEEDED')
    return True

def flag(configuration,expected):
    containers=configuration.get('containers',[])
    if len(containers)!=1:raise ValueError('ONE_EXACT_UI_CONTAINER_REQUIRED')
    rows=containers[0].get('env',[]);matches=[row for row in rows if row.get('name')==FLAG]
    if len({row['name'] for row in rows})!=len(rows) or len(matches)!=1 or matches[0]!={'name':FLAG,'value':expected}:
        raise ValueError('EXACT_PLAIN_UI_ANSWER_ENABLEMENT_FLAG_REQUIRED')
    return matches[0]

def enabled_configuration(paused):
    result=deepcopy(paused);flag(result,'false')['value']='true';return result

def require_only_flag_delta(paused,enabled):
    flag(paused,'false');flag(enabled,'true')
    if enabled_configuration(paused)!=enabled:raise ValueError('ONLY_FALSE_TO_TRUE_UI_FLAG_DELTA_ALLOWED')
    return True

def candidate_template(paused_template,paused_configuration):
    configuration=enabled_configuration(paused_configuration)
    # launchStage is derived Revision output / Service-level input. It is not
    # a RevisionTemplate field, and remains part of the full actual hash check.
    # https://docs.cloud.google.com/run/docs/reference/rest/v2/projects.locations.services#RevisionTemplate
    writable={'scaling','vpcAccess','timeout','serviceAccount','containers','volumes','executionEnvironment',
        'encryptionKey','maxInstanceRequestConcurrency','serviceMesh','encryptionKeyRevocationAction',
        'encryptionKeyShutdownDuration','sessionAffinity','nodeSelector','gpuZonalRedundancyDisabled'}
    if set(configuration)-writable-{'launchStage'}:raise ValueError('UNREVIEWED_REVISION_MATERIAL_TEMPLATE_FIELD')
    template=deepcopy(paused_template)
    for key,value in configuration.items():
        if key in writable:template[key]=deepcopy(value)
    template['revision']=ENABLED
    return template,configuration

def ui_service_configuration(service):
    keys=('ingress','launchStage','binaryAuthorization','scaling','invokerIamDisabled','defaultUriDisabled',
        'iapEnabled','description','labels','annotations','customAudiences','buildConfig')
    return {key:deepcopy(service[key]) for key in keys if key in service}

def current_ui(binding):
    service=run.api('GET',run.PREFIX+UI);rollback.require_service(UI,service,binding)
    revision=rollback.routed_revision(service);actual=run.api('GET',run.PREFIX+UI+'/revisions/'+revision)
    rollback.require_ready_revision(actual,revision)
    configuration=rollback.revision_configuration(actual,service['template'])
    flag(configuration,'false')
    return service,{'revision':revision,'template':deepcopy(service['template']),'revision_configuration':configuration,
        'revision_configuration_sha256':rollback.digest(configuration),'service_scaling':deepcopy(service.get('scaling',{})),
        'service_configuration':ui_service_configuration(service)}

def policies():
    result={}
    for name in core.SERVICES+(UI,):
        value=run.api('GET',run.PREFIX+name+':getIamPolicy?options.requestedPolicyVersion=3')
        rows=core.policy_rows(value)
        if any('allAuthenticatedUsers' in row.get('members',[]) for row in value.get('bindings',[])) or not any(
            row.get('role')=='roles/run.invoker' and not row.get('condition') and 'allUsers' in row.get('members',[]) for row in value.get('bindings',[])):
            raise ValueError('EXACT_EXISTING_PUBLIC_INVOKER_SCOPE_REQUIRED')
        result[name]={'normalized_binding_sha256':rollback.digest(rows),'etag':value.get('etag'),'version':value.get('version',1)}
    return result

def core_rows(binding):
    rows={}
    for name in core.SERVICES:
        service,row=core.actual_revision(name,binding)
        row['service_configuration']=ui_service_configuration(service);rows[name]=row
    return rows

def prepare(guard_path):
    absent('initial.json','candidate_submission.json')
    binding,_=rollback.release();evidence=functional_evidence(binding);guard=preview.guard_receipt(guard_path)
    service,row=current_ui(binding)
    snapshot={'schema':'motomedic-owner-waived-functional-ui-promotion-initial-v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'binding':binding,'functional_evidence':evidence,'guard':guard,'ui':row,'core':core_rows(binding),'public_iam':policies(),
        'provider_ledger':ledger_state(),'independent_factual_quality_acceptance':False,'provider_calls':0,'cloud_writes':0}
    write('initial.json',snapshot);return {'prepared':True,'paused_revision':row['revision'],'enabled_revision':ENABLED,'provider_calls':0}

def check_unchanged(initial,*,exact_charges=False):
    binding,_=rollback.release()
    if binding!=initial['binding'] or functional_evidence(binding)!=initial['functional_evidence']:
        raise ValueError('FUNCTIONAL_PROMOTION_FROZEN_OR_ACCEPTANCE_BINDING_CHANGED')
    if preview.guard_receipt(initial['guard']['path'])!=initial['guard']:
        raise ValueError('EXACT_FRESH_GUARD_RECEIPT_CHANGED')
    if core_rows(binding)!=initial['core'] or policies()!=initial['public_iam']:
        raise ValueError('CORE_CONFIGURATION_OR_PUBLIC_IAM_CHANGED_DURING_UI_PROMOTION')
    service=run.api('GET',run.PREFIX+UI)
    if ui_service_configuration(service)!=initial['ui']['service_configuration']:
        raise ValueError('UI_INGRESS_IAM_CHECK_OR_OTHER_SERVICE_CONFIGURATION_CHANGED')
    require_retained_ledger(initial['provider_ledger'],ledger_state(),exact_charges=exact_charges)
    return binding

def create():
    absent('candidate_submission.json');initial=read('initial.json');binding=check_unchanged(initial,exact_charges=True)
    service,row=current_ui(binding)
    if row!=initial['ui']:raise ValueError('EXACT_PAUSED_UI_BASELINE_CHANGED')
    template,configuration=candidate_template(row['template'],row['revision_configuration'])
    request={'template':template,'traffic':[{'type':'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION','revision':row['revision'],'percent':100}]}
    if not service.get('etag'):raise ValueError('UI_CREATION_CONCURRENCY_ETAG_REQUIRED')
    request['etag']=service['etag']
    # Journal exact reviewed intent before the single UI-only PATCH.
    absent('candidate_intent.json');write('candidate_intent.json',{'request':request,'enabled_configuration':configuration,
        'paused_revision':row['revision'],'initial_sha256':sha(OUT/'initial.json'),'provider_calls':0})
    operation=run.api('PATCH',run.PREFIX+UI+'?updateMask=template,traffic',request)
    write('candidate_submission.json',{'operation':operation,'request':request,'provider_calls':0,'core_or_iam_or_billing_changes':False})
    return {'enabled_revision_created':ENABLED,'traffic_remains_paused':True,'provider_calls':0}

def candidate_status():
    initial=read('initial.json');binding=check_unchanged(initial);saved=read('candidate_submission.json')
    operation=run.api('GET','https://run.googleapis.com/v2/'+saved['operation']['name'])
    if operation.get('done')is not True:return {'candidate_ready':False,'provider_calls':0}
    if operation.get('error'):raise ValueError('FUNCTIONAL_ENABLED_UI_CREATION_FAILED')
    service=run.api('GET',run.PREFIX+UI);rollback.require_service(UI,service,binding)
    if (rollback.routed_revision(service)!=initial['ui']['revision'] or service.get('latestCreatedRevision','').split('/')[-1]!=ENABLED or
        service['template'].get('revision','').split('/')[-1]!=ENABLED or service.get('scaling',{})!=initial['ui']['service_scaling']):
        raise ValueError('ENABLED_UI_MUST_BE_NEW_WITH_TRAFFIC_STILL_PAUSED')
    actual=run.api('GET',run.PREFIX+UI+'/revisions/'+ENABLED)
    ready=[row for row in actual.get('conditions',[]) if row.get('type')=='Ready']
    if len(ready)!=1 or ready[0].get('state')!='CONDITION_SUCCEEDED':return {'candidate_ready':False,'provider_calls':0}
    rollback.require_ready_revision(actual,ENABLED)
    configuration=rollback.revision_configuration(actual,saved['request']['template'])
    require_only_flag_delta(initial['ui']['revision_configuration'],configuration)
    row={'revision':ENABLED,'template':saved['request']['template'],'revision_configuration':configuration,
        'revision_configuration_sha256':rollback.digest(configuration),'service_scaling':deepcopy(service.get('scaling',{}))}
    value={'schema':'motomedic-functional-ui-enabled-candidate-v1','binding':binding,'ui':row,'only_answer_flag_changed':True,
        'traffic_still_paused':True,'provider_calls':0,'independent_factual_quality_acceptance':False}
    if (OUT/'candidate_ready.json').exists():
        if read('candidate_ready.json')!=value:raise ValueError('IMMUTABLE_ENABLED_UI_CANDIDATE_RECEIPT_CHANGED')
    else:write('candidate_ready.json',value)
    return {'candidate_ready':True,'revision':ENABLED,'provider_calls':0}

def route(stage):
    if stage not in ('enabled','paused_rollback','enabled_restore'):raise ValueError('EXACT_FUNCTIONAL_UI_ROUTING_STAGE_REQUIRED')
    absent(stage+'_traffic.json',stage+'_intent.json');initial=read('initial.json');binding=check_unchanged(initial)
    if stage=='paused_rollback':read('enabled_health.json')
    if stage=='enabled_restore':read('paused_rollback_health.json');require_paused_browser()
    candidate=read('candidate_ready.json')
    row=initial['ui'] if stage=='paused_rollback' else candidate['ui']
    service=run.api('GET',run.PREFIX+UI);rollback.require_service(UI,service,binding)
    expected_from=initial['ui']['revision'] if stage in ('enabled','enabled_restore') else ENABLED
    if rollback.routed_revision(service)!=expected_from:raise ValueError('FUNCTIONAL_UI_ROUTE_TRANSITION_SOURCE_CHANGED')
    actual=run.api('GET',run.PREFIX+UI+'/revisions/'+row['revision']);rollback.require_ready_revision(actual,row['revision'])
    if rollback.digest(rollback.revision_configuration(actual,row['template']))!=row['revision_configuration_sha256']:
        raise ValueError('EXACT_FUNCTIONAL_UI_ROUTE_TARGET_CONFIGURATION_CHANGED')
    if not service.get('etag'):raise ValueError('UI_TRAFFIC_CONCURRENCY_ETAG_REQUIRED')
    request={'etag':service['etag'],'traffic':[{'type':'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION','revision':row['revision'],'percent':100}]}
    write(stage+'_intent.json',{'request':request,'stage':stage,'provider_calls':0})
    operation=run.api('PATCH',run.PREFIX+UI+'?updateMask=traffic',request)
    write(stage+'_traffic.json',{'request':request,'operation':operation,'stage':stage,'binding':binding,'provider_calls':0})
    return {'stage':stage,'target_revision':row['revision'],'provider_calls':0}

def health(stage):
    if stage not in ('enabled','paused_rollback','enabled_restore'):raise ValueError('EXACT_FUNCTIONAL_UI_HEALTH_STAGE_REQUIRED')
    absent(stage+'_health.json');initial=read('initial.json');binding=check_unchanged(initial)
    saved=read(stage+'_traffic.json');operation=run.api('GET','https://run.googleapis.com/v2/'+saved['operation']['name'])
    if operation.get('done')is not True or operation.get('error'):return {'stage':stage,'health_ready':False,'provider_calls':0}
    row=initial['ui'] if stage=='paused_rollback' else read('candidate_ready.json')['ui']
    service=run.api('GET',run.PREFIX+UI);rollback.require_service(UI,service,binding)
    if rollback.routed_revision(service)!=row['revision'] or service.get('scaling',{})!=initial['ui']['service_scaling']:
        raise ValueError('FUNCTIONAL_UI_ACTUAL_TRAFFIC_OR_SERVICE_SCALING_CHANGED')
    actual=run.api('GET',run.PREFIX+UI+'/revisions/'+row['revision']);rollback.require_ready_revision(actual,row['revision'])
    configuration=rollback.revision_configuration(actual,row['template'])
    if rollback.digest(configuration)!=row['revision_configuration_sha256']:raise ValueError('FUNCTIONAL_UI_EXACT_ROUTED_MATERIAL_CONFIGURATION_CHANGED')
    flag(configuration,'false' if stage=='paused_rollback' else 'true')
    result=rollback.get_health(UI,service,binding,url=preview.URL)
    check_unchanged(initial)
    write(stage+'_health.json',{'schema':'motomedic-functional-ui-routed-health-v1','stage':stage,'binding':binding,
        'revision':row['revision'],'revision_configuration_sha256':row['revision_configuration_sha256'],'anonymous_ui_health':result,
        'core_and_iam_unchanged':True,'provider_ledger_after':ledger_state(),'permanent_grant_caps_and_charges_retained':True,
        'legitimate_bounded_public_usage_does_not_disable_rollback':True,'provider_calls_by_health_check':0,'independent_factual_quality_acceptance':False})
    return {'stage':stage,'health_ready':True,'revision':row['revision'],'provider_calls':0}

def browser_paths(mode):
    if mode not in ('paused','enabled'):raise ValueError('EXACT_FUNCTIONAL_BROWSER_MODE_REQUIRED')
    return ROOT/('tmp/public_evaluator/functional-v13-'+mode+'-browser-v1')

def require_paused_browser():
    path=browser_paths('paused')/'receipt.json';value=json.loads(path.read_bytes())
    initial=read('initial.json')
    if (value.get('status')!='PASS_PUBLIC_PAUSED_SHELL' or value.get('expected_release_manifest_sha256')!=initial['binding']['serving_manifest_sha256'] or
        value.get('ui_turn_submissions')!=0 or value.get('provider_calls_by_this_observer')!=0 or
        value.get('question_input_disabled')is not True or value.get('paused_message_visible')is not True):
        raise ValueError('ACTUAL_ANONYMOUS_PAUSED_ROLLBACK_BROWSER_REQUIRED')
    record=read('paused_browser.json')
    if record['browser_receipt_sha256']!=sha(path):raise ValueError('PAUSED_ROLLBACK_BROWSER_RECEIPT_CHANGED')
    return file_reference(path)

def require_routed_ui(stage,initial,binding):
    row=initial['ui'] if stage=='paused_rollback' else read('candidate_ready.json')['ui']
    service=run.api('GET',run.PREFIX+UI);rollback.require_service(UI,service,binding)
    if rollback.routed_revision(service)!=row['revision']:
        raise ValueError('EXACT_BROWSER_ROUTED_UI_REVISION_REQUIRED')
    actual=run.api('GET',run.PREFIX+UI+'/revisions/'+row['revision']);rollback.require_ready_revision(actual,row['revision'])
    configuration=rollback.revision_configuration(actual,row['template'])
    if rollback.digest(configuration)!=row['revision_configuration_sha256']:
        raise ValueError('EXACT_BROWSER_ROUTED_UI_CONFIGURATION_CHANGED')
    flag(configuration,'false' if stage=='paused_rollback' else 'true')
    return {'revision':row['revision'],'revision_configuration_sha256':row['revision_configuration_sha256']}

def browser(mode):
    if mode not in ('paused','enabled'):raise ValueError('EXACT_FUNCTIONAL_BROWSER_MODE_REQUIRED')
    target=mode+'_browser.json';absent(target);initial=read('initial.json')
    stage='paused_rollback' if mode=='paused' else ('enabled_restore' if (OUT/'enabled_restore_health.json').exists() else 'enabled');read(stage+'_health.json')
    binding=check_unchanged(initial);require_routed_ui(stage,initial,binding);output=browser_paths(mode)
    if output.exists():raise ValueError('NEVER_OVERWRITE_FUNCTIONAL_BROWSER_OUTPUT')
    bundle=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node'
    environment=os.environ.copy();environment['NODE_PATH']=str(bundle/'node_modules');environment.pop('MOTOMEDIC_PRIVATE_TEST_ID_TOKEN',None)
    script=ROOT/('tmp/public_evaluator/browser_preview_v13_v1.cjs' if mode=='paused' else 'tmp/public_evaluator/browser_acceptance_v13.cjs')
    args=[str(bundle/'bin/node.exe'),str(script),'--execute-authorized','--url',preview.URL,
        '--release-sha',initial['binding']['serving_manifest_sha256'],'--output',str(output)]
    before=ledger_state();result=subprocess.run(args,cwd=ROOT,env=environment,timeout=300 if mode=='paused' else 2800)
    receipt_path=output/'receipt.json'
    if not receipt_path.exists():raise ValueError('FUNCTIONAL_BROWSER_RECEIPT_MISSING')
    value=json.loads(receipt_path.read_bytes());after=ledger_state()
    if result.returncode or value.get('expected_release_manifest_sha256')!=initial['binding']['serving_manifest_sha256']:
        raise ValueError('ACTUAL_FUNCTIONAL_PUBLIC_BROWSER_DID_NOT_PASS')
    require_retained_ledger(before,after)
    if mode=='paused':
        if value.get('status')!='PASS_PUBLIC_PAUSED_SHELL' or value.get('ui_turn_submissions')!=0 or value.get('provider_calls_by_this_observer')!=0:
            raise ValueError('PAUSED_ROLLBACK_BROWSER_CREATED_PROVIDER_WORK')
    elif value.get('status')!='PASS_UI_BOUNDARY_OBSERVATION' or value.get('ui_turn_submissions')!=1 or len(value.get('turns',[]))!=1:
        raise ValueError('ACTUAL_ANONYMOUS_DIRECT_BROWSER_REQUIRED')
    check_unchanged(initial);routed=require_routed_ui(stage,initial,binding)
    write(target,{'schema':'motomedic-functional-ui-browser-evidence-v1','mode':mode,'browser_receipt_path':receipt_path.relative_to(ROOT).as_posix(),
        'browser_receipt_sha256':sha(receipt_path),'script_sha256':sha(script),'provider_ledger_before':before,'provider_ledger_after':after,
        'independent_factual_quality_acceptance':False,'human_signoff':False,'provider_work_forbidden':mode=='paused',
        'public_browser_passed':True,'routed_ui_after_browser':routed,'core_and_public_iam_unchanged_after_browser':True,
        'provider_counts_for_enabled_browser_require_correlated_operation_audit':mode=='enabled'})
    return {'mode':mode,'public_browser_passed':True,'independent_factual_quality_acceptance':False}

if __name__=='__main__':
    cloud.token=console.token
    actions=('prepare','create','candidate_status','route','health','browser')
    if sys.argv[1:]==['--check-only']:print(json.dumps({'actions':actions,'cloud_actions_executed':False,'provider_calls':0,
        'legacy_manual_acceptance_gate_unchanged':True,'single_direct_owner_enablement_only':True,'six_case_acceptance_claimed':False,'owner_waiver_exact_sha256':WAIVER_SHA,
        'independent_factual_quality_acceptance':False,'only_ui_answer_flag_change_authorized':True}))
    elif len(sys.argv)==3 and sys.argv[1]in ('prepare','route','health','browser'):print(json.dumps(globals()[sys.argv[1]](sys.argv[2])))
    elif len(sys.argv)==2 and sys.argv[1]in ('create','candidate_status'):print(json.dumps(globals()[sys.argv[1]]()))
    else:raise SystemExit('ONE_EXACT_FUNCTIONAL_UI_PROMOTION_ACTION_REQUIRED')
