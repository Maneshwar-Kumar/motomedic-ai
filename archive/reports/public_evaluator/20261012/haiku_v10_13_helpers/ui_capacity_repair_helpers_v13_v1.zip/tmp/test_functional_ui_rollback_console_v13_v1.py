"""Synthetic retained-charge rollback wrapper tests, no clouds/providers."""
from copy import deepcopy
from pathlib import Path
import sys,tempfile,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tmp'))
import functional_ui_rollback_console_v13_v1 as console

class RollbackConsoleTests(unittest.TestCase):
    def test_exact_completed_browser_baseline_is_provider_free_and_retains_actual_charges(self):
        with patch.object(console.promote,'ledger_state') as ledger,patch.object(console.promote.run,'api') as api:
            baseline=console.bound_baseline();ledger.assert_not_called();api.assert_not_called()
        self.assertEqual(baseline['reserved_attempts'],34);self.assertEqual(baseline['reserved_tokens'],549094)
        self.assertEqual(baseline['reserved_nanodollars'],56954750)
    def test_refund_since_completed_browser_blocks_before_any_traffic_or_observer_action(self):
        baseline=console.bound_baseline();changed=deepcopy(baseline);changed['reserved_tokens']-=1
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(console,'OUT',Path(directory)),\
            patch.object(console.promote,'ledger_state',return_value=changed),patch.object(console.promote,'route') as route:
            with self.assertRaises(ValueError):console.execute('route_paused')
            route.assert_not_called()
    def test_fixed_action_journal_retains_growth_and_prevents_repeated_traffic_mutation(self):
        baseline=console.bound_baseline();grown=deepcopy(baseline);grown['reserved_attempts']+=2
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(console,'OUT',Path(directory)),\
            patch.object(console.promote,'ledger_state',side_effect=[baseline,grown]),\
            patch.object(console.promote,'route',return_value={'stage':'paused_rollback','provider_calls':0}) as route:
            console.execute('route_paused');route.assert_called_once_with('paused_rollback')
            self.assertEqual(console.bound_baseline()['reserved_attempts'],grown['reserved_attempts'])
            with self.assertRaises(ValueError):console.execute('route_paused')
            self.assertEqual(route.call_count,1)
    def test_unknown_action_has_no_ledger_or_cloud_effect(self):
        with patch.object(console.promote,'ledger_state') as ledger:
            with self.assertRaises(ValueError):console.execute('other')
            ledger.assert_not_called()

if __name__=='__main__':unittest.main()
