"""Synthetic exact read-only guard refresh and restore-only scope tests."""
from copy import deepcopy
from pathlib import Path
import json,sys,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tmp'))
import functional_ui_guard_bridge_v13_v1 as bridge

class GuardBridgeTests(unittest.TestCase):
    def test_actual_guard_bridge_preserves_initial_and_guard_bytes_without_network(self):
        with patch.object(bridge.promote.run,'api') as api:
            value=bridge.guard_bridge(bridge.promote.read('initial.json'));api.assert_not_called()
        self.assertTrue(value['original_initial_and_guard_bytes_preserved'])
        self.assertTrue(value['all_immutable_guard_settings_and_billing_scope_equal'])
        self.assertFalse(value['new_model_billing_allocation_or_iam_authority'])
    def test_changed_budget_billing_guard_revision_or_stop_rejects_even_if_receipt_had_a_valid_read(self):
        initial=bridge.promote.read('initial.json');old=json.loads((ROOT/initial['guard']['path']).read_bytes())
        fresh=json.loads((ROOT/bridge.FRESH_PATH).read_bytes())
        for field in ('settings','billing','revision','stop'):
            changed=deepcopy(fresh)
            if field=='settings':changed['guard_settings']['STOP_INR']='9999'
            elif field=='billing':changed['billing_enabled']['motomedic-inference-20261009']=True
            elif field=='revision':changed['guard_revision']='different-version'
            else:changed['latest_guard_log_scalars'][0]['stop']=True
            with patch.object(bridge.promote.preview,'guard_receipt',return_value={'sha256':bridge.FRESH_SHA}),\
                patch.object(bridge.json,'loads',side_effect=[old,changed]),self.subTest(field=field),self.assertRaises(ValueError):
                bridge.guard_bridge(initial)
    def test_only_restore_and_health_actions_allowed_and_original_predicate_restored_after_call(self):
        original=bridge.promote.check_unchanged
        with patch.object(bridge.console,'execute',return_value={'restored':True}) as execute:
            with self.assertRaises(ValueError):bridge.execute('create')
            execute.assert_not_called();self.assertTrue(bridge.execute('health_enabled_restore')['restored'])
        self.assertIs(bridge.promote.check_unchanged,original)

if __name__=='__main__':unittest.main()
