"""Exact newer read-only guard for the same UI rollback/restore authority."""
import hashlib,json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tmp'))
import functional_ui_rollback_console_v13_v1 as console
promote=console.promote
FRESH_PATH='reports/public_evaluator/20261012/operations/guard_readback_v10_13_20261012T115158342580Z.json'
FRESH_SHA='64f0280df82721973c27e2bba340f643c489be5738f53d1978a516d94faaaf8a'
INITIAL_SHA='effa0ff84c3fda30850cff56504d4e16dc369bbd12b90900a4a4c4e159f81be6'
WRAPPER_SHA='9e586b140b092c8e5b431382aa66d810fa971f769a1a426b0dad6dcfd038cf24'
BRIDGE=promote.OUT/'guard_refresh_v1.json'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def guard_bridge(initial):
    if sha(promote.OUT/'initial.json')!=INITIAL_SHA or sha(Path(console.__file__))!=WRAPPER_SHA:
        raise ValueError('EXACT_INITIAL_AND_RETAINED_CHARGE_WRAPPER_BYTES_CHANGED')
    old_path=ROOT/initial['guard']['path']
    if sha(old_path)!=initial['guard']['sha256'] or sha(ROOT/FRESH_PATH)!=FRESH_SHA:
        raise ValueError('ORIGINAL_OR_NEW_EXACT_GUARD_RECEIPT_CHANGED')
    fresh=promote.preview.guard_receipt(FRESH_PATH)
    old=json.loads(old_path.read_bytes());new=json.loads((ROOT/FRESH_PATH).read_bytes())
    for key in ('schema_version','project_id','guard_revision','guard_settings','billing_enabled','recorded_scope_matches',
        'delayed_reporting_prevents_instantaneous_cap','cloud_writes','billing_changed','provider_calls','raw_logs_or_request_bodies_saved'):
        if old.get(key)!=new.get(key):raise ValueError('GUARD_SCOPE_SETTING_BILLING_OR_GUARD_VERSION_CHANGED')
    logs=new.get('latest_guard_log_scalars',[])
    if (not logs or logs[0].get('stop')is not False or type(logs[0].get('cost_inr'))not in (int,float) or
        not 0<=logs[0]['cost_inr']<2540):raise ValueError('FRESH_GUARD_ALREADY_STOPPED_OR_REPORTED_THRESHOLD_REACHED')
    return {'schema':'motomedic-ui-rollback-readonly-guard-freshness-bridge-v1',
        'initial_path':(promote.OUT/'initial.json').relative_to(ROOT).as_posix(),'initial_sha256':INITIAL_SHA,
        'original_guard':initial['guard'],'fresh_guard':fresh,'fresh_guard_sha256':FRESH_SHA,
        'all_immutable_guard_settings_and_billing_scope_equal':True,'latest_reported_stop':False,
        'read_only_newer_guard_receipt_only':True,'delayed_reporting_prevents_instantaneous_cap':True,
        'promotion_source_bytes_changed':False,'original_initial_and_guard_bytes_preserved':True,
        'new_model_billing_allocation_or_iam_authority':False,'bridge_source_sha256':sha(Path(__file__)),
        'cloud_calls_by_bridge':0,'provider_calls_by_bridge':0}

def guarded_check_unchanged(initial,*,exact_charges=False):
    # Every original predicate stays exact. Only freshness uses the newly
    # recorded guard; original initial/guard bytes remain separately hash-bound.
    binding,_=promote.rollback.release()
    if binding!=initial['binding'] or promote.functional_evidence(binding)!=initial['functional_evidence']:
        raise ValueError('FUNCTIONAL_PROMOTION_FROZEN_OR_ACCEPTANCE_BINDING_CHANGED')
    bridge=guard_bridge(initial)
    if not BRIDGE.exists():
        with BRIDGE.open('x',encoding='utf-8') as target:json.dump(bridge,target,indent=2,sort_keys=True);target.write('\n')
    elif json.loads(BRIDGE.read_bytes())!=bridge:raise ValueError('IMMUTABLE_GUARD_REFRESH_BRIDGE_CHANGED')
    if promote.core_rows(binding)!=initial['core'] or promote.policies()!=initial['public_iam']:
        raise ValueError('CORE_CONFIGURATION_OR_PUBLIC_IAM_CHANGED_DURING_UI_PROMOTION')
    service=promote.run.api('GET',promote.run.PREFIX+promote.UI)
    if promote.ui_service_configuration(service)!=initial['ui']['service_configuration']:
        raise ValueError('UI_INGRESS_IAM_CHECK_OR_OTHER_SERVICE_CONFIGURATION_CHANGED')
    promote.require_retained_ledger(initial['provider_ledger'],promote.ledger_state(),exact_charges=exact_charges)
    return binding

def execute(action):
    if action not in ('route_enabled_restore','health_enabled_restore'):
        raise ValueError('ONLY_EXISTING_UI_RESTORE_AND_HEALTH_GUARD_BRIDGE_ACTIONS_ALLOWED')
    original=promote.check_unchanged
    try:
        promote.check_unchanged=guarded_check_unchanged
        return console.execute(action)
    finally:promote.check_unchanged=original

if __name__=='__main__':
    promote.cloud.token=promote.console.token
    if sys.argv[1:]==['--check-only']:
        value=guard_bridge(promote.read('initial.json'));console.bound_baseline()
        print(json.dumps({'actions':['route_enabled_restore','health_enabled_restore'],'fresh_guard':value['fresh_guard'],
            'old_initial_and_guard_preserved':True,'cloud_calls':0,'provider_calls':0}))
    elif len(sys.argv)==2:print(json.dumps(execute(sys.argv[1])))
    else:raise SystemExit('ONE_FIXED_RESTORE_GUARD_BRIDGE_ACTION_REQUIRED')
