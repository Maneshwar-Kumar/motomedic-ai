"""Synthetic UI service-max-only repair boundaries, no clouds/providers."""
from copy import deepcopy
from pathlib import Path
import sys,tempfile,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tmp'))
import repair_ui_capacity_v13_v1 as repair

class CapacityRepairTests(unittest.TestCase):
    def config(self):return {'ingress':'ALL','scaling':{'maxInstanceCount':1},'labels':{'exact':'preserved'},'invokerIamDisabled':False}
    def test_only_service_max_changes_and_revision_traffic_image_or_iam_deltas_reject(self):
        before=self.config();after=repair.target_configuration(before)
        self.assertEqual(before['scaling']['maxInstanceCount'],1);self.assertEqual(after['scaling']['maxInstanceCount'],2)
        self.assertTrue(repair.require_only_service_max_delta(before,after))
        for key in ('ingress','labels','invokerIamDisabled','revision','traffic','image'):
            changed=deepcopy(after);changed[key]='different'
            with self.subTest(key=key),self.assertRaises(ValueError):repair.require_only_service_max_delta(before,changed)
        for scaling in ({'maxInstanceCount':2},{'maxInstanceCount':1,'minInstanceCount':1},{'maxInstanceCount':'1'}):
            changed=self.config();changed['scaling']=scaling
            with self.assertRaises(ValueError):repair.target_configuration(changed)
    def test_single_etag_patch_only_scaling_is_journalled_before_mutation(self):
        initial={'etag':'exact','ui_service_configuration':self.config(),'provider_ledger':{},
            'required_target_service_configuration':repair.target_configuration(self.config())}
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(repair,'OUT',Path(directory)),\
            patch.object(repair,'read',return_value=initial),patch.object(repair,'current',return_value=({'etag':'exact'},{})),\
            patch.object(repair,'sha',return_value='a'*64):
            def api(method,url,body):
                self.assertTrue((Path(directory)/'intent.json').exists())
                self.assertEqual(method,'PATCH');self.assertEqual(url,repair.run.PREFIX+repair.promote.UI+'?updateMask=scaling')
                self.assertEqual(body,{'etag':'exact','scaling':{'maxInstanceCount':2}});return {'name':'operation'}
            with patch.object(repair.run,'api',side_effect=api) as call:repair.apply();call.assert_called_once()
    def test_changed_etag_blocks_before_any_cloud_mutation(self):
        initial={'etag':'old','ui_service_configuration':self.config(),'provider_ledger':{}}
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(repair,'OUT',Path(directory)),\
            patch.object(repair,'read',return_value=initial),patch.object(repair,'current',return_value=({'etag':'new'},{})),\
            patch.object(repair.run,'api') as api:
            with self.assertRaises(ValueError):repair.apply()
            api.assert_not_called()
    def test_instance_metric_is_get_only_and_saves_only_filtered_revision_state_scalars(self):
        body={'timeSeries':[{'resource':{'labels':{'revision_name':'enabled','private_extra':'do-not-save'}},
            'metric':{'labels':{'state':'active','ignored':'do-not-save'}},'points':[{'interval':{'endTime':'2026-10-12T12:00:00Z'},
                'value':{'int64Value':'1'},'unused':'do-not-save'}]}]}
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as directory,patch.object(repair,'OUT',Path(directory)),\
            patch.object(repair.run,'api',return_value=body) as api:
            result=repair.metric();self.assertEqual(api.call_args.args[0],'GET')
            self.assertEqual(set(result['records'][0]),{'revision','state','endTime','value'})
            self.assertEqual(result['cloud_writes'],0);self.assertEqual(result['provider_calls'],0)

if __name__=='__main__':unittest.main()
