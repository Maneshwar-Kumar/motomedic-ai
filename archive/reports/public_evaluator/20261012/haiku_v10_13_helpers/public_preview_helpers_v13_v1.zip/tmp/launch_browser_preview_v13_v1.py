"""Exact frozen preview shell observer; no answer submission mode."""
import hashlib
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp'))
import submit_hosted_v10 as cloud

def main():
    if len(sys.argv)!=2 or sys.argv[1] not in ('private-preview','public-preview','self-check'):
        raise ValueError('EXACT_PREVIEW_SHELL_MODE_REQUIRED')
    mode=sys.argv[1];bundle=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node'
    env=os.environ.copy();env['NODE_PATH']=str(bundle/'node_modules')
    args=[str(bundle/'bin/node.exe'),str(ROOT/'tmp/public_evaluator/browser_preview_v13_v1.cjs')]
    if mode=='self-check':args+=['--self-check']
    else:
        manifest=cloud.OUT/'serving_manifest_v10_13.json';sha=hashlib.sha256(manifest.read_bytes()).hexdigest()
        if (cloud.OUT/'serving_manifest_v10_13.sha256').read_text().split()[0]!=sha:raise ValueError('CURRENT_MANIFEST_SIDECAR_CHANGED')
        args+=['--execute-authorized','--url','https://motomedic-rider-ui-279945185781.us-central1.run.app','--release-sha',sha]
        if mode=='private-preview':
            sdk_env=os.environ.copy();sdk_env.pop('PYTHONPATH',None)
            result=subprocess.run([str(cloud.CLI),'auth','print-identity-token','--account=maneshwarkumar@gmail.com','--quiet'],
                capture_output=True,text=True,env=sdk_env,timeout=45)
            if result.returncode or not result.stdout.strip():raise RuntimeError('SDK_AUTHENTICATION_UNAVAILABLE')
            env['MOTOMEDIC_PRIVATE_TEST_ID_TOKEN']=result.stdout.strip()
    output=ROOT/('tmp/public_evaluator/'+mode+'-output-v10_13-preview-v1')
    if output.exists():raise ValueError('NEVER_OVERWRITE_PREVIEW_BROWSER_OUTPUT')
    args+=['--output',str(output)]
    return subprocess.run(args,env=env,cwd=ROOT,timeout=240).returncode

if __name__=='__main__':sys.exit(main())
