"""Synthetic preview scope/configuration checks, without cloud or models."""
import copy
from datetime import datetime,timezone,timedelta
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE));sys.path.insert(0,str(BASE.parent))
import public_ui_preview_v13_v2 as preview

class PreviewTests(unittest.TestCase):
    def test_recorded_direct_owner_scope_has_separate_paused_preview_authority(self):
        value=preview.owner_scope('reports/public_evaluator/20261012/public_review/owner_public_review_scope_v1.json')
        self.assertTrue(value['scope']['authorized']['public_ui_preview_before_factual_acceptance'])
        self.assertTrue(value['scope']['implementation_constraints']['preview_answer_submission_paused'])
        self.assertEqual(value['sha256'],hashlib.sha256((BASE.parent/value['path']).read_bytes()).hexdigest())
    def test_pause_requires_explicit_single_plain_false(self):
        exact={'containers':[{'env':[{'name':preview.FLAG,'value':'false'}]}]}
        self.assertTrue(preview.paused_ui(exact))
        for mutate in ('true','missing','duplicate','secret'):
            actual=copy.deepcopy(exact);rows=actual['containers'][0]['env']
            if mutate=='true':rows[0]['value']='true'
            elif mutate=='missing':rows.clear()
            elif mutate=='duplicate':rows.append(copy.deepcopy(rows[0]))
            else:rows[0]['valueSource']={'secretKeyRef':{'secret':'invalid'}}
            with self.subTest(mutate=mutate),self.assertRaises(ValueError):preview.paused_ui(actual)
    def test_guard_requires_fresh_unchanged_existing_budget_and_billing(self):
        fixture={'read_at_utc':datetime.now(timezone.utc).isoformat(),'recorded_scope_matches':True,
            'provider_calls':0,'billing_changed':False,'guard_settings':{'BUDGET_INR':'2700','STOP_INR':'2540'},
            'billing_enabled':{preview.cloud.PROJECT:True,'motomedic-inference-20261009':False}}
        relative='reports/public_evaluator/20261012/operations/synthetic_guard_never_written.json'
        with patch.object(Path,'read_bytes',return_value=json.dumps(fixture).encode()):
            preview.guard_receipt(relative)
        for key in ('age','budget','billing','calls'):
            value=copy.deepcopy(fixture)
            if key=='age':value['read_at_utc']=(datetime.now(timezone.utc)-timedelta(hours=1)).isoformat()
            elif key=='budget':value['guard_settings']['BUDGET_INR']='3000'
            elif key=='billing':value['billing_enabled']['motomedic-inference-20261009']=True
            else:value['provider_calls']=1
            with patch.object(Path,'read_bytes',return_value=json.dumps(value).encode()),self.assertRaises(ValueError):preview.guard_receipt(relative)
    def test_gate_helpers_do_not_replace_full_quality_acceptance(self):
        source=(BASE/'public_ui_preview_v13_v2.py').read_text()
        self.assertIn("'quality_acceptance':False",source)
        self.assertIn("'actual_answer_vs_manual_tests_completed':False",source)
        self.assertIn("'full_release_accepted':False",source)
        self.assertIn('private_readiness_v10_13_v2.json',source)
        self.assertNotIn('rollback.acceptance(',source)
    def test_output_is_exclusive_and_never_overwritten(self):
        with tempfile.TemporaryDirectory(dir=BASE) as temporary,patch.object(preview,'OUT',Path(temporary)):
            preview.write('fixture.json',{'provider_calls':0})
            with self.assertRaises(FileExistsError):preview.write('fixture.json',{'provider_calls':1})
            self.assertEqual(preview.read('fixture.json'),{'provider_calls':0})

if __name__=='__main__':unittest.main()
