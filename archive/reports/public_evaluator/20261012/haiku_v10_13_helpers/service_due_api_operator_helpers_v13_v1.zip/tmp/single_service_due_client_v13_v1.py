"""One owner-requested live API question, one POST, existing frozen client."""
import argparse,hashlib,importlib.util,json,os
from datetime import datetime,timezone
from pathlib import Path
import re,sys,time
ROOT=Path(__file__).resolve().parents[1]
ARTIFACTS=('service_due_case.json','receipt.json','exit_status.json')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    with path.open('x',encoding='utf-8') as target:json.dump(value,target,indent=2,sort_keys=True,ensure_ascii=False);target.write('\n')
def main(args):
    if ROOT!=Path('/workspace') or os.environ.get('MOTOMEDIC_HOSTED_PROVIDER_VALIDATION')!='true':raise ValueError('HOSTED_ONLY_DIAGNOSTIC_REQUIRED')
    inventory=json.loads((ROOT/args.inventory).read_bytes());job=os.environ.get('MOTOMEDIC_CLOUD_BUILD_ID')
    if (not re.fullmatch(r'[0-9a-f-]{36}',job or '') or job!=args.allocated_job_id or
        inventory.get('schema')!='motomedic-single-service-due-api-source-inputs-v1'):
        raise ValueError('EXACT_ALLOCATED_HOSTED_JOB_AND_INPUTS_REQUIRED')
    for relative,expected in inventory['file_sha256'].items():
        path=(ROOT/relative).resolve()
        if not path.is_relative_to(ROOT) or sha(path)!=expected:raise ValueError('EXACT_SOURCE_INPUT_BYTES_CHANGED')
    frozen=json.loads((ROOT/inventory['manifest_path']).read_bytes())
    sys.path[:]=['/app']+[value for value in sys.path if value!='/app']
    client_path=ROOT/'tmp/public_evaluator/hosted_client_v10_13_v2.py'
    spec=importlib.util.spec_from_file_location('existing_exact_hosted_api_client',client_path)
    client=importlib.util.module_from_spec(spec);spec.loader.exec_module(client)
    # The historical helper prepends workspace. Reassert actual frozen app code.
    sys.path[:]=['/app']+[value for value in sys.path if value!='/app']
    from rider_ui.client import validate_view,RUNTIME_POLICY
    from rider_ui.verified_sse import read_verified_stream,response_hash
    from cloud.grounded_generation.token_ceiling import GRANT_DOCUMENT,resolve_token_ceiling
    for name in ('rider_ui.client','rider_ui.identity','rider_ui.verified_sse','cloud.grounded_generation.token_ceiling'):
        module=__import__(name,fromlist=['*']);path=Path(module.__file__).resolve()
        relative=path.relative_to(Path('/app')).as_posix()
        if sha(path)!=frozen['file_sha256'][relative]:raise ValueError('FROZEN_CLIENT_RUNTIME_MODULE_CHANGED')
    query=inventory['question'];key=inventory['operation_id'];lock=inventory['runtime_lock']
    if query!='When is the service due for my bike?' or not re.fullmatch(r'[0-9a-f]{32}',key):raise ValueError('ONE_EXACT_OWNER_QUERY_AND_FRESH_KEY_REQUIRED')
    guard=json.loads((ROOT/inventory['guard_path']).read_bytes())
    age=(datetime.now(timezone.utc)-datetime.fromisoformat(guard['read_at_utc'])).total_seconds()
    if (not 0<=age<=1800 or guard.get('recorded_scope_matches')is not True or guard.get('billing_changed')is not False or
        guard.get('provider_calls')!=0 or guard.get('guard_settings',{}).get('BUDGET_INR')!='2700' or
        guard['guard_settings'].get('STOP_INR')!='2540' or guard.get('billing_enabled')!={'motomedic-ai-20261009':True,'motomedic-inference-20261009':False} or
        not guard.get('latest_guard_log_scalars') or guard['latest_guard_log_scalars'][0].get('stop')is not False):
        raise ValueError('EXACT_FRESH_UNCHANGED_INR_AND_BILLING_GUARD_REQUIRED')
    output=Path(args.output);output.mkdir(parents=True,exist_ok=True)
    if list(output.iterdir()):raise ValueError('NEVER_OVERWRITE_DIAGNOSTIC_OUTPUT')
    before=client.ledger('motomedic-ai-20261009');primary=before['grounded-primary-nonrecurring-v1'];money=before['owner-haiku-fallback-20261011-validation-v1']
    ceiling,authority=resolve_token_ceiling(primary,before.get(GRANT_DOCUMENT))
    if ceiling!=2000000 or primary.get('maximum_attempts')!=100 or money.get('maximum_nanodollars')!=1000000000:
        raise ValueError('PERMANENT_APPROVED_ALLOCATION_CHANGED')
    if primary.get('reserved_attempts',100)>=100 or primary.get('reserved_tokens',ceiling)>=ceiling or money.get('reserved_nanodollars',1000000000)>=1000000000:
        raise ValueError('PERMANENT_ALLOCATION_EXHAUSTED')
    backend=client.Backend('https://motomedic-arm-a-279945185781.us-central1.run.app',os.environ['MOTOMEDIC_VISITOR_SECRET'])
    row={'schema':'motomedic-single-service-due-live-api-case-v1','case_id':'SERVICE_DUE_01','operation_id':key,
        'question':query,'question_sha256':client.digest(query),'runtime_lock':lock,'post_retries':0,'inference_replayed':False,
        'fresh_signed_capability_existing_engineering_principal':True,'status':'NOT_POSTED','independent_factual_quality_acceptance':False}
    try:
        health=backend.request('GET','/v1/health')
        if health.get('ready')is not True or health.get('runtime_lock')!=lock or health.get('answer_provider')!='claude-haiku-5-5':raise ValueError('ACTUAL_CURRENT_HAIKU_RUNTIME_NOT_READY')
        payload={'query':query,'bike_variant':'Himalayan BS6','confirmed_himalayan_bs6':True,
            'manual_checksum':'cf221a29e2f9cd5af6e80a99774a697c814e8eda661c27d72e519d8a7e80da89',
            'index_id':'index_a3282c4d98cf54595e4ba168','cache_mode':'bypass'}
        row['status']='ONE_POST_DISPATCHED';value=backend.request('POST','/v1/sessions',body=payload,operation=key)
        deadline=time.monotonic()+1250
        while value.get('status')=='RUNNING':
            if value.get('operation_id')!=key or time.monotonic()>=deadline:raise ValueError('OPERATION_WAIT_EXHAUSTED_NO_POST_RETRY')
            time.sleep(5);value=backend.request('GET','/v1/operations/'+key)
        view=validate_view(value,expected_policy=RUNTIME_POLICY)
        if view['delivery']['runtime_lock']!=lock:raise ValueError('SAVED_RUNTIME_CHANGED')
        stream=backend.request('GET','/v1/operations/'+key,sse=True);chunks=[];stages=[]
        try:streamed=read_verified_stream(stream.iter_content(4096),operation_id=key,on_chunk=chunks.append,on_progress=stages.append,expected_policy=RUNTIME_POLICY)
        finally:stream.close()
        recovered=validate_view(backend.request('GET','/v1/operations/'+key),expected_policy=RUNTIME_POLICY)
        if streamed!=view or recovered!=view:raise ValueError('EXACT_SAVED_STREAM_RECOVERY_CHANGED')
        row.update(status='SAVED_STREAMED_RECOVERED',saved_view=view,response_sha256=response_hash(view),
            route=view['response']['type'],exact_saved_stream=True,exact_recovered_view=True,
            streamed_text=''.join(chunks),stream_stages=stages)
    except Exception as exc:
        row['error']=client.safe_code(str(exc),'LIVE_API_OR_DELIVERY_FAILURE');row['failure_class']=type(exc).__name__
    finally:
        backend.http.close();after=client.ledger('motomedic-ai-20261009')
        for doc,fields in (('grounded-primary-nonrecurring-v1',('reserved_attempts','reserved_tokens')),('owner-haiku-fallback-20261011-validation-v1',('reserved_nanodollars','reservation_count'))):
            if any(after[doc].get(field,0)<before[doc].get(field,0) for field in fields):raise ValueError('HISTORICAL_CHARGES_DECREASED')
        if resolve_token_ceiling(after['grounded-primary-nonrecurring-v1'],after.get(GRANT_DOCUMENT))!=(ceiling,authority):raise ValueError('TOKEN_AUTHORITY_CHANGED')
        save(output/'service_due_case.json',row)
        receipt={'schema':'motomedic-single-service-due-live-api-receipt-v1','cloud_build_id':job,'operation_id':key,
            'serving_manifest_sha256':inventory['serving_manifest_sha256'],'runtime_lock':lock,
            'source_inventory_sha256':sha(ROOT/args.inventory),'owner_scope_sha256':inventory['owner_scope_sha256'],
            'case_sha256':sha(output/'service_due_case.json'),'ledger_before':before,'ledger_after':after,
            'transport_delivery_passed':row.get('status')=='SAVED_STREAMED_RECOVERED','response_type':row.get('route'),
            'technical_answer_released':row.get('route')=='SUPPORTED' and row.get('saved_view',{}).get('response',{}).get('release_gate_passed')is True,
            'post_retries':0,'six_case_acceptance':False,'independent_factual_quality_acceptance':False,
            'native_count_and_admission_authority':'UNCHANGED_ACTUAL_PRODUCTION_RUNTIME','count2_forecast_used_for_new_query':False,
            'allocation_reset':False,'allocation_refund':False,'billing_changed':False,'raw_provider_bodies_logged':False}
        save(output/'receipt.json',receipt);save(output/'exit_status.json',{'cloud_build_id':job,'exit_code':0 if receipt['transport_delivery_passed'] else 1})
        client.upload_artifacts(args)
    print(json.dumps({'response_type':row.get('route'),'status':row['status'],'post_retries':0,'six_case_acceptance':False}),flush=True)
    return 0 if row['status']=='SAVED_STREAMED_RECOVERED' else 1
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--inventory',required=True);parser.add_argument('--output',required=True)
    parser.add_argument('--allocated-job-id',required=True);parser.add_argument('--artifact-uri',required=True)
    try:sys.exit(main(parser.parse_args()))
    except Exception:print(json.dumps({'failure_code':'SINGLE_SERVICE_DUE_DIAGNOSTIC_FAILED_NO_REPLAY'}),flush=True);sys.exit(1)
