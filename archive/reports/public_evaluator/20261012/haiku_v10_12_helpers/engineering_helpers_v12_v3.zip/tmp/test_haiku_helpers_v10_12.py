"""Synthetic helper boundary tests. No credentials, network or providers."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import MagicMock,patch

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE));sys.path.insert(0,str(BASE/'public_evaluator'));sys.path.insert(0,str(BASE.parent))
import private_acceptance_console_v10_12 as console
import prepare_evaluator_v10_12 as evaluator
import phase_budget_v10_12 as phase
import rollback_public_v10_12 as rollback
import count_only_context_v10_12 as count
from cloud.grounded_generation.role_router import ROUTING_CONTRACT
from cloud.grounded_generation.role_contracts import haiku_maximum_nanodollars

def fixtures():
    pair=ROUTING_CONTRACT['roles']['HAIKU_DRAFT_HAIKU_VERIFY']
    source={'serving_manifest_sha256':'a'*64,'runtime_lock':'b'*64,
        'model_routing_contract_sha256':phase.digest(ROUTING_CONTRACT),
        'files':{'tmp/public_evaluator/count_only_context_v10_12.py':'c'*64,
            'tmp/public_evaluator/count_history_v1.json':'d'*64}}
    cases=[]
    for index in range(6):
        role={'version':ROUTING_CONTRACT['version'],'route':'HAIKU_DRAFT_HAIKU_VERIFY',
            'routing_contract_sha256':phase.digest(ROUTING_CONTRACT),'primary_input_tokens_counted':5000,
            'selected_draft_input_tokens':5000,'initial_draft_request_sha256':'e'*64,
            'stable_context_sha256':'f'*64,'draft_model_contract_sha256':phase.digest(pair['draft']),
            'verifier_contract_sha256':phase.digest(pair['verifier'])}
        def slots(stages):
            values=[]
            for stage,provider in ((stages[0],pair['draft']),(stages[1],pair['verifier'])):
                n=5512 if stage=='draft' else 18000
                values.append({'model':provider['model'],'stage':stage,'input_tokens':n,
                    'output_tokens':provider['output_tokens'],'attempt':1,
                    'maximum_nanodollars':haiku_maximum_nanodollars(n)})
            return values
        stages=[]
        for position,stage in enumerate(phase.NATIVE_STAGES):
            provider=pair['draft'] if position in (0,3) else pair['verifier']
            stages.append({'stage':stage,'model':provider['model'],'role':provider['role'],
                'input_tokens_counted':5000 if position==0 else 1000,
                'counter_body_sha256':'f'*64,'counter_request_bytes':1000})
        cases.append({'case_id':'synthetic'+str(index),'question_sha256':phase.digest('question '+str(index)),
            'role_plan':role,'initial_phase_slots':slots(('draft','verify')),
            'conditional_correction_phase_slots':slots(('correction','reverify')),'native_stages':stages})
    receipt={'schema':'motomedic-hosted-native-count-role-preflight-v3',
        'classification':'HOSTED_NATIVE_COUNTERS_AND_ROLE_FORECAST_ONLY',
        'cloud_build_id':'11111111-2222-4333-8444-555555555555','owner_model_scope_sha256':phase.OWNER_SCOPE_SHA,
        'model_routing_contract_sha256':phase.digest(ROUTING_CONTRACT),'serving_manifest_sha256':'a'*64,
        'runtime_lock':'b'*64,'script_sha256':'c'*64,'history_sha256':'d'*64,'preflight_passed':True,
        'selected_draft_native_window_eligible':True,'selected_draft_actual_quota_eligible':True,
        'known_verifier_fixed_quota_eligible':True,'verifier_synthetic_stress_native_window_eligible':True,
        'transport_allowlist_enforced':True,'provider_allocation_delta_zero':True,'generation_calls':0,
        'reservation_calls':0,'prohibited_transport_calls':0,'case_count':6,'planned_native_counter_calls':36,
        'native_counter_calls':36,'counter_transport_calls':36,'model_metadata_transport_calls':0,
        'ledger_before':{'retained':24},'ledger_after':{'retained':24},
        'actual_finalized_verifier_count_demonstrated':False,'future_finalized_verifier_quota_status':phase.UNKNOWN,
        'declared_native_stage_order':list(phase.NATIVE_STAGES),'cases':cases}
    ledgers={phase.PRIMARY:{'version':'whole-turn-capacity-v1','maximum_attempts':100,'maximum_tokens':999200,
        'reserved_attempts':24,'reserved_tokens':239808},phase.HAIKU_BUDGET:{
        'version':'claude-fallback-nonrecurring-one-dollar-v1','maximum_nanodollars':1000000000,
        'reserved_nanodollars':11544000}}
    inventory={'serving_manifest_sha256':'a'*64,'model_routing_contract_sha256':phase.digest(ROUTING_CONTRACT),
        'model_routing_contract':ROUTING_CONTRACT}
    plan={'cases':[{'case_id':'synthetic'+str(i),'question':'question '+str(i)} for i in range(6)]}
    return source,receipt,ledgers,inventory,plan

class CountAndBudgetTests(unittest.TestCase):
    def test_exact_haiku_count_receipt_and_shared_budget_pass(self):
        source,receipt,ledgers,inventory,plan=fixtures()
        console.validate_count_receipt(receipt,source)
        budget=phase.make_budget(receipt,source,'e'*64,ROUTING_CONTRACT)
        phase.validate_budget(budget,inventory,'b'*64,plan)
        before=copy.deepcopy(ledgers);capacity=phase.capacity_check(budget,0,ledgers)
        self.assertTrue(capacity['eligible']);self.assertEqual(capacity['required']['attempts'],20)
        self.assertEqual(capacity['baseline_retained_charges']['tokens'],239808)
        self.assertEqual(capacity['baseline_retained_charges']['haiku_nanodollars'],11544000)
        self.assertEqual(ledgers,before)
    def test_generation_wrong_release_model_role_stage_body_or_extra_slot_rejects(self):
        for change in ('generation','scope','paid','model','role','stage','body','extra','cost','unknown','order','count'):
            source,receipt,*_=fixtures();row=receipt['cases'][0]
            if change=='generation':receipt['generation_calls']=1
            elif change=='scope':receipt['owner_model_scope_sha256']='f'*64
            elif change=='paid':receipt['ledger_after']={'retained':25}
            elif change=='model':row['native_stages'][0]['model']='retired-provider'
            elif change=='role':row['native_stages'][0]['role']='semantic_verifier'
            elif change=='stage':row['initial_phase_slots'][0]['stage']='verify'
            elif change=='body':row['native_stages'][0]['counter_body_sha256']='missing'
            elif change=='extra':row['initial_phase_slots'].append(copy.deepcopy(row['initial_phase_slots'][0]))
            elif change=='cost':row['initial_phase_slots'][1]['maximum_nanodollars']-=1
            elif change=='unknown':receipt['actual_finalized_verifier_count_demonstrated']=True
            elif change=='order':row['native_stages'].reverse()
            else:row['native_stages'][0]['input_tokens_counted']+=1
            with self.subTest(change=change),self.assertRaises(ValueError):
                phase.make_budget(receipt,source,'e'*64,ROUTING_CONTRACT)
    def test_counters_and_monetary_floor_fail_closed_without_reset(self):
        for allocation,key,value in ((phase.PRIMARY,'reserved_attempts',99),(phase.PRIMARY,'reserved_tokens',990000),
            (phase.HAIKU_BUDGET,'reserved_nanodollars',990000000)):
            source,receipt,ledgers,*_=fixtures();budget=phase.make_budget(receipt,source,'e'*64,ROUTING_CONTRACT)
            ledgers[allocation][key]=value;before=copy.deepcopy(ledgers)
            self.assertFalse(phase.capacity_check(budget,0,ledgers)['eligible']);self.assertEqual(ledgers,before)
    def test_counter_transport_forbids_generation_metadata_redirect_methods(self):
        receipt={'counter_transport_calls':0,'prohibited_transport_calls':0,'_active_counter_record':{}}
        transport=MagicMock(return_value={'input_tokens':100})
        wrapped=count.counter_transport(transport,'messages/count_tokens',receipt)
        self.assertEqual(wrapped('POST','messages/count_tokens',{'model':'synthetic'},'synthetic-not-key'),{'input_tokens':100})
        self.assertEqual(receipt['counter_transport_calls'],1)
        for method,path in (('POST','messages'),('GET','messages/count_tokens'),('POST','models/retired:countTokens')):
            with self.assertRaisesRegex(RuntimeError,'COUNT_TRANSPORT_PATH_PROHIBITED'):wrapped(method,path,{},'synthetic')
        self.assertEqual(transport.call_count,1);self.assertEqual(receipt['prohibited_transport_calls'],3)
    def test_count_recipe_only_binds_anthropic_secret_and_exact_backend(self):
        source,*_=fixtures();image='us-central1-docker.pkg.dev/'+console.cloud.PROJECT+'/motomedic/arm-a@sha256:'+'e'*64
        source.update(count_backend_image=image,service_account=console.run.BACKEND_SA,object='synthetic-exact',generation='123')
        binding={'serving_manifest_sha256':'a'*64,'runtime_revision':'v10_12','images':{'backend':image}}
        recipe=evaluator.count_config(source,binding);step=recipe['steps'][1]
        self.assertEqual(step['secretEnv'],['ANTHROPIC_API_KEY'])
        self.assertIn('MOTOMEDIC_HOSTED_COUNT_ONLY=true',step['env']);self.assertNotIn('--model-metadata',step['args'])
        self.assertEqual(step['name'],image)
        binding['runtime_revision']='v10_11'
        with self.assertRaises(ValueError):evaluator.count_config(source,binding)

class StagedRevisionTests(unittest.TestCase):
    def test_exact_zero_traffic_candidate_ready_does_not_use_latest_ready_revision(self):
        binding={'synthetic_exact_binding':True};name='motomedic-arm-a';revision=rollback.candidate_revision(name)
        saved={'binding':binding,'operations':{name:{'operation':{'name':'synthetic/op'},'expected_revision':revision}}}
        template={'containers':[{'image':'synthetic-digest','env':[]}],
            'serviceAccount':'synthetic-sa','timeout':'1200s','maxInstanceRequestConcurrency':1,
            'scaling':{'minInstanceCount':1,'maxInstanceCount':1}}
        configuration={**copy.deepcopy(template),'executionEnvironment':'EXECUTION_ENVIRONMENT_GEN2'}
        initial={'services':{name:{'revision':'old-serving','template_sha256':'e'*64,
            'revision_configuration':configuration,'revision_configuration_sha256':rollback.digest(configuration)}}}
        service={'latestReadyRevision':'old-serving','latestCreatedRevision':revision,
            'template':{**copy.deepcopy(template),'revision':revision},'trafficStatuses':[{'percent':100,'revision':'old-serving'}]}
        actual={**copy.deepcopy(configuration),'name':revision,'conditions':[{'type':'Ready','state':'CONDITION_SUCCEEDED'}]}
        def api(method,url):
            if url.endswith('synthetic/op'):return {'done':True}
            if '/revisions/' in url:return actual
            return service
        with patch.object(rollback,'release',return_value=(binding,{})),patch.object(rollback,'read',side_effect=lambda key:saved if key.endswith('candidate_operations.json') else initial),\
            patch.object(rollback.run,'api',side_effect=api),patch.object(rollback,'require_service'),\
            patch.object(rollback,'dump'),patch.object(Path,'exists',return_value=False):
            self.assertTrue(rollback.poll()['candidates_ready'])
            actual['conditions'][0]['state']='CONDITION_PENDING';self.assertFalse(rollback.poll()['candidates_ready'])
            actual['conditions'][0]['state']='CONDITION_SUCCEEDED';actual['name']='different-candidate'
            with self.assertRaises(ValueError):rollback.poll()
    def test_config_normalizes_only_generated_container_name_and_keeps_resources(self):
        template={'containers':[{'image':'synthetic-digest','env':[],'resources':{'limits':{'cpu':'2','memory':'8Gi'}}}],
            'serviceAccount':'synthetic-sa','timeout':'1200s','maxInstanceRequestConcurrency':1}
        actual=copy.deepcopy(template);actual['containers'][0]['name']='generated-1';before=copy.deepcopy(actual)
        self.assertTrue(rollback.require_revision_configuration(actual,template));self.assertEqual(actual,before)
        actual['containers'][0]['resources']['limits']['cpu']='1'
        with self.assertRaises(ValueError):rollback.require_revision_configuration(actual,template)

if __name__=='__main__':unittest.main()
