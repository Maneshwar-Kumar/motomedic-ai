"""Isolated actual sibling-import and exact argv check; no network/credentials."""
import json,subprocess,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import prepare_evaluator_v10_12 as helper
class ActualWrapperTests(unittest.TestCase):
 def test_isolated_runpy_can_import_sibling_and_reconstruct_exact_unicode_budget(self):
  budget=json.dumps({'synthetic':'Ω 🏍','nested':[{'budget':1} for _ in range(2500)]},ensure_ascii=False,separators=(',',':'))
  original=['-B','tmp/public_evaluator/hosted_client_v10_12.py','--fixed','synthetic','--measured-phase-budget-json',budget]
  arguments=helper.packed_client_arguments(original)
  self.assertTrue(all(len(x.encode('utf-8'))<=10000 for x in arguments))
  with tempfile.TemporaryDirectory(dir=helper.ROOT/'tmp') as directory:
   root=Path(directory);p=root/'tmp/public_evaluator';p.mkdir(parents=True)
   (p/'phase_budget_v10_12.py').write_text('SYNTHETIC_SIBLING_IMPORTED=True\n')
   (p/'hosted_client_v10_12.py').write_text('import json,sys\nfrom phase_budget_v10_12 import SYNTHETIC_SIBLING_IMPORTED\nprint(json.dumps({"sibling":SYNTHETIC_SIBLING_IMPORTED,"argv":sys.argv}))\n')
   result=subprocess.run([sys.executable,'-I']+arguments,cwd=root,capture_output=True,text=True,timeout=30,check=True)
   decoded=json.loads(result.stdout);self.assertTrue(decoded['sibling']);self.assertEqual(decoded['argv'],original[1:])
 def test_overlong_nonbudget_argument_is_rejected(self):
  with self.assertRaisesRegex(ValueError,'CLOUD_BUILD_ARGUMENT_BYTE_LIMIT'):helper.packed_client_arguments(['-B','tmp/public_evaluator/hosted_client_v10_12.py','x'*10001,'--measured-phase-budget-json','{}'])
if __name__=='__main__':unittest.main()
