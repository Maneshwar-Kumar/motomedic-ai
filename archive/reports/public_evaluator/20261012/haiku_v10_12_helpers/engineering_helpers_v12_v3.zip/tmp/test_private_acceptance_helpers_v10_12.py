"""Synthetic protocol/IAM tests; no credential reads, network or providers."""
import copy
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

BASE = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


console = module('console_v10_12_test', BASE / 'private_acceptance_console_v10_12.py')
client = module('hosted_client_v10_12_test', BASE / 'public_evaluator/hosted_client_v10_12.py')
evaluator = console.evaluator


class RoutingReadinessTests(unittest.TestCase):
    def check(self, mutation=None):
        from cloud.grounded_generation.role_router import ROUTING_CONTRACT
        body = {'ready': True, 'runtime_lock': 'b'*64,
            'answer_provider': 'claude-haiku-5-5', 'verifier_provider': 'claude-haiku-5-5',
            'prompt_cache': 'ANTHROPIC_ROLE_EVIDENCE_PREFIX_5M',
            'model_routing': copy.deepcopy(ROUTING_CONTRACT),
            'manual_checksum': 'cf221a29e2f9cd5af6e80a99774a697c814e8eda661c27d72e519d8a7e80da89',
            'index_id': 'index_a3282c4d98cf54595e4ba168',
            'architecture': 'DRAFT_VERIFY_STREAM_OPEN_MANUAL_QA',
            'streaming': 'DRAFT_VERIFY_STREAM', 'durable_dispatch_configured': True,
            'reranking': 'authenticated-open-hybrid-rank-disagreement-v5'}
        binding = {'serving_manifest_sha256': 'a'*64,
            'images': {'backend': 'synthetic-bound-backend', 'ui': 'synthetic-bound-ui'}}
        saved = {'runtime_lock': 'b'*64, 'versions': {'model_routing_contract': copy.deepcopy(ROUTING_CONTRACT)}}
        if mutation == 'manifest': binding['serving_manifest_sha256'] = 'c'*64
        elif mutation == 'saved_routing': saved['versions']['model_routing_contract']['version'] = 'changed-role-version'
        elif mutation == 'health_routing': body['model_routing']['availability_fallback_enabled'] = True
        elif mutation == 'cache': body['prompt_cache'] = 'ANTHROPIC_VERIFIER_EVIDENCE_PREFIX_5M'
        elif mutation == 'manual': body['manual_checksum'] = 'c'*64
        elif mutation == 'dispatch': body['durable_dispatch_configured'] = False
        def read(name):
            return saved if name.startswith('expected_runtime_lock') else binding
        def api(method, path):
            ui = path.endswith('motomedic-rider-ui')
            return {'terminalCondition': {'state': 'CONDITION_SUCCEEDED'},
                'template': {'containers': [{'image': binding['images']['ui' if ui else 'backend']}]},
                'uri': 'https://synthetic.run.app', 'latestReadyRevision': 'synthetic-private-revision'}
        opener = MagicMock()
        response = opener.open.return_value.__enter__.return_value
        response.status = 200
        response.read.return_value = json.dumps(body).encode()
        with patch.object(console, 'release', return_value='a'*64), \
                patch.object(Path, 'exists', return_value=True), \
                patch.object(console, 'read', side_effect=read), \
                patch.object(console, 'sdk_identity', return_value='synthetic-not-a-token') as sdk, \
                patch.object(console.run, 'api', side_effect=api), \
                patch.object(console.cloud, 'build_opener', return_value=opener), \
                patch.object(console.cloud, 'dump') as dump:
            if mutation:
                with self.assertRaises(ValueError): console.readiness()
                dump.assert_not_called()
                if mutation in ('manifest', 'saved_routing'): sdk.assert_not_called()
            else:
                console.readiness()
                receipt = dump.call_args.args[1]
                self.assertEqual(receipt['provider_calls'], 0)
                self.assertFalse(receipt['public_iam_changed'])
                self.assertEqual(len(receipt['services']), 3)
    def test_exact_saved_routing_contract_source_and_all_private_images_pass(self):
        self.check()
    def test_model_source_cache_dispatch_or_manifest_drift_cannot_claim_readiness(self):
        for mutation in ('manifest','saved_routing','health_routing','cache','manual','dispatch'):
            with self.subTest(mutation=mutation): self.check(mutation)


class SourceGrantTests(unittest.TestCase):
    def values(self):
        prior = {'source': {'object': 'serving/engineering-clients/v10_8/' + 'a' * 64 + '.tar.gz'}}
        source = {'object': 'serving/engineering-clients/v10_12/' + 'b' * 64 + '.tar.gz',
            'sha256': 'b' * 64, 'generation': '123', 'service_account': console.run.BACKEND_SA,
            'artifact_prefix': 'engineering-acceptance/public-v10_3/'}
        old = {'role': console.GET_ROLE, 'members': [console.MEMBER], 'condition': {
            'title': 'motomedic-backend-exact-evaluator-client-v10-10-v7',
            'expression': "resource.name == 'projects/_/buckets/" + console.cloud.BUCKET +
                '/objects/' + prior['source']['object'] + "'"}}
        unrelated = {'role': 'synthetic-role', 'members': ['synthetic-member'],
            'condition': {'expression': 'synthetic unchanged create prefix'}}
        return {'version': 3, 'etag': 'synthetic-etag', 'bindings': [old, unrelated]}, prior, source

    def test_exact_replacement_preserves_every_unrelated_row_and_input(self):
        policy, prior, source = self.values()
        original = copy.deepcopy(policy)
        updated, removed, added = console.source_policy_replacement(policy, prior, source)
        self.assertEqual(policy, original)
        self.assertEqual(updated['etag'], original['etag'])
        self.assertEqual(updated['bindings'][0], original['bindings'][1])
        self.assertNotIn(removed, updated['bindings'])
        self.assertEqual(added['members'], [console.MEMBER])
        self.assertIn(source['object'], added['condition']['expression'])

    def test_missing_etag_or_ambiguous_old_binding_fails(self):
        for mutation in ('etag', 'duplicate', 'additional_member', 'missing'):
            policy, prior, source = self.values()
            if mutation == 'etag': policy.pop('etag')
            elif mutation == 'duplicate': policy['bindings'].append(copy.deepcopy(policy['bindings'][0]))
            elif mutation == 'additional_member': policy['bindings'][0]['members'].append('another-member')
            else: policy['bindings'].pop(0)
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                console.source_policy_replacement(policy, prior, source)

    def test_wrong_source_prefix_hash_generation_principal_or_output_prefix_fails(self):
        for key, wrong in [('object', 'serving/engineering-clients/v10_8/' + 'b' * 64 + '.tar.gz'),
                ('sha256', 'c' * 64), ('generation', 'unknown'), ('service_account', 'other'),
                ('artifact_prefix', 'arbitrary-prefix/')]:
            policy, prior, source = self.values(); source[key] = wrong
            with self.subTest(key=key), self.assertRaises(ValueError):
                console.source_policy_replacement(policy, prior, source)


class SDKIsolationTests(unittest.TestCase):
    def test_sdk_clears_only_pythonpath_and_retains_existing_configuration(self):
        result = SimpleNamespace(returncode=0, stdout='synthetic-access-identity', stderr='')
        with patch.dict(console.os.environ, {'PYTHONPATH': 'synthetic-ui-deps',
                'CLOUDSDK_PYTHON': 'synthetic-sdk-python', 'CLOUDSDK_CONFIG': 'synthetic-existing-config'}), \
                patch.object(console.subprocess, 'run', return_value=result) as run:
            self.assertEqual(console.sdk_identity('print-access-token'), 'synthetic-access-identity')
        environment = run.call_args.kwargs['env']
        self.assertNotIn('PYTHONPATH', environment)
        self.assertEqual(environment['CLOUDSDK_PYTHON'], 'synthetic-sdk-python')
        self.assertEqual(environment['CLOUDSDK_CONFIG'], 'synthetic-existing-config')

    def test_sdk_failures_expose_only_static_error_category(self):
        for error, category in [('invalid_grant synthetic-private-detail', 'CredentialRefreshError'),
                ('PERMISSION_DENIED synthetic-private-detail', 'ApiPermissionError'),
                ('ModuleNotFoundError synthetic-private-detail', 'SDKDependencyError')]:
            with patch.object(console.subprocess, 'run', return_value=SimpleNamespace(
                    returncode=1, stdout='', stderr=error)), self.assertRaises(console.SDKCommandFailure) as raised:
                console.sdk_identity('print-access-token')
            self.assertEqual(raised.exception.sdk_error_category, category)
            self.assertNotIn('synthetic-private-detail', str(raised.exception))


class CountRecipeTests(unittest.TestCase):
    def values(self):
        source = {'serving_manifest_sha256': 'a' * 64, 'runtime_lock': 'b' * 64,
            'files': {'tmp/public_evaluator/count_only_context_v10_12.py': 'c' * 64},
            'service_account': console.run.BACKEND_SA,
            'object': 'serving/engineering-clients/v10_12/' + 'd' * 64 + '.tar.gz', 'generation': '123'}
        binding = {'serving_manifest_sha256': 'a' * 64, 'runtime_revision': 'v10_12',
            'images': {'backend': 'us-central1-docker.pkg.dev/' + console.cloud.PROJECT +
                '/motomedic/arm-a@sha256:' + 'e' * 64}}
        source['count_backend_image'] = binding['images']['backend']
        return source, binding

    def test_count_recipe_uses_bound_backend_and_only_hosted_native_counter_keys(self):
        source, binding = self.values(); config = evaluator.count_config(source, binding)
        self.assertEqual(config['timeout'], '1200s')
        self.assertEqual(config['options']['machineType'], 'E2_HIGHCPU_8')
        step = config['steps'][1]
        self.assertEqual(step['name'], binding['images']['backend'])
        self.assertEqual(step['secretEnv'], ['ANTHROPIC_API_KEY'])
        self.assertNotIn('MOTOMEDIC_VISITOR_SECRET', step['secretEnv'])
        self.assertIn('MOTOMEDIC_CLAUDE_FALLBACK_ENABLED=false', step['env'])
        self.assertIn('MOTOMEDIC_HOSTED_COUNT_ONLY=true', step['env'])
        self.assertEqual(config['source']['storageSource']['generation'], '123')
        self.assertIn('tmp/public_evaluator/count_only_context_v10_12.py', step['args'])
        self.assertNotIn('--model-metadata',step['args'])
        self.assertIn('tmp/public_evaluator/client_inputs_v10_12.json',step['args'])
        self.assertIn('gs://' + console.cloud.BUCKET + '/engineering-acceptance/public-v10_3/$BUILD_ID', step['args'])

    def test_missing_script_or_mismatched_image_release_fails_before_submission(self):
        for mutation in ('script', 'sha', 'revision', 'image'):
            source, binding = self.values()
            if mutation == 'script': source['files'] = {}
            elif mutation == 'sha': binding['serving_manifest_sha256'] = 'f' * 64
            elif mutation == 'revision': binding['runtime_revision'] = 'v10_4'
            else: binding['images']['backend'] = 'synthetic-unbound-image'
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                evaluator.count_config(source, binding)


class ClientProtocolTests(unittest.TestCase):
    def test_stop_gate_avoids_later_paid_cases_and_preserves_old_default(self):
        self.assertIsNone(client.stop_reason({'route': 'SYSTEM_ERROR'}, 1, False))
        self.assertEqual(client.stop_reason({'route': 'SYSTEM_ERROR'}, 1, True),
            'SYSTEM_ERROR_OR_OPERATIONAL_FAILURE')
        self.assertEqual(client.stop_reason({'error': 'TRANSPORT_UNCERTAIN'}, 1, True),
            'SYSTEM_ERROR_OR_OPERATIONAL_FAILURE')
        self.assertEqual(client.stop_reason({'route': 'UNSUPPORTED', 'expected_route_matched': False}, 1, True),
            'FIRST_CANDIDATE_PROBE_NOT_ACCEPTED')
        self.assertIsNone(client.stop_reason({'route': 'SUPPORTED', 'expected_route_matched': True}, 1, True))

    def boundary(self, changed=False, wrong_error=None, expose=False):
        backend = MagicMock(); view = {'synthetic_exact_saved_view': True}
        backend.request.return_value = view
        other = MagicMock()
        if not expose:
            other.request.side_effect = client.EvaluationFailure(wrong_error or 'OPERATION_NOT_FOUND_404')
        args = SimpleNamespace(project='synthetic', backend='https://synthetic.run.app')
        amounts = [{'attempts': 8}, {'attempts': 16 if changed else 8}]
        with patch.object(client, 'ledger', side_effect=amounts), patch.object(client, 'Backend', return_value=other), \
                patch('rider_ui.client.validate_view', side_effect=lambda value, **kwargs: value), \
                patch('rider_ui.identity.issue', return_value='synthetic-other-visitor'):
            result = client.completed_boundaries(backend, args, 'synthetic-not-a-key',
                '/v1/sessions', {'synthetic_original_request': True}, 'a' * 32, view)
        backend.request.assert_called_once_with('POST', '/v1/sessions',
            body={'synthetic_original_request': True}, operation='a' * 32)
        other.request.assert_called_once_with('GET', '/v1/operations/' + 'a' * 32)
        return result

    def test_complete_duplicate_and_valid_wrong_visitor_require_unchanged_ledger(self):
        self.assertEqual(self.boundary()['provider_calls'], 0)

    def test_boundary_cannot_claim_zero_paid_calls_if_ledger_changed(self):
        with self.assertRaisesRegex(client.EvaluationFailure, 'CHANGED_PROVIDER_RESERVATIONS'):
            self.boundary(changed=True)

    def test_invalid_visitor_auth_or_disclosed_operation_is_not_ownership_proof(self):
        with self.assertRaisesRegex(client.EvaluationFailure, 'NOT_OWNERSHIP_REJECTED'):
            self.boundary(wrong_error='VISITOR_CAPABILITY_REQUIRED_401')
        with self.assertRaisesRegex(client.EvaluationFailure, 'OPERATION_DISCLOSED'):
            self.boundary(expose=True)



if __name__ == "__main__":unittest.main()
