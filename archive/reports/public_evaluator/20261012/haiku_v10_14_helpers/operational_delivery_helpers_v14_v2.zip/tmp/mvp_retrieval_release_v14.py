"""Fixed backend-only v14 release actions; import performs no cloud operation."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import sys
from urllib.parse import quote, urlencode

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tmp'))
import public_cloud_run_v10_13_v2 as run
import private_acceptance_console_v10_13_v2 as console
import rollback_public_v10_13 as rollback
import functional_ui_promotion_v13_v2 as promote
import public_ui_preview_v13_v2 as preview
cloud = run.cloud
OUT = cloud.OUT / 'haiku_v10_14_helpers/backend_release_v1'
PAIR = ('motomedic-answer-worker', 'motomedic-arm-a')
UI = 'motomedic-rider-ui'
QDRANT = 'motomedic-qdrant'
SERVICES = PAIR + (UI, QDRANT)
MANIFEST = cloud.OUT / 'serving_manifest_v10_14.json'
PREPARATION = cloud.OUT / 'hosted_build_preparation_v10_14.json'
WRITABLE = frozenset(('scaling', 'vpcAccess', 'timeout', 'serviceAccount', 'containers',
    'volumes', 'executionEnvironment', 'encryptionKey', 'maxInstanceRequestConcurrency',
    'serviceMesh', 'encryptionKeyRevocationAction', 'encryptionKeyShutdownDuration',
    'sessionAffinity', 'nodeSelector', 'gpuZonalRedundancyDisabled', 'labels', 'annotations'))

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name): return json.loads((OUT / name).read_bytes())
def write(name, value):
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / name).open('x', encoding='utf-8') as target:
        json.dump(value, target, indent=2, sort_keys=True); target.write('\n')
def absent(name):
    if (OUT / name).exists(): raise ValueError('UNCERTAIN_OR_COMPLETED_ACTION_MUST_NOT_REPLAY:' + name)
def manifest():
    value = json.loads(MANIFEST.read_bytes())
    if (cloud.OUT / 'serving_manifest_v10_14.sha256').read_text().split()[0] != sha(MANIFEST):
        raise ValueError('EXACT_V14_MANIFEST_SIDECAR_REQUIRED')
    return value
def inputs():
    value = json.loads(PREPARATION.read_bytes()); frozen = manifest()
    if (value['runtime_revision'] != 'v10_14' or value['serving_manifest_sha256'] != sha(MANIFEST)
            or value['input_tree_sha256'] != frozen['input_tree_sha256']):
        raise ValueError('EXACT_PREPARED_V14_BACKEND_SOURCE_REQUIRED')
    ctx = value['contexts']['backend']
    for path, expected in ((ctx['source_archive'], ctx['source_archive_sha256']),
            (ctx['path'] + '/cloudbuild.json', ctx['cloudbuild_sha256']),
            (ctx['path'] + '/Dockerfile', ctx['dockerfile_sha256']),
            (ctx['path'] + '/arm_a_release.json', ctx['installed_manifest_sha256'])):
        if sha(ROOT / path) != expected: raise ValueError('PREPARED_BACKEND_BYTES_CHANGED')
    return value, ctx
def ui_equivalence():
    before = json.loads((cloud.OUT / 'serving_manifest_v10_13.json').read_bytes())
    after = manifest()
    select = lambda files: {name: value for name, value in files.items()
        if name.startswith('rider_ui/') or name == 'controller_contracts.py'}
    old, new = select(before['file_sha256']), select(after['file_sha256'])
    if not old or old != new: raise ValueError('UI_AND_CONTROLLER_PROTOCOL_BYTES_MUST_REMAIN_V13_IDENTICAL')
    binding = json.loads((cloud.OUT / 'hosted_image_binding_v10_13.json').read_bytes())
    return {'ui_runtime_image_revision': 'v10_13', 'ui_image': binding['images']['ui'],
        'v13_manifest_sha256': sha(cloud.OUT / 'serving_manifest_v10_13.json'),
        'v14_manifest_sha256': sha(MANIFEST), 'identical_ui_and_controller_files': old,
        'all_file_hashes_identical': True, 'ui_rebuild_or_deployment': False}
def controls(guard_path):
    guard = preview.guard_receipt(guard_path)
    value = json.loads((ROOT / guard['path']).read_bytes())
    observations = value.get('latest_guard_log_scalars', [])
    if (not observations or observations[0].get('stop') is not False
            or type(observations[0].get('cost_inr')) not in (int, float)
            or not math.isfinite(observations[0]['cost_inr'])
            or not 0 <= observations[0]['cost_inr'] < 2540):
        raise ValueError('LATEST_RECORDED_DISCONNECT_GUARD_MUST_NOT_HAVE_STOPPED')
    ledger = promote.ledger_state()
    if (OUT / 'initial.json').exists(): promote.require_retained_ledger(read('initial.json')['ledger'], ledger)
    return {'guard': guard, 'ledger': ledger}
def row(name, declared_template=None):
    service = run.api('GET', run.PREFIX + name)
    revision = rollback.routed_revision(service)
    actual = run.api('GET', run.PREFIX + name + '/revisions/' + revision)
    rollback.require_ready_revision(actual, revision)
    configuration = rollback.revision_configuration(actual, declared_template or service['template'])
    policy = run.api('GET', run.PREFIX + name + ':getIamPolicy?options.requestedPolicyVersion=3')
    return {'service': service, 'revision': revision, 'revision_configuration': configuration,
        'revision_configuration_sha256': rollback.digest(configuration),
        'service_configuration': promote.ui_service_configuration(service),
        'iam_binding_sha256': rollback.digest(promote.core.policy_rows(policy))}
def unchanged_surrounding(initial):
    for name in (UI, QDRANT):
        actual = row(name); old = initial['services'][name]
        for key in ('revision', 'revision_configuration_sha256', 'service_configuration', 'iam_binding_sha256'):
            if actual[key] != old[key]: raise ValueError('UI_QDRANT_OR_IAM_CHANGED:' + name)
    return True
def prepare(guard_path):
    absent('initial.json'); preparation, context = inputs(); equivalence = ui_equivalence()
    values = {name: row(name) for name in SERVICES}
    old_binding = json.loads((cloud.OUT / 'hosted_image_binding_v10_13.json').read_bytes())
    for name in PAIR:
        if values[name]['revision_configuration']['containers'][0]['image'] != old_binding['images']['backend']:
            raise ValueError('ACTUAL_ORIGINAL_API_WORKER_IMAGE_MUST_BE_V13')
    if values[UI]['revision_configuration']['containers'][0]['image'] != equivalence['ui_image']:
        raise ValueError('ACTUAL_UNCHANGED_UI_V13_IMAGE_REQUIRED')
    flag = [item for item in values[UI]['revision_configuration']['containers'][0].get('env', [])
        if item['name'] == 'MOTOMEDIC_RIDER_ANSWERS_ENABLED']
    if flag != [{'name': 'MOTOMEDIC_RIDER_ANSWERS_ENABLED', 'value': 'true'}]:
        raise ValueError('EXISTING_PUBLIC_UI_ANSWERING_MUST_REMAIN_ENABLED')
    checked = controls(guard_path)
    write('initial.json', {'schema': 'motomedic-v14-backend-only-release-initial-v1',
        'recorded_at_utc': datetime.now(timezone.utc).isoformat(), 'preparation_sha256': sha(PREPARATION),
        'manifest_sha256': sha(MANIFEST), 'source_commit': preparation['source_commit'],
        'runtime_lock_readback_sha256': sha(cloud.OUT / 'expected_runtime_lock_v10_14.json'),
        'ui_equivalence': equivalence, 'services': values, **checked,
        'provider_calls': 0, 'cloud_mutations': 0})
    return {'prepared': True, 'ui_files_identical': True, 'backend_only': True, 'provider_calls': 0}
def require_initial():
    initial = read('initial.json'); inputs()
    if initial['manifest_sha256'] != sha(MANIFEST) or initial['preparation_sha256'] != sha(PREPARATION) or initial['ui_equivalence'] != ui_equivalence():
        raise ValueError('EXACT_RELEASE_INITIAL_INPUTS_CHANGED')
    if initial['runtime_lock_readback_sha256'] != sha(cloud.OUT / 'expected_runtime_lock_v10_14.json'):
        raise ValueError('EXACT_V14_RUNTIME_LOCK_READBACK_CHANGED')
    return initial
def upload(guard_path):
    absent('source_reference.json'); initial = require_initial(); controls(guard_path)
    preparation, ctx = inputs(); archive = ROOT / ctx['source_archive']
    obj = 'serving/v10_14/' + preparation['input_tree_sha256'] + '/backend-' + ctx['source_archive_sha256'] + '.tar.gz'
    intent = {'object': obj, 'sha256': ctx['source_archive_sha256'], 'bytes': archive.stat().st_size,
        'manifest_sha256': sha(MANIFEST), 'ui_upload': False}
    absent('upload_intent.json'); write('upload_intent.json', intent)
    url = 'https://storage.googleapis.com/upload/storage/v1/b/' + cloud.BUCKET + '/o?' + urlencode({'uploadType': 'media', 'name': obj, 'ifGenerationMatch': '0'})
    request = cloud.Request(url, data=archive.read_bytes(), method='POST',
        headers={'Authorization': 'Bearer ' + cloud.token(), 'Content-Type': 'application/gzip'})
    try:
        with cloud.build_opener(cloud.NoRedirect()).open(request, timeout=60) as response: metadata = json.load(response)
    except cloud.HTTPError as exc:
        if exc.code != 412: raise RuntimeError('BACKEND_SOURCE_UPLOAD_FAILED') from None
        metadata = cloud.api('https://storage.googleapis.com/storage/v1/b/' + cloud.BUCKET + '/o/' + quote(obj, safe=''))
    reference = {'uri': 'gs://' + cloud.BUCKET + '/' + obj, 'generation': str(metadata['generation']),
        'sha256': ctx['source_archive_sha256'], 'maximum_bytes': archive.stat().st_size}
    cloud.GCSReader(token=cloud.token).fetch(cloud.ObjectReference(**reference), OUT / 'uploaded_backend_readback.tar.gz')
    write('source_reference.json', {'reference': reference, 'object': obj, 'initial_manifest_sha256': initial['manifest_sha256'], 'provider_calls': 0})
    return {'source_uploaded_and_readback_verified': True, 'generation': reference['generation'], 'provider_calls': 0}
def submit(guard_path):
    absent('build_intent.json'); initial = require_initial(); controls(guard_path)
    preparation, ctx = inputs(); source = read('source_reference.json')
    if source['reference']['sha256'] != ctx['source_archive_sha256'] or source['initial_manifest_sha256'] != sha(MANIFEST):
        raise ValueError('BOUND_BACKEND_SOURCE_CHANGED')
    config = json.loads((ROOT / ctx['path'] / 'cloudbuild.json').read_bytes())
    config['source'] = {'storageSource': {'bucket': cloud.BUCKET, 'object': source['object'], 'generation': source['reference']['generation']}}
    write('build_intent.json', {'config': config, 'source_reference': source, 'provider_calls': 0})
    operation = cloud.api('https://cloudbuild.googleapis.com/v1/projects/' + cloud.PROJECT + '/builds', config)
    write('build_submission.json', {'operation': operation, 'config': config, 'provider_calls': 0})
    return {'id': operation['metadata']['build']['id'], 'backend_builds': 1, 'ui_builds': 0, 'provider_calls': 0}
def poll():
    saved = read('build_submission.json'); job = saved['operation']['metadata']['build']['id']
    if not re.fullmatch(r'[0-9a-f-]{36}', job): raise ValueError('EXACT_BUILD_ID_REQUIRED')
    result = cloud.api('https://cloudbuild.googleapis.com/v1/projects/' + cloud.PROJECT + '/builds/' + job)
    write('build_readback_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ') + '.json', result)
    if result['status'] != 'SUCCESS': return {'id': job, 'status': result['status'], 'provider_calls': 0}
    preparation, ctx = inputs(); source = read('source_reference.json')
    expected_recipe = json.loads((ROOT / ctx['path'] / 'cloudbuild.json').read_bytes())
    if (result.get('source', {}).get('storageSource') != saved['config']['source']['storageSource']
            or len(result.get('steps', [])) != len(expected_recipe['steps'])
            or any(any(actual.get(key) != value for key, value in expected.items())
                for actual, expected in zip(result.get('steps', []), expected_recipe['steps']))
            or any(result.get('substitutions', {}).get(key) != value
                for key, value in expected_recipe['substitutions'].items())):
        raise ValueError('HOSTED_BUILD_SOURCE_PROVENANCE_CHANGED')
    images = result.get('results', {}).get('images', [])
    if len(images) != 1 or images[0].get('name') != ctx['image_tag'] or not re.fullmatch(r'sha256:[0-9a-f]{64}', images[0].get('digest', '')):
        raise ValueError('EXACT_ONE_HOSTED_BACKEND_IMAGE_REQUIRED')
    image = images[0]['name'].split(':serving-')[0] + '@' + images[0]['digest']
    binding = {'schema': 'motomedic-backend-only-v14-build-binding-v1', 'runtime_revision': 'v10_14',
        'serving_manifest_sha256': sha(MANIFEST), 'source_commit': preparation['source_commit'],
        'backend_image': image, 'build_id': job, 'backend_source_reference': source['reference'],
        'runtime_lock': json.loads((cloud.OUT / 'expected_runtime_lock_v10_14.json').read_bytes())['runtime_lock'],
        'installed_manifest_sha256': ctx['installed_manifest_sha256'], 'ui_equivalence': ui_equivalence(),
        'ui_builds': 0, 'provider_calls': 0, 'quality_acceptance': False}
    if not (OUT / 'backend_build_binding.json').exists(): write('backend_build_binding.json', binding)
    elif read('backend_build_binding.json') != binding: raise ValueError('BACKEND_BUILD_BINDING_CHANGED')
    return {'id': job, 'status': 'SUCCESS', 'backend_image': image, 'ui_reused_v13': True, 'provider_calls': 0}
def target(name):
    if name not in PAIR: raise ValueError('ONLY_API_AND_WORKER_DEPLOYMENT_ALLOWED')
    initial = require_initial(); old = initial['services'][name]
    template = deepcopy(old['service']['template'])
    if set(template) - WRITABLE - {'revision'}: raise ValueError('UNKNOWN_WRITABLE_REVISION_TEMPLATE_FIELD')
    binding = read('backend_build_binding.json')
    if binding['serving_manifest_sha256'] != sha(MANIFEST) or binding['ui_equivalence'] != initial['ui_equivalence']:
        raise ValueError('EXACT_BACKEND_IMAGE_BINDING_CHANGED')
    revision = name + '-v10-14-retrieval-v6'
    template['revision'] = revision
    if len(template['containers']) != 1: raise ValueError('EXACT_ONE_BACKEND_CONTAINER_REQUIRED')
    template['containers'][0]['image'] = binding['backend_image']
    material = deepcopy(old['revision_configuration']); material['containers'][0]['image'] = binding['backend_image']
    return template, {'revision': revision, 'revision_configuration': material,
        'revision_configuration_sha256': rollback.digest(material)}
def stage(name, guard_path):
    absent('stage_intent_' + name + '.json'); initial = require_initial(); controls(guard_path); unchanged_surrounding(initial)
    current = row(name); old = initial['services'][name]
    for key in ('revision', 'revision_configuration_sha256', 'service_configuration', 'iam_binding_sha256'):
        if current[key] != old[key]: raise ValueError('ORIGINAL_SERVICE_CHANGED_BEFORE_STAGE')
    template, expected = target(name)
    request = {'etag': current['service']['etag'], 'template': template,
        'traffic': [{'type': 'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION', 'revision': old['revision'], 'percent': 100}]}
    write('stage_intent_' + name + '.json', {'request': request, 'expected': expected, 'provider_calls': 0})
    operation = run.api('PATCH', run.PREFIX + name + '?updateMask=template,traffic', request)
    write('stage_submission_' + name + '.json', {'operation': operation, 'provider_calls': 0})
    return {'staged': name, 'traffic_remains': old['revision'], 'provider_calls': 0}
def ready():
    initial = require_initial(); unchanged_surrounding(initial); rows = {}
    for name in PAIR:
        saved = read('stage_submission_' + name + '.json'); operation = run.api('GET', 'https://run.googleapis.com/v2/' + saved['operation']['name'])
        if operation.get('done') is not True: return {'ready': False, 'provider_calls': 0}
        if operation.get('error'): raise ValueError('BACKEND_STAGE_OPERATION_FAILED')
        service = run.api('GET', run.PREFIX + name); template, expected = target(name)
        if (service['template'] != template or rollback.routed_revision(service) != initial['services'][name]['revision']
                or service.get('latestCreatedRevision', '').split('/')[-1] != expected['revision']
                or promote.ui_service_configuration(service) != initial['services'][name]['service_configuration']):
            raise ValueError('EXACT_STAGED_TEMPLATE_OR_OLD_TRAFFIC_CHANGED')
        actual = run.api('GET', run.PREFIX + name + '/revisions/' + expected['revision'])
        rollback.require_bound_revision(actual, template, expected); rows[name] = expected
    if not (OUT / 'ready_revisions.json').exists(): write('ready_revisions.json', {'services': rows, 'provider_calls': 0})
    return {'ready': True, 'revisions': {name: value['revision'] for name, value in rows.items()}, 'provider_calls': 0}
def route(mode, guard_path):
    if mode not in ('candidate', 'rollback', 'restore'): raise ValueError('FIXED_PAIR_ROUTE_REQUIRED')
    absent(mode + '_route_intent.json'); initial = require_initial(); controls(guard_path); unchanged_surrounding(initial)
    candidates = read('ready_revisions.json')['services']; requests = {}
    if mode != 'candidate': read(('candidate' if mode == 'rollback' else 'rollback') + '_health.json')
    for name in PAIR:
        service = run.api('GET', run.PREFIX + name); template, expected = target(name)
        if service['template'] != template or promote.ui_service_configuration(service) != initial['services'][name]['service_configuration']:
            raise ValueError('STAGED_SERVICE_MATERIAL_CHANGED')
        policy = run.api('GET', run.PREFIX + name + ':getIamPolicy?options.requestedPolicyVersion=3')
        if rollback.digest(promote.core.policy_rows(policy)) != initial['services'][name]['iam_binding_sha256']:
            raise ValueError('BACKEND_IAM_CHANGED')
        destination = initial['services'][name] if mode == 'rollback' else candidates[name]
        origin = candidates[name] if mode == 'rollback' else initial['services'][name]
        if rollback.routed_revision(service) != origin['revision']:
            raise ValueError('EXACT_PAIR_ROUTE_ORIGIN_CHANGED')
        actual = run.api('GET', run.PREFIX + name + '/revisions/' + destination['revision'])
        declared = initial['services'][name]['service']['template'] if mode == 'rollback' else template
        rollback.require_bound_revision(actual, declared, destination)
        requests[name] = {'etag': service['etag'], 'traffic': [{'type': 'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION', 'revision': destination['revision'], 'percent': 100}]}
    write(mode + '_route_intent.json', {'requests': requests, 'provider_calls': 0})
    for name in PAIR:
        operation = run.api('PATCH', run.PREFIX + name + '?updateMask=traffic', requests[name])
        write(mode + '_route_' + name + '.json', {'operation': operation, 'provider_calls': 0})
    return {'routed_pair': mode, 'worker_first': True, 'ui_unchanged': True, 'provider_calls': 0}
def health(mode, guard_path):
    if mode not in ('candidate', 'rollback', 'restore'): raise ValueError('FIXED_HEALTH_MODE_REQUIRED')
    initial = require_initial(); checked = controls(guard_path); unchanged_surrounding(initial)
    lock_file = cloud.OUT / ('expected_runtime_lock_v10_13.json' if mode == 'rollback' else 'expected_runtime_lock_v10_14.json')
    lock = json.loads(lock_file.read_bytes())['runtime_lock']; rows = {}
    for name in PAIR:
        template, candidate = target(name)
        declared = initial['services'][name]['service']['template'] if mode == 'rollback' else template
        current = row(name, declared)
        expected = initial['services'][name] if mode == 'rollback' else read('ready_revisions.json')['services'][name]
        if current['revision'] != expected['revision'] or current['revision_configuration_sha256'] != expected['revision_configuration_sha256']:
            raise ValueError('EXACT_ROUTED_PAIR_REVISION_REQUIRED')
        if any(current[key] != initial['services'][name][key]
                for key in ('service_configuration', 'iam_binding_sha256')):
            raise ValueError('ROUTED_SERVICE_CONFIGURATION_OR_IAM_CHANGED')
        request = cloud.Request(current['service']['uri'] + '/v1/health')
        with cloud.build_opener(cloud.NoRedirect()).open(request, timeout=60) as response:
            body = json.loads(response.read(65536)); status = response.status
        wanted = {'ready': True, 'runtime_lock': lock, 'answer_provider': 'claude-haiku-5-5',
            'verifier_provider': 'claude-haiku-5-5', 'index_id': 'index_a3282c4d98cf54595e4ba168',
            'manual_checksum': 'cf221a29e2f9cd5af6e80a99774a697c814e8eda661c27d72e519d8a7e80da89',
            'reranking': 'authenticated-open-hybrid-rank-disagreement-' + ('v5' if mode == 'rollback' else 'v6')}
        if status != 200 or any(body.get(key) != value for key, value in wanted.items()): raise ValueError('EXACT_ROUTED_V14_HEALTH_REQUIRED')
        rows[name] = {'revision': current['revision'], 'http_status': status, 'health': body}
    checked_after = controls(guard_path); promote.require_retained_ledger(checked['ledger'], checked_after['ledger'])
    write(mode + '_health.json', {'schema': 'motomedic-backend-only-pair-health-v1', 'services': rows,
        'controls_before': checked, 'controls_after': checked_after, 'ui_equivalence': initial['ui_equivalence'],
        'provider_calls': 0, 'quality_acceptance': False})
    return {'pair_health_passed': True, 'mode': mode, 'ui_remains_v13': True, 'provider_calls': 0}

if __name__ == '__main__':
    cloud.token = console.token
    args = sys.argv[1:]
    if args == ['--check-only']: result = {'actions': ['prepare', 'upload', 'submit', 'poll', 'stage', 'ready', 'route', 'health'], 'cloud_calls': 0, 'provider_calls': 0, 'ui_build_or_deploy': False}
    elif len(args) == 2 and args[0] in ('prepare', 'upload', 'submit'): result = globals()[args[0]](args[1])
    elif args == ['poll']: result = poll()
    elif args == ['ready']: result = ready()
    elif len(args) == 3 and args[0] in ('stage', 'route', 'health'): result = globals()[args[0]](args[1], args[2])
    else: raise SystemExit('ONE_FIXED_BACKEND_ONLY_V14_ACTION_REQUIRED')
    print(json.dumps(result), flush=True)
