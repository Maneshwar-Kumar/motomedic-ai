"""Restore only the known-good v14 pair after two recorded rollback health timeouts."""
import json
from pathlib import Path
import sys
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import mvp_retrieval_rollback_v14_v3 as bridge
corrected, prior = bridge.corrected, bridge.prior

def restore(guard_path):
    candidate = bridge.health_receipt('candidate')
    initial = prior.require_initial()
    intent = prior.read('rollback_route_intent.json')
    if set(intent.get('requests', {})) != set(prior.PAIR) or intent.get('provider_calls') != 0:
        raise ValueError('EXACT_PRIOR_OLD13_ROLLBACK_PAIR_INTENT_REQUIRED')
    journals = {}
    for name in prior.PAIR:
        request = intent['requests'][name]
        expected = [{'type': 'TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION',
            'revision': initial['services'][name]['revision'], 'percent': 100}]
        journal = prior.read('rollback_route_' + name + '.json')
        operation = journal.get('operation', {})
        if (set(request) != {'etag', 'traffic'} or not request['etag'] or request['traffic'] != expected
                or journal.get('provider_calls') != 0
                or not operation.get('name', '').startswith('projects/' + prior.cloud.PROJECT + '/locations/us-central1/operations/')
                or operation.get('metadata', {}).get('name') != 'projects/' + prior.cloud.PROJECT + '/locations/us-central1/services/' + name):
            raise ValueError('EXACT_SUBMITTED_OLD13_TRAFFIC_JOURNAL_REQUIRED')
        journals[name] = corrected.reference(prior.OUT / ('rollback_route_' + name + '.json'))
    if (corrected.OUT / 'rollback_health.json').exists() or (prior.OUT / 'rollback_health.json').exists():
        raise ValueError('USE_ACTUAL_PASSED_HEALTH_ROUTE_WHEN_PRESENT')
    failures = []
    for number in (1, 2):
        path = corrected.OUT / ('rollback_health_timeout_v' + str(number) + '.json')
        value = json.loads(path.read_bytes())
        if (value.get('schema') != 'motomedic-readonly-rollback-health-timeout-v1'
                or value.get('helper') != 'tmp/mvp_retrieval_release_v14_v2.py'
                or value.get('action') != 'health rollback' or value.get('error_type') != 'TimeoutError'
                or value.get('HTTP_timeout_seconds') != 60 or value.get('provider_calls') != 0
                or value.get('traffic_mutations_by_failed_health_check') != 0
                or value.get('quality_acceptance') is not False or value.get('pair_health_passed') is True
                or (number == 2 and value.get('attempt') != 2)):
            raise ValueError('EXACT_TWO_RECORDED_READONLY_HEALTH_FAILURES_REQUIRED')
        failures.append(corrected.reference(path))
    prior.controls(guard_path)
    failure = {'schema': 'motomedic-explicit-known-good14-emergency-restore-v1',
        'classification': 'RESTORE_AFTER_FAILED_ROLLBACK_HEALTH',
        'authority': 'EXPLICIT_COORDINATOR_RECOVERY_FOR_OWNER_AUTHORIZED_WORKING_MVP',
        'rollback_pair_health_passed': False, 'rollback_validation_complete': False,
        'known_good_v14_candidate_health': corrected.reference(corrected.OUT / 'candidate_health.json'),
        'corrected_backend_binding': corrected.reference(corrected.BINDING),
        'old13_rollback_intent': corrected.reference(prior.OUT / 'rollback_route_intent.json'),
        'old13_route_journals': journals, 'read_only_health_failures': failures,
        'provider_calls': 0, 'old_health_receipt_created_or_overwritten': False,
        'automatic_health_retry_or_paid_operation_replay': False}
    corrected.write('emergency_restore_decision_v1.json', failure)
    original_read = prior.read
    def truthful_failed_health(name):
        return failure if name == 'rollback_health.json' else original_read(name)
    # Recovery changes only the named operational health prerequisite. The prior
    # route retains exact known14 source/image, old13 current origin, immutable
    # Ready/material checks, IAM/service config, etag, guard/ledger and worker-first traffic.
    with patch.object(prior, 'read', truthful_failed_health):
        result = prior.route('restore', guard_path)
    return {**result, 'classification': failure['classification'], 'rollback_pair_health_passed': False,
        'decision': corrected.reference(corrected.OUT / 'emergency_restore_decision_v1.json')}

if __name__ == '__main__':
    prior.cloud.token = prior.console.token
    args = sys.argv[1:]
    if args == ['--check-only']:
        result = {'actions': ['restore'], 'cloud_calls': 0, 'provider_calls': 0,
            'runtime_or_UI_changes': False, 'old_rollback_health_acceptance_claimed': False}
    elif len(args) == 2 and args[0] == 'restore': result = restore(args[1])
    else: raise SystemExit('ONLY_EXPLICIT_KNOWN_GOOD14_RECOVERY_RESTORE_ALLOWED')
    print(json.dumps(result), flush=True)
