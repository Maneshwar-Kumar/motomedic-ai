"""Read only the response reference shown in the coordinator's browser test."""
import json,sys,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import private_acceptance_console_v10_13_v4 as console
from hosted_client_v10_13_v2 import firestore_value
def decode(v):
 if 'mapValue' in v:return {k:decode(x) for k,x in v['mapValue'].get('fields',{}).items()}
 if 'arrayValue' in v:return [decode(x) for x in v['arrayValue'].get('values',[])]
 if 'doubleValue' in v:
  n=float(v['doubleValue'])
  if not math.isfinite(n):raise ValueError('NONFINITE_DIAGNOSTIC')
  return n
 return firestore_value(v)
run=console.run;run.cloud.token=console.token
from urllib.parse import urlencode
paths=('view.response.type','view.runtime_controls.composition','view.runtime_controls.source_admission')
url='https://firestore.googleapis.com/v1/projects/motomedic-ai-20261009/databases/(default)/documents:runQuery'
query={'structuredQuery':{'from':[{'collectionId':'arm_a_sessions'}],
 'where':{'fieldFilter':{'field':{'fieldPath':'view.response.trace_id'},'op':'EQUAL','value':{'stringValue':'d7ade0aeedb64cb1a700914f9b4e4d77'}}},
 'select':{'fields':[{'fieldPath':p} for p in paths]},'limit':1}}
body=run.api('POST',url,query)
documents=[r['document'] for r in body if 'document' in r]
if len(documents)!=1:raise ValueError('EXACT_OWN_BROWSER_TRACE_NOT_FOUND')
result={k:decode(v) for k,v in documents[0].get('fields',{}).items()}
target=Path('reports/public_evaluator/20261012/haiku_v10_14_helpers/browser_service_due_failure_trace_v1.json')
with target.open('x',encoding='utf-8') as f:json.dump(result,f,sort_keys=True,indent=2)
c=result.get('view',{}).get('runtime_controls',{})
print(json.dumps({'route':result.get('view',{}).get('response',{}).get('type'),'composition':c.get('composition'),'source_admission':c.get('source_admission')}))
