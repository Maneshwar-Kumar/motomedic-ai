'use strict';

// Ignored engineering harness. Never writes cookies, tokens, provider bodies,
// rider history or source text. Only the selected UI and citation metadata are
// captured. Real execution requires coordinator-provided URL and permission.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { chromium } = require('playwright');

const VERSION = 'public-evaluator-browser-service-due-v14';
const QUESTION = 'When is the service due for my bike?';
const ROOT = path.resolve(__dirname, '../..');
const sha256 = text => crypto.createHash('sha256').update(text).digest('hex');
const STAGES = ['Retrieving manual information.', 'Drafting your answer.',
  'Checking the answer against the manual.', 'Displaying the verified answer.'];

function argument(name, fallback) {
  const at = process.argv.indexOf(name);
  return at === -1 ? fallback : process.argv[at + 1];
}

function ensure(value, code) {
  if (!value) throw Object.assign(new Error(code), { safeCode: code });
}

function questionInput(page, label) {
  return page.getByPlaceholder(label, { exact: true })
    .or(page.getByRole('textbox', { name: label, exact: true })).first();
}

async function confirmScope(page) {
  const label = 'My motorcycle is a Himalayan BS6';
  const checkbox = page.getByRole('checkbox', { name: label, exact: true });
  await checkbox.waitFor({ state: 'visible', timeout: 15000 });
  ensure(await checkbox.isEnabled(), 'SCOPE_CONFIRMATION_DISABLED');
  if (!await checkbox.isChecked()) {
    // Streamlit renders a styled input; use the same visible label a rider uses.
    // Never force a click, set DOM state, or treat a successful click as approval.
    await page.getByText(label, { exact: true }).click({ timeout: 15000 });
  }
  const deadline = Date.now() + 15000;
  while (!await checkbox.isChecked() && Date.now() < deadline) await page.waitForTimeout(100);
  ensure(await checkbox.isChecked(), 'SCOPE_CONFIRMATION_NOT_CHECKED');
}

async function readyInput(page, label) {
  const entry = questionInput(page, label);
  await entry.waitFor({ state: 'visible', timeout: 60000 });
  const deadline = Date.now() + 60000;
  while (!await entry.isEnabled() && Date.now() < deadline) await page.waitForTimeout(100);
  ensure(await entry.isEnabled(), 'QUESTION_INPUT_DISABLED');
  return entry;
}

async function widgetMetadata(page) {
  return page.locator('input:not([type="hidden"]):not([type="password"]), textarea')
    .evaluateAll(elements => elements.slice(0, 25).map(element => ({
      placeholder: element.getAttribute('placeholder'),
      aria_label: element.getAttribute('aria-label'),
      disabled: element.disabled === true || element.getAttribute('aria-disabled') === 'true'
    })));
}

async function observe(page) {
  await page.evaluate(stages => {
    window.__mmBrowserCheck = { started: performance.now(), stages: [],
      streamTexts: [], firstTechnicalStage: null, mutationCount: 0 };
    const record = () => {
      const state = window.__mmBrowserCheck;
      if (!state) return;
      state.mutationCount++;
      const body = document.body.innerText;
      for (const stage of stages) if (body.includes(stage) && !state.stages.includes(stage))
        state.stages.push(stage);
      for (const element of document.querySelectorAll('[data-testid="stText"]')) {
        if (element.closest('[data-testid="stChatMessage"]')) continue;
        const text = element.innerText;
        if (!text || text.length < 15 || state.streamTexts.includes(text)) continue;
        state.streamTexts.push(text);
        if (state.firstTechnicalStage === null)
          state.firstTechnicalStage = state.stages.at(-1) || 'NOT_OBSERVED';
      }
    };
    window.__mmMutationObserver?.disconnect();
    window.__mmMutationObserver = new MutationObserver(record);
    window.__mmMutationObserver.observe(document.body,
      { childList: true, subtree: true, characterData: true });
    record();
  }, STAGES);
}

async function acceptedTurn(page, text, inputLabel, out, number, timeout, onSubmit) {
  const entry = await readyInput(page, inputLabel);
  const initialChats = await page.locator('[data-testid="stChatMessage"]').count();
  await observe(page);
  const started = Date.now();
  await entry.fill(text);
  onSubmit();  // Conservatively retain a submission if keypress/transport is uncertain.
  await entry.press('Enter');
  let screenshotTaken = false;
  let recovered = false;
  // Poll browser UI; never retry a mutation or send another question on error.
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const streamLength = await page.evaluate(() =>
      window.__mmBrowserCheck?.streamTexts.length || 0);
    if (streamLength && !screenshotTaken) {
      await page.screenshot({ path: path.join(out, `turn_${number}_stream.png`), fullPage: true });
      screenshotTaken = true;
    }
    const recovery = page.getByRole('button', { name: 'Reconnect and retrieve result', exact: true });
    if (await recovery.count() && await recovery.isVisible()) {
      // Explicit UI recovery reads the saved operation. It does not regenerate.
      await recovery.click();
      recovered = true;
    }
    const next = questionInput(page, 'Ask another question…');
    const chats = await page.locator('[data-testid="stChatMessage"]').count();
    if (chats >= initialChats + 2 && await next.count() && await next.isEnabled()) break;
    await page.waitForTimeout(1000);
  }
  ensure(Date.now() < deadline, 'ANSWER_OR_RECOVERY_DEADLINE_EXCEEDED');
  const messages = page.locator('[data-testid="stChatMessage"]');
  const answer = messages.last();
  ensure(await answer.getByText('Answer', { exact: true }).count() === 1,
    'NO_SUPPORTED_TECHNICAL_RESPONSE');
  const body = await answer.locator('[data-testid="stText"]').first().innerText();
  ensure(body.trim().length > 0, 'ANSWER_TEXT_EMPTY');
  const citation = answer.getByText(/^Source · PDF pages? /);
  ensure(await citation.count() === 1, 'CITATION_METADATA_NOT_RENDERED');
  await citation.click();
  ensure(await answer.getByText('Display of original PDF pages and excerpts is restricted.',
    { exact: true }).count() === 1, 'CITATION_DISPLAY_POLICY_NOT_RENDERED');
  const observation = await page.evaluate(() => window.__mmBrowserCheck || {});
  const partials = observation.streamTexts || [];
  const stream = partials.filter(value => body.startsWith(value));
  ensure(!partials.some(value => !body.startsWith(value)), 'UNBOUND_TRANSIENT_TEXT_RENDERED');
  await page.screenshot({ path: path.join(out, `turn_${number}_accepted.png`), fullPage: true });
  return { turn: number, question_sha256: sha256(text), route: 'SUPPORTED',
    rendered_text_sha256: sha256(body), rendered_characters: [...body].length,
    citation_heading_sha256: sha256(await citation.innerText()),
    elapsed_seconds: Math.round((Date.now() - started) / 10) / 100,
    ui_recovery_used: recovered,
    observed_progress_stages: observation.stages || [],
    stream_rendering_observed: stream.length > 0,
    distinct_stream_renderings: stream.length,
    stream_prefixes_match_final: stream.every(value => body.startsWith(value)),
    first_transient_stage: observation.firstTechnicalStage || 'NOT_OBSERVED',
    screenshots: [screenshotTaken ? `turn_${number}_stream.png` : null,
      `turn_${number}_accepted.png`].filter(Boolean),
    browser_source_display: 'UI_PARAPHRASES_AND_CITATION_METADATA_ONLY',
    independent_source_quality_acceptance: false,
    backend_sse_binding_acceptance: 'REQUIRES_CORRELATED_HOSTED_RECEIPT' };
}

async function main() {
  const selfCheck = process.argv.includes('--self-check');
  const shellOnly = process.argv.includes('--shell-only');
  const privateToken = (process.env.MOTOMEDIC_PRIVATE_TEST_ID_TOKEN || '').trim();
  delete process.env.MOTOMEDIC_PRIVATE_TEST_ID_TOKEN;
  ensure(!privateToken || shellOnly, 'PRIVATE_IDENTITY_REQUIRES_SHELL_ONLY');
  ensure(!privateToken || /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(privateToken),
    'PRIVATE_IDENTITY_TOKEN_INVALID');
  ensure(!process.argv.includes('--follow-up'), 'SINGLE_SERVICE_DUE_TURN_ONLY');
  const execute = process.argv.includes('--execute-authorized');
  const out = path.resolve(argument('--output', path.join(__dirname, 'browser-output')));
  ensure(out.startsWith(path.join(ROOT, 'tmp') + path.sep), 'OUTPUT_MUST_STAY_IN_IGNORED_TMP');
  const browserPath = argument('--browser', 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe');
  ensure(fs.existsSync(browserPath), 'BROWSER_EXECUTABLE_UNAVAILABLE');
  ensure(selfCheck || execute, 'URL_AND_EXPLICIT_EXECUTION_AUTHORIZATION_REQUIRED');
  let url;
  let release;
  if (!selfCheck) {
    const value = new URL(argument('--url', ''));
    ensure(value.protocol === 'https:' && value.hostname.endsWith('.run.app') &&
      value.pathname === '/' && !value.username && !value.password && !value.search && !value.hash,
      'EXACT_PUBLIC_CLOUD_RUN_ORIGIN_REQUIRED');
    url = value.origin;
    release = argument('--release-sha', '');
    ensure(/^[a-f0-9]{64}$/.test(release), 'FROZEN_RELEASE_SHA_REQUIRED');
  }
  ensure(!fs.existsSync(out), 'VERSIONED_BROWSER_OUTPUT_ALREADY_EXISTS');
  fs.mkdirSync(out, { recursive: true });
  const receipt = { schema_version: VERSION, recorded_at_utc: new Date().toISOString(),
    script_sha256: sha256(fs.readFileSync(__filename)),
    expected_runtime_policy: 'open-manual-haiku-draft-verify-v10_13',
    target_backend_serving_revision: 'v10_14', reused_ui_revision: 'v10_13',
    acceptance_scope: 'ONE_PUBLIC_SERVICE_DUE_ANSWER_WITH_CITATION',
    runtime_policy_directly_observed: false,
    runtime_policy_evidence: 'REQUIRES_CORRELATED_PRIVATE_READINESS_AND_SAVED_OPERATION_BINDING',
    execution: selfCheck ? 'SYNTHETIC_BROWSER_ABOUT_BLANK_ONLY' :
      privateToken ? 'AUTHORIZED_PRIVATE_SHELL_NO_QUESTION' :
      shellOnly ? 'AUTHORIZED_PUBLIC_SHELL_NO_QUESTION' : 'AUTHORIZED_PUBLIC_BROWSER',
    provider_bodies_logged: false, cookie_values_logged: false,
    raw_page_text_logged: false, raw_network_trace_saved: false, ui_turn_submissions: 0,
    actual_provider_calls: 'REQUIRES_CORRELATED_HOSTED_RECEIPT', turns: [] };
  let browser;
  let page;
  let pageErrorCount = 0;
  let websocketCount = 0;
  let visitorStatus = null;
  let errorStage = 'BROWSER_LAUNCH';
  try {
    browser = await chromium.launch({ executablePath: browserPath, headless: true });
    receipt.browser_version = browser.version();
    errorStage = 'BROWSER_CONTEXT';
    const context = await browser.newContext({ viewport: { width: 1440, height: 1100 },
      deviceScaleFactor: 1, serviceWorkers: 'block',
      ...(privateToken && !selfCheck ?
        { extraHTTPHeaders: { Authorization: 'Bearer ' + privateToken } } : {}) });
    if (privateToken && !selfCheck) {
      // Block every other network origin before transmitting the scoped token,
      // including redirects, subresources and WebSocket handshakes.
      await context.route('**/*', route => {
        if (new URL(route.request().url()).origin !== url) return route.abort('blockedbyclient');
        return route.continue();
      });
      await context.routeWebSocket('**/*', socket => {
        const target = new URL(socket.url());
        if (target.protocol !== 'wss:' || 'https://' + target.host !== url)
          return socket.close({ code: 1008, reason: 'SCOPED_PRIVATE_ORIGIN_REQUIRED' });
        socket.connectToServer();
      });
      receipt.private_authentication = {
        source: 'SHORT_LIVED_OWNER_IDENTITY_TOKEN_IN_MEMORY', scoped_origin: url,
        all_other_http_and_websocket_origins_blocked: true, paid_turns_forbidden: true };
    }
    page = await context.newPage();
    page.on('pageerror', () => pageErrorCount++);
    page.on('websocket', socket => { if (new URL(socket.url()).pathname === '/_stcore/stream') websocketCount++; });
    page.on('response', response => {
      if (new URL(response.url()).pathname === '/_visitor') visitorStatus = response.status();
    });
    if (selfCheck) {
      errorStage = 'OFFLINE_SELF_CHECK';
      await page.goto('about:blank');
      await page.setContent('<button>safe engineering fixture</button>' +
        '<label><input type="checkbox" aria-label="My motorcycle is a Himalayan BS6"' +
        ' style="position:absolute;width:1px;height:1px;opacity:0">' +
        '<span>My motorcycle is a Himalayan BS6</span></label>' +
        '<textarea disabled placeholder="Ask a question…" aria-label="Streamlit chat input"></textarea>' +
        '<div id="caption"></div><div data-testid="stText" id="stream"></div>' +
        '<div data-testid="stChatMessage"><div data-testid="stText">synthetic prior chat</div></div>');
      ensure(await page.getByRole('button', { name: 'safe engineering fixture' }).count() === 1,
        'BROWSER_SELECTOR_SELF_CHECK_FAILED');
      await page.evaluate(() => document.querySelector('input[type="checkbox"]')
        .addEventListener('change', event => {
          document.querySelector('textarea').disabled = !event.target.checked;
        }));
      await confirmScope(page);
      ensure(await (await readyInput(page, 'Ask a question…')).isEnabled(),
        'BROWSER_PLACEHOLDER_SELECTOR_SELF_CHECK_FAILED');
      const metadata = await widgetMetadata(page);
      ensure(metadata.length === 2 && metadata[1].placeholder === 'Ask a question…' &&
        metadata[1].aria_label === 'Streamlit chat input' && metadata[1].disabled === false &&
        metadata.every(value => Object.keys(value).length === 3),
        'BROWSER_WIDGET_METADATA_SELF_CHECK_FAILED');
      await observe(page);
      await page.evaluate(() => {
        document.getElementById('caption').innerText = 'Displaying the verified answer.';
        document.getElementById('stream').innerText = 'Synthetic neutral browser response.';
      });
      await page.waitForFunction(() => window.__mmBrowserCheck.streamTexts.length === 1);
      ensure(await page.evaluate(() =>
        window.__mmBrowserCheck.firstTechnicalStage === 'Displaying the verified answer.' &&
        window.__mmBrowserCheck.streamTexts[0] === 'Synthetic neutral browser response.'),
        'BROWSER_STREAM_OBSERVER_SELF_CHECK_FAILED');
      receipt.external_requests = 0;
      receipt.actual_provider_calls = 0;
      receipt.status = 'PASS';
    } else {
      receipt.public_origin = url;
      receipt.expected_release_manifest_sha256 = release;
      // Use Chrome's TLS trust and the same scoped network routing as the UI.
      // A readiness redirect is never accepted, including within this origin.
      errorStage = 'GATEWAY_HEALTH_NAVIGATION';
      const health = await page.goto(url + '/health', { waitUntil: 'domcontentloaded', timeout: 20000 });
      ensure(health && health.url() === url + '/health' && !health.request().redirectedFrom(),
        'PUBLIC_GATEWAY_HEALTH_REDIRECT_FORBIDDEN');
      ensure(health.status() === 200, 'PUBLIC_GATEWAY_HEALTH_UNREADY');
      errorStage = 'GATEWAY_HEALTH_JSON';
      const readiness = JSON.parse(await health.text());
      ensure(Object.keys(readiness).length === 1 && readiness.ready === true,
        'PUBLIC_GATEWAY_HEALTH_INVALID');
      receipt.gateway_health = { path: '/health', status: health.status(), ready: true };
      const timeout = Number(argument('--timeout-seconds', '1320')) * 1000;
      ensure(Number.isInteger(timeout) && timeout >= 150000 && timeout <= 1500000,
        'BROWSER_TIMEOUT_INVALID');
      errorStage = 'UI_NAVIGATION';
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
      errorStage = 'UI_PROOF_COOKIE_WEBSOCKET';
      await page.getByText('MotoMedic handles your routine queries for your Himalayan',
        { exact: true }).waitFor({ timeout: 120000 });
      const cookies = await context.cookies(url);
      const visitor = cookies.find(cookie => cookie.name === '__Host-motomedic-visitor');
      ensure(visitor && visitor.secure && visitor.httpOnly && visitor.sameSite === 'Lax' &&
        visitor.path === '/', 'SIGNED_VISITOR_COOKIE_NOT_OBSERVED');
      ensure(visitorStatus === 200 && websocketCount > 0, 'PROOF_OR_STREAMLIT_SOCKET_NOT_READY');
      receipt.public_admission = { proof_submission_status: visitorStatus,
        cookie_secure: visitor.secure, cookie_http_only: visitor.httpOnly,
        cookie_same_site: visitor.sameSite, streamlit_socket_opened: true };
      errorStage = 'UI_SCOPE_CONFIRMATION';
      await page.screenshot({ path: path.join(out, 'ui_before_scope_confirmation.png'), fullPage: true });
      receipt.widget_metadata_before_scope = await widgetMetadata(page);
      await confirmScope(page);
      receipt.scope_checkbox_checked = true;
      errorStage = 'UI_QUESTION_INPUT_READY';
      await readyInput(page, 'Ask a question…');
      receipt.question_input_enabled = true;
      receipt.widget_metadata_after_scope = await widgetMetadata(page);
      await page.screenshot({ path: path.join(out, 'public_scope_confirmed.png'), fullPage: true });
      if (shellOnly) {
        ensure(receipt.ui_turn_submissions === 0 && receipt.turns.length === 0,
          'SHELL_MODE_QUESTION_SUBMISSION_FORBIDDEN');
        receipt.actual_provider_calls = 0;
        receipt.provider_call_scope = 'NO_QUESTION_SUBMITTED_BY_THIS_HARNESS';
      } else {
        errorStage = 'AUTHORIZED_QUESTION_TURN';
        const submitted = () => receipt.ui_turn_submissions++;
        receipt.turns.push(await acceptedTurn(page, QUESTION, 'Ask a question…', out, 1, timeout, submitted));
        ensure(receipt.ui_turn_submissions === 1 && receipt.turns.length === 1,
          'EXACTLY_ONE_SERVICE_DUE_TURN_REQUIRED');
      }
      errorStage = 'FINAL_UI_CHECKS';
      receipt.no_horizontal_overflow = await page.evaluate(() =>
        document.documentElement.scrollWidth <= window.innerWidth);
      receipt.status = privateToken ? 'PASS_PRIVATE_SHELL_NO_QUESTION' :
        shellOnly ? 'PASS_PUBLIC_SHELL_NO_QUESTION' : 'PASS_UI_BOUNDARY_OBSERVATION';
      receipt.independent_factual_quality_acceptance = false;
      receipt.full_release_acceptance = false;
      receipt.stream_visibility_limits = 'Browser DOM may coalesce chunks; backend exact SSE/verifier/cache proofs must be joined separately.';
    }
    receipt.page_error_count = pageErrorCount;
    receipt.streamlit_socket_count = websocketCount;
    ensure(pageErrorCount === 0, 'BROWSER_PAGE_ERROR_OBSERVED');
  } catch (error) {
    receipt.status = 'FAIL';
    receipt.failure_stage = errorStage;
    receipt.error_name = ['Error', 'TimeoutError', 'TypeError', 'SyntaxError', 'RangeError']
      .includes(error.name) ? error.name : 'OtherError';
    receipt.failure_code = error.safeCode ||
      (error.name === 'TimeoutError' ? 'BROWSER_WAIT_TIMEOUT' : 'BROWSER_EXECUTION_FAILED');
    receipt.submission_status_may_be_uncertain = receipt.ui_turn_submissions > receipt.turns.length;
    receipt.page_error_count = pageErrorCount;
    receipt.streamlit_socket_count = websocketCount;
    if (page && !selfCheck && (errorStage.startsWith('UI_') ||
        errorStage === 'AUTHORIZED_QUESTION_TURN' || errorStage === 'FINAL_UI_CHECKS')) {
      try {
        receipt.widget_metadata_at_failure = await widgetMetadata(page);
        await page.screenshot({ path: path.join(out, 'ui_failure.png'), fullPage: true });
        receipt.failure_screenshot = 'ui_failure.png';
      } catch (_) {
        receipt.failure_screenshot_unavailable = true;
      }
    }
  } finally {
    if (browser) await browser.close();
    fs.writeFileSync(path.join(out, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  }
  console.log(JSON.stringify(receipt));
  return receipt.status.startsWith('PASS') ? 0 : 1;
}

main().then(code => { process.exitCode = code; }).catch(() => {
  console.log(JSON.stringify({ schema_version: VERSION, status: 'FAIL',
    failure_code: 'BROWSER_ARGUMENT_OR_RUNTIME_UNAVAILABLE' }));
  process.exitCode = 1;
});
