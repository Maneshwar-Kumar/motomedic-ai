"""Only bridge corrected v2 health receipts into unchanged v14 traffic gates."""
import json
from pathlib import Path
import sys
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import mvp_retrieval_release_v14_v2 as corrected
prior = corrected.prior

def health_receipt(mode):
    binding = corrected.require_binding()
    path = corrected.OUT / (mode + '_health.json')
    value = json.loads(path.read_bytes())
    initial = prior.require_initial()
    expected_rows = (initial['services'] if mode == 'rollback'
        else prior.read('ready_revisions.json')['services'])
    expected_lock = (json.loads((prior.cloud.OUT / 'expected_runtime_lock_v10_13.json').read_bytes())['runtime_lock']
        if mode == 'rollback' else binding['runtime_lock'])
    if (value.get('schema') != 'motomedic-v14-corrected-pair-health-v2'
            or value.get('backend_binding') != corrected.reference(corrected.BINDING)
            or value.get('corrected_expectation') != corrected.reference(corrected.EXPECTED)
            or value.get('preserved_v1_initial') != corrected.reference(prior.OUT / 'initial.json')
            or value.get('ui_equivalence') != initial['ui_equivalence']
            or value.get('provider_calls') != 0 or value.get('cloud_mutations') != 0
            or value.get('v1_health_acceptance_claimed') is not False
            or set(value.get('services', {})) != set(prior.PAIR)):
        raise ValueError('EXACT_CORRECTED_PAIR_HEALTH_RECEIPT_REQUIRED')
    for name in prior.PAIR:
        row = value['services'][name]; health = row.get('health', {})
        expected = {'ready': True, 'runtime_lock': expected_lock,
            'answer_provider': 'claude-haiku-5-5', 'verifier_provider': 'claude-haiku-5-5',
            'model_routing': corrected.ROUTING_CONTRACT,
            'reranking': corrected.LEGACY_HEALTH_LABEL,
            'durable_dispatch_configured': True}
        if (row.get('revision') != expected_rows[name]['revision'] or row.get('http_status') != 200
                or any(health.get(key) != item for key, item in expected.items())):
            raise ValueError('CORRECTED_HEALTH_LOCK_REVISION_OR_PROVIDER_CHANGED')
    prior.promote.require_retained_ledger(value['controls_before']['ledger'], value['controls_after']['ledger'])
    return value

def route(mode, guard_path):
    if mode not in ('rollback', 'restore'):
        raise ValueError('ONLY_CORRECTED_ROLLBACK_OR_RESTORE_ALLOWED')
    prerequisite = 'candidate' if mode == 'rollback' else 'rollback'
    verified = health_receipt(prerequisite)
    original_read = prior.read
    def exact_health_bridge(name):
        if name == prerequisite + '_health.json': return verified
        return original_read(name)
    # Only the named operational health prerequisite is redirected. All source,
    # initial/candidate/image, current material/IAM, etag, guard, ledger and
    # worker-first traffic gates remain the existing prior.route implementation.
    with patch.object(prior, 'read', exact_health_bridge):
        result = prior.route(mode, guard_path)
    return {**result, 'corrected_health_receipt': corrected.reference(corrected.OUT / (prerequisite + '_health.json')),
        'v1_health_receipt_created_or_overwritten': False}

if __name__ == '__main__':
    prior.cloud.token = prior.console.token
    args = sys.argv[1:]
    if args == ['--check-only']:
        result = {'actions': ['route rollback', 'route restore'], 'cloud_calls': 0, 'provider_calls': 0,
            'UI_changes': False, 'runtime_changes': False, 'v1_health_receipt_mutations': False}
    elif len(args) == 3 and args[0] == 'route': result = route(args[1], args[2])
    else: raise SystemExit('ONE_FIXED_CORRECTED_ROLLBACK_OR_RESTORE_ACTION_REQUIRED')
    print(json.dumps(result), flush=True)
