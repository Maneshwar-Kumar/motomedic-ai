"""Read-only v14 health expectation correction; v1 release bytes stay intact."""
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import mvp_retrieval_release_v14 as prior
from cloud.grounded_generation.verified_qa import Config
from cloud.grounded_generation.cached_verifier import CONTRACT
from cloud.grounded_generation.role_router import ROUTING_CONTRACT
from cloud.grounded_generation.serving_retrieval import VERSION as RETRIEVAL_VERSION

ROOT, cloud, run = prior.ROOT, prior.cloud, prior.run
OUT = cloud.OUT / 'haiku_v10_14_helpers/backend_release_v2'
EXPECTED = cloud.OUT / 'expected_runtime_lock_v10_14_v2.json'
BINDING = OUT / 'backend_build_binding_v2.json'
LEGACY_HEALTH_LABEL = 'authenticated-open-hybrid-rank-disagreement-v5'

def write(name, value):
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / name).open('x', encoding='utf-8') as target:
        json.dump(value, target, indent=2, sort_keys=True); target.write('\n')
def reference(path): return {'path': path.relative_to(ROOT).as_posix(), 'sha256': prior.sha(path)}
def expectation():
    initial = prior.require_initial()
    value = json.loads(EXPECTED.read_bytes())
    proper = Config(verifier_contract=CONTRACT, routing_contract=ROUTING_CONTRACT)
    preserved = cloud.OUT / 'expected_runtime_lock_v10_14.json'
    correction = value.get('corrects_preserved_expectation', {})
    if (value.get('runtime_lock') != proper.lock or value.get('versions') != proper.versions()
            or correction.get('path') != preserved.relative_to(ROOT).as_posix()
            or correction.get('sha256') != prior.sha(preserved)
            or prior.sha(preserved) != initial['runtime_lock_readback_sha256']
            or value.get('runtime_code_or_deployment_changes') is not False):
        raise ValueError('EXACT_PRODUCTION_CONSTRUCTOR_EXPECTATION_CORRECTION_REQUIRED')
    frozen = prior.manifest()
    for name, expected in proper.versions()['code_sha256'].items():
        paths = (name, 'cloud/grounded_generation/' + name, 'cloud/arm_a/' + name)
        if not any(frozen['file_sha256'].get(path) == expected for path in paths):
            raise ValueError('PRODUCTION_CONFIG_CODE_DIFFERS_FROM_FROZEN_V14:' + name)
    if RETRIEVAL_VERSION != 'authenticated-open-hybrid-rank-disagreement-v6':
        raise ValueError('ACTUAL_FROZEN_RETRIEVAL_VERSION_NOT_V6')
    return value, proper
def corrected_binding():
    value, proper = expectation()
    original = prior.read('backend_build_binding.json')
    corrected = dict(original)
    corrected.update(schema='motomedic-backend-only-v14-build-binding-v2', runtime_lock=proper.lock,
        preserved_v1_binding=reference(prior.OUT / 'backend_build_binding.json'),
        corrected_expectation=reference(EXPECTED),
        correction_scope='EXPECTED_CONFIG_CONSTRUCTOR_AND_LEGACY_HEALTH_LABEL_ONLY',
        runtime_image_source_or_configuration_changes=False,
        v1_health_acceptance_claimed=False,
        legacy_health_reranking_label=LEGACY_HEALTH_LABEL,
        actual_serving_retrieval_version=RETRIEVAL_VERSION,
        actual_serving_retrieval_sha256=prior.manifest()['file_sha256']['cloud/grounded_generation/serving_retrieval.py'])
    return corrected
def bind():
    corrected = corrected_binding()
    write(BINDING.name, corrected)
    return {'binding_v2_saved': True, 'runtime_lock': corrected['runtime_lock'],
        'backend_image': corrected['backend_image'], 'cloud_calls': 0, 'provider_calls': 0}
def require_binding():
    actual = json.loads(BINDING.read_bytes())
    if actual != corrected_binding(): raise ValueError('CORRECTED_BACKEND_BINDING_CHANGED')
    return actual
def health(mode, guard_path):
    if mode not in ('candidate', 'rollback', 'restore'): raise ValueError('FIXED_PAIR_HEALTH_MODE_REQUIRED')
    binding = require_binding(); initial = prior.require_initial()
    checked = prior.controls(guard_path); prior.unchanged_surrounding(initial)
    lock = (json.loads((cloud.OUT / 'expected_runtime_lock_v10_13.json').read_bytes())['runtime_lock']
        if mode == 'rollback' else binding['runtime_lock'])
    results = {}
    for name in prior.PAIR:
        template, candidate = prior.target(name)
        declared = initial['services'][name]['service']['template'] if mode == 'rollback' else template
        current = prior.row(name, declared)
        wanted_revision = initial['services'][name] if mode == 'rollback' else prior.read('ready_revisions.json')['services'][name]
        if (current['revision'] != wanted_revision['revision']
                or current['revision_configuration_sha256'] != wanted_revision['revision_configuration_sha256']
                or any(current[key] != initial['services'][name][key]
                    for key in ('service_configuration', 'iam_binding_sha256'))):
            raise ValueError('EXACT_ROUTED_PAIR_MATERIAL_OR_IAM_CHANGED')
        request = cloud.Request(current['service']['uri'] + '/v1/health')
        with cloud.build_opener(cloud.NoRedirect()).open(request, timeout=60) as response:
            body = json.loads(response.read(65536)); status = response.status
        wanted = {'ready': True, 'runtime_lock': lock, 'answer_provider': 'claude-haiku-5-5',
            'verifier_provider': 'claude-haiku-5-5', 'model_routing': ROUTING_CONTRACT,
            'index_id': 'index_a3282c4d98cf54595e4ba168',
            'manual_checksum': 'cf221a29e2f9cd5af6e80a99774a697c814e8eda661c27d72e519d8a7e80da89',
            'reranking': LEGACY_HEALTH_LABEL, 'durable_dispatch_configured': True,
            'architecture': 'DRAFT_VERIFY_STREAM_OPEN_MANUAL_QA', 'streaming': 'DRAFT_VERIFY_STREAM'}
        if status != 200 or any(body.get(key) != item for key, item in wanted.items()):
            raise ValueError('EXACT_PRODUCTION_RUNTIME_HEALTH_REQUIRED')
        results[name] = {'revision': current['revision'], 'http_status': status, 'health': body}
    checked_after = prior.controls(guard_path)
    prior.promote.require_retained_ledger(checked['ledger'], checked_after['ledger'])
    write(mode + '_health.json', {'schema': 'motomedic-v14-corrected-pair-health-v2',
        'recorded_at_utc': datetime.now(timezone.utc).isoformat(), 'services': results,
        'backend_binding': reference(BINDING), 'corrected_expectation': reference(EXPECTED),
        'preserved_v1_initial': reference(prior.OUT / 'initial.json'),
        'controls_before': checked, 'controls_after': checked_after,
        'ui_equivalence': initial['ui_equivalence'],
        'health_reranking_field_is_legacy_static_label': True,
        'actual_retrieval_version_proof': 'EXACT_FROZEN_CODE_HASH_AND_CONFIG_LOCK; LIVE_RETRIEVAL_TRACE_REQUIRED_FOR_OPERATION_PROOF',
        'actual_frozen_retrieval_version': RETRIEVAL_VERSION,
        'provider_calls': 0, 'cloud_mutations': 0, 'v1_health_acceptance_claimed': False,
        'quality_acceptance': False})
    return {'pair_health_passed': True, 'mode': mode, 'runtime_lock': lock,
        'ui_remains_v13': True, 'provider_calls': 0, 'cloud_mutations': 0}

if __name__ == '__main__':
    cloud.token = prior.console.token
    args = sys.argv[1:]
    if args == ['--check-only']: result = {'actions': ['bind', 'health'], 'cloud_calls': 0, 'provider_calls': 0, 'runtime_mutations': 0}
    elif args == ['bind']: result = bind()
    elif len(args) == 3 and args[0] == 'health': result = health(args[1], args[2])
    else: raise SystemExit('ONE_FIXED_EXPECTATION_CORRECTION_OR_READONLY_HEALTH_ACTION_REQUIRED')
    print(json.dumps(result), flush=True)
